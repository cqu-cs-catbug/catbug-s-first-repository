from __future__ import annotations
from dataclasses import dataclass
from core.body_type import BodyType
from core.color_palette import ColorPalette


@dataclass(frozen=True)
class Skin:
    """表示蛇的完整皮肤，由体型和颜色组合而成"""
    name: str  # 组合名称，如"green_giant"
    body_type: BodyType  # 体型
    color_palette: ColorPalette  # 颜色
    
    @property
    def head_color(self) -> str:
        return self.color_palette.head_color
    
    @property
    def body_color(self) -> str:
        return self.color_palette.body_color
    
    @property
    def head_size_multiplier(self) -> float:
        return self.body_type.head_size_multiplier
    
    @property
    def body_size_multiplier(self) -> float:
        return self.body_type.body_size_multiplier
    
    @property
    def length_multiplier(self) -> float:
        return self.body_type.length_multiplier
