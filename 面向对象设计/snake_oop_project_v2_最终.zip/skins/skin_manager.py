from __future__ import annotations
import json
import os
from typing import Dict, Optional

from core.body_type_manager import BodyTypeManager
from core.color_palette_manager import ColorPaletteManager
from core.exceptions import ResourceLoadException
from skins.skin import Skin


class SkinManager:
    """Singleton skin manager (global shared resource)."""
    _instance: Optional["SkinManager"] = None

    def __init__(self) -> None:
        self._skins: Dict[str, Skin] = {}
        self._loaded = False
        
        # 初始化管理器实例
        self.body_type_manager = BodyTypeManager.instance()
        self.color_palette_manager = ColorPaletteManager.instance()
        
        # 注册默认皮肤组合
        self.register_default()

    @classmethod
    def instance(cls) -> "SkinManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def load_from_file(self, path: str) -> None:
        """加载皮肤资源 - 修复：允许重新加载，更健壮的错误处理"""
        # 加载颜色调色板
        self.color_palette_manager.load_from_file(path)
        
        # 皮肤组合会动态生成，不需要从文件加载
        self._loaded = True

    def register_default(self) -> None:
        """注册默认皮肤组合"""
        # 清空现有皮肤
        self._skins.clear()
        
        # 获取所有体型和颜色
        body_types = self.body_type_manager.get_all()
        color_palettes = self.color_palette_manager.get_all()
        
        # 生成所有可能的组合
        for color_name, color in color_palettes.items():
            for body_type_name, body_type in body_types.items():
                # 组合名称：color_body_type
                combined_name = f"{color_name}_{body_type_name}"
                self._skins[combined_name] = Skin(
                    name=combined_name,
                    body_type=body_type,
                    color_palette=color
                )
        
        # 添加一些常用的别名
        for color_name, color in color_palettes.items():
            # 默认体型的别名，如 "green" -> "green_normal"
            self._skins[color_name] = self._skins[f"{color_name}_normal"]
        
        for body_type_name, body_type in body_types.items():
            # 默认颜色的别名，如 "giant" -> "green_giant"
            self._skins[body_type_name] = self._skins[f"green_{body_type_name}"]

    def get(self, name: str) -> Skin:
        """获取指定名称的皮肤"""
        # 如果皮肤不存在，尝试动态生成
        if name not in self._skins:
            # 尝试解析组合名称：color_body_type
            parts = name.split("_")
            if len(parts) == 2:
                color_name, body_type_name = parts
                try:
                    body_type = self.body_type_manager.get(body_type_name)
                    color_palette = self.color_palette_manager.get(color_name)
                    skin = Skin(
                        name=name,
                        body_type=body_type,
                        color_palette=color_palette
                    )
                    self._skins[name] = skin
                    return skin
                except Exception:
                    pass
            
            # 如果无法解析，返回默认皮肤
            self.register_default()
            return self._skins["green_normal"]
        return self._skins[name]
        
    def get_by_combination(self, color_name: str, body_type_name: str) -> Skin:
        """根据颜色和体型组合获取皮肤"""
        combined_name = f"{color_name}_{body_type_name}"
        return self.get(combined_name)
        
    def get_all_body_types(self) -> Dict[str, str]:
        """获取所有可用的体型及其显示名称"""
        body_types = self.body_type_manager.get_all()
        return {name: body_type.display_name for name, body_type in body_types.items()}
        
    def get_all_color_palettes(self) -> Dict[str, str]:
        """获取所有可用的颜色及其显示名称"""
        color_palettes = self.color_palette_manager.get_all()
        return {name: color.display_name for name, color in color_palettes.items()}
