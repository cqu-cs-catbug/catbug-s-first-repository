from __future__ import annotations
from dataclasses import dataclass, field
from collections import deque
from typing import Deque, Iterable, Optional, Set

from core.types import Direction, Position
from core.exceptions import InvalidInputException
from skins.skin import Skin


@dataclass
class Snake:
    name: str
    body: Deque[Position]
    direction: Direction
    skin: Skin
    alive: bool = True
    score: int = 0
    shield_charges: int = 0
    _grow_pending: int = 0
    shrink_skill_uses: int = 0  # Shift技能使用次数（每局最多2次）
    _move_counter: int = 0  # 移动计数器，用于实现独立减速

    @property
    def head(self) -> Position:
        return self.body[0]

    def occupies(self, pos: Position) -> bool:
        return pos in self.body

    def occupied_set(self) -> Set[Position]:
        return set(self.body)

    def turn(self, new_direction: Direction) -> None:
        # 忽略反方向输入，避免蛇停止或卡顿
        # 如果按反方向键，直接忽略，保持当前方向
        if new_direction.is_opposite(self.direction):
            return  # 直接返回，不改变方向，不抛出异常
        self.direction = new_direction

    def step_next_head(self) -> Position:
        return self.head + self.direction.delta

    def move(self, in_swamp: bool = False) -> None:
        """
        Advance one cell.
        in_swamp: 是否在湿地上，用于实现独立减速
        """
        # 如果在湿地上，需要等待2个tick才移动一次（减速50%）
        if in_swamp:
            self._move_counter += 1
            if self._move_counter < 2:
                return  # 跳过本次移动
            self._move_counter = 0  # 重置计数器
        
        new_head = self.step_next_head()
        self.body.appendleft(new_head)

        if self._grow_pending > 0:
            self._grow_pending -= 1
            return

        self.body.pop()

    def grow(self, amount: int = 1) -> None:
        self._grow_pending += max(1, amount)

    def shrink_half(self) -> bool:
        """
        蛇长度减半
        返回: True表示成功，False表示失败（已达到使用次数限制）
        """
        # 检查使用次数限制（每局最多2次）
        if self.shrink_skill_uses >= 2:
            return False
        
        # Keep at least length 2
        target = max(2, len(self.body) // 2)
        while len(self.body) > target:
            self.body.pop()
        
        # 增加使用次数
        self.shrink_skill_uses += 1
        return True

    def grant_shield(self, charges: int = 1) -> None:
        self.shield_charges += max(1, charges)

    def consume_shield_if_any(self) -> bool:
        if self.shield_charges > 0:
            self.shield_charges -= 1
            return True
        return False
