from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional
import json
import os
from core.settings import GameSettings
from core.types import SpeedSetting


class SettingsManager:
    """设置管理器，负责保存和加载游戏设置"""
    
    _instance: Optional["SettingsManager"] = None
    
    def __init__(self):
        if SettingsManager._instance is not None:
            raise RuntimeError("SettingsManager is a singleton")
        self._settings_file = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "game_settings.json"
        )
        self._default_settings = GameSettings()
    
    @classmethod
    def instance(cls) -> "SettingsManager":
        """获取单例实例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def load_settings(self) -> GameSettings:
        """从文件加载设置"""
        print(f"Attempting to load settings from {self._settings_file}")
        if not os.path.exists(self._settings_file):
            print(f"Settings file not found, returning default settings")
            return self._default_settings
        
        try:
            with open(self._settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                print(f"Raw settings data loaded: {data}")
                
                # 处理旧格式的兼容性（只在字段不存在时添加默认值）
                if 'p1_keys' not in data:
                    data['p1_keys'] = {"up": "Up", "down": "Down", "left": "Left", "right": "Right"}
                if 'p2_keys' not in data:
                    data['p2_keys'] = {"up": "w", "down": "s", "left": "a", "right": "d"}
                if 'enable_mountain' not in data:
                    data['enable_mountain'] = True
                if 'enable_swamp' not in data:
                    data['enable_swamp'] = True
                if 'two_player_time_limit_sec' not in data:
                    data['two_player_time_limit_sec'] = 60
                if 'key_scheme' not in data:
                    data['key_scheme'] = "default"
                
                # 转换speed字符串为SpeedSetting枚举
                if 'speed' in data and isinstance(data['speed'], str):
                    data['speed'] = SpeedSetting[data['speed']]
                
                # 移除不在GameSettings字段中的键（避免TypeError）
                from dataclasses import fields
                valid_fields = {f.name for f in fields(GameSettings)}
                filtered_data = {k: v for k, v in data.items() if k in valid_fields}
                print(f"Filtered settings data: {filtered_data}")
                
                result = GameSettings(**filtered_data)
                print(f"Loaded settings: {result}")
                return result
        except json.JSONDecodeError as e:
            print(f"JSON decode error when loading settings: {e}")
            print(f"Settings file {self._settings_file} may be corrupted, returning default settings")
            return self._default_settings
        except Exception as e:
            # 加载失败时打印错误信息（用于调试）
            import traceback
            print(f"Error loading settings: {e}")
            traceback.print_exc()
            return self._default_settings
    
    def save_settings(self, settings: GameSettings) -> None:
        """保存设置到文件"""
        print(f"Attempting to save settings to {self._settings_file}")
        print(f"Settings to save: {settings}")
        try:
            os.makedirs(os.path.dirname(self._settings_file), exist_ok=True)
            data = asdict(settings)
            print(f"Settings data (before conversion): {data}")
            # 转换SpeedSetting枚举为字符串
            if isinstance(settings.speed, SpeedSetting):
                data['speed'] = settings.speed.name
            print(f"Settings data (after conversion): {data}")
            with open(self._settings_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"Settings saved successfully to {self._settings_file}")
        except PermissionError as e:
            print(f"Permission error when saving settings: {e}")
            print(f"Check if you have write permissions for {self._settings_file}")
        except IOError as e:
            print(f"IO error when saving settings: {e}")
        except Exception as e:
            # 保存失败时打印错误信息（用于调试）
            import traceback
            print(f"Error saving settings: {e}")
            traceback.print_exc()
            # 仍然静默处理，避免影响游戏运行
    
    def reset_to_default(self) -> GameSettings:
        """重置为默认设置"""
        default = self._default_settings
        self.save_settings(default)
        return default
