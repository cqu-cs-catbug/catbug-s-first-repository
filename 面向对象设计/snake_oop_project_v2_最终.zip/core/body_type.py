from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class BodyType:
    """表示蛇的体型特征"""
    name: str  # 体型名称，如"giant", "dwarf", "slender"
    display_name: str  # 显示名称，如"巨大型", "矮小型", "细长型"
    head_size_multiplier: float  # 头部大小倍数
    body_size_multiplier: float  # 身体大小倍数
    length_multiplier: float  # 初始长度倍数
