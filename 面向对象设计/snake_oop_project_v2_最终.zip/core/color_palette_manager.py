from __future__ import annotations
import json
import os
from typing import Dict, Optional

from core.color_palette import ColorPalette


class ColorPaletteManager:
    """颜色管理器（单例），管理所有可用的颜色调色板"""
    _instance: Optional["ColorPaletteManager"] = None
    
    def __init__(self) -> None:
        self._color_palettes: Dict[str, ColorPalette] = {}
        self._register_default_color_palettes()
    
    @classmethod
    def instance(cls) -> "ColorPaletteManager":
        """获取颜色管理器单例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _register_default_color_palettes(self) -> None:
        """注册默认颜色调色板"""
        self._color_palettes = {
            "green": ColorPalette(
                name="green",
                display_name="绿色经典",
                head_color="#1c7c54",
                body_color="#5fbf89"
            ),
            "blue": ColorPalette(
                name="blue",
                display_name="蓝色经典",
                head_color="#174ea6",
                body_color="#6ea8fe"
            ),
            "red": ColorPalette(
                name="red",
                display_name="红色经典",
                head_color="#b00020",
                body_color="#ff6b6b"
            ),
            "purple": ColorPalette(
                name="purple",
                display_name="紫色",
                head_color="#6b46c1",
                body_color="#a78bfa"
            ),
            "orange": ColorPalette(
                name="orange",
                display_name="橙色",
                head_color="#d97706",
                body_color="#fbbf24"
            ),
            "yellow": ColorPalette(
                name="yellow",
                display_name="黄色",
                head_color="#eab308",
                body_color="#fde68a"
            ),
            "cyan": ColorPalette(
                name="cyan",
                display_name="青色",
                head_color="#0891b2",
                body_color="#22d3ee"
            ),
            "pink": ColorPalette(
                name="pink",
                display_name="粉色",
                head_color="#ec4899",
                body_color="#f472b6"
            )
        }
    
    def load_from_file(self, path: str) -> None:
        """从文件加载颜色调色板"""
        if not os.path.exists(path):
            return
        
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            # 保存旧的颜色作为后备
            old_palettes = dict(self._color_palettes)
            
            # 清空现有颜色，准备加载新颜色
            self._color_palettes.clear()
            
            # 先注册默认颜色
            self._register_default_color_palettes()
            
            # 加载新颜色
            for k, v in data.get("skins", {}).items():
                try:
                    # 确保颜色值是字符串
                    head_color = str(v.get("head_color", "#000000"))
                    body_color = str(v.get("body_color", "#000000"))
                    display_name = v.get("display_name", k)
                    self._color_palettes[k] = ColorPalette(
                        name=k,
                        display_name=display_name,
                        head_color=head_color,
                        body_color=body_color
                    )
                except Exception:
                    # 单个颜色加载失败，跳过继续加载其他颜色
                    continue
        except Exception:
            # 加载失败时，恢复旧的颜色
            self._color_palettes = old_palettes
    
    def get(self, name: str) -> ColorPalette:
        """获取指定名称的颜色调色板"""
        return self._color_palettes.get(name, self._color_palettes["green"])
    
    def get_all(self) -> Dict[str, ColorPalette]:
        """获取所有可用的颜色调色板"""
        return self._color_palettes.copy()
    
    def get_display_name(self, name: str) -> str:
        """获取颜色调色板的显示名称"""
        return self._color_palettes.get(name, self._color_palettes["green"]).display_name
