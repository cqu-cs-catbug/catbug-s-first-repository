class GameException(Exception):
    """Base exception for game domain errors."""


class CollisionException(GameException):
    """Raised when a fatal collision occurs."""

    def __init__(self, message: str, who: str | None = None):
        super().__init__(message)
        self.who = who


class InvalidInputException(GameException):
    """Raised when input is invalid (e.g., reversing direction)."""


class ResourceLoadException(GameException):
    """Raised when a resource (skin/config) fails to load."""
