from __future__ import annotations
from typing import Dict, Optional

from core.body_type import BodyType


class BodyTypeManager:
    """体型管理器（单例），管理所有可用的体型"""
    _instance: Optional["BodyTypeManager"] = None
    
    def __init__(self) -> None:
        self._body_types: Dict[str, BodyType] = {}
        self._register_default_body_types()
    
    @classmethod
    def instance(cls) -> "BodyTypeManager":
        """获取体型管理器单例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _register_default_body_types(self) -> None:
        """注册默认体型"""
        self._body_types = {
            "normal": BodyType(
                name="normal",
                display_name="标准型",
                head_size_multiplier=1.0,
                body_size_multiplier=1.0,
                length_multiplier=1.0
            ),
            "giant": BodyType(
                name="giant",
                display_name="巨大型",
                head_size_multiplier=1.3,
                body_size_multiplier=1.2,
                length_multiplier=1.5
            ),
            "dwarf": BodyType(
                name="dwarf",
                display_name="矮小型",
                head_size_multiplier=0.8,
                body_size_multiplier=0.8,
                length_multiplier=0.8
            ),
            "slender": BodyType(
                name="slender",
                display_name="细长型",
                head_size_multiplier=0.9,
                body_size_multiplier=0.7,
                length_multiplier=1.2
            )
        }
    
    def get(self, name: str) -> BodyType:
        """获取指定名称的体型"""
        return self._body_types.get(name, self._body_types["normal"])
    
    def get_all(self) -> Dict[str, BodyType]:
        """获取所有可用的体型"""
        return self._body_types.copy()
    
    def get_display_name(self, name: str) -> str:
        """获取体型的显示名称"""
        return self._body_types.get(name, self._body_types["normal"]).display_name
