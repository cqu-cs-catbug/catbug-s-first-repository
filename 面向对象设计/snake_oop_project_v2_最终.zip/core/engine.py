from __future__ import annotations
import os
import random
import time
from collections import deque
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

from core.events import EventBus
from core.exceptions import CollisionException, InvalidInputException, ResourceLoadException
from core.settings import GameSettings
from core.types import Direction, Position, SpeedSetting, TerrainType
from entities.snake import Snake
from items.base import Item
from items.item_factory import ItemFactory
from modes.standard import StandardMode
from modes.two_player import TwoPlayerMode
from modes.timed import TimedMode
from modes.two_player_timed import TwoPlayerTimedMode
from skins.skin_manager import SkinManager
from world.map import GameMap


@dataclass
class GameState:
    running: bool = False
    paused: bool = False
    game_over: bool = False
    message: str = ""
    time_started: Optional[float] = None  # 实际开始计时的时间


class GameEngine:
    """GameEngine orchestrates map, snakes, items and game mode (Strategy)."""

    def __init__(self, events: Optional[EventBus] = None) -> None:
        self.events = events or EventBus()
        self.settings: GameSettings = GameSettings()
        self.state = GameState()
        self.map: GameMap | None = None
        self.snakes: List[Snake] = []
        self.items: List[Item] = []
        self.mode = StandardMode()
        self.item_factory = ItemFactory()

        self.started_at: float = 0.0
        self._last_tick_ms: int = 0

        # Controllers keyed by snake name; UI assigns them.
        self.controllers: Dict[str, "PlayerController"] = {}
        # per-tick rollback snapshots (used when shield absorbs collisions)
        self._prev_bodies: Dict[str, deque] = {}

    def start_game(self, settings: GameSettings) -> None:
        self.settings = settings
        self.state = GameState(running=True, paused=False, game_over=False, message="", time_started=None)
        self.started_at = time.time()  # 保留用于初始化，但实际计时使用time_started
        self._last_tick_ms = int(self.started_at * 1000)

        # Load skins with safe fallback using absolute path
        skin_mgr = SkinManager.instance()
        try:
            # Get absolute path to assets/skins.json
            script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            skins_path = os.path.join(script_dir, "assets", "skins.json")
            skin_mgr.load_from_file(skins_path)
        except Exception as e:
            # Use default skins if loading fails for any reason
            skin_mgr.register_default()

        # Build map (根据难度生成地形)
        enable_mountain = getattr(settings, 'enable_mountain', True)
        enable_swamp = getattr(settings, 'enable_swamp', True)
        self.map = GameMap.build_default(
            settings.width,
            settings.height,
            enable_moving_obstacle=settings.enable_moving_obstacle,
            difficulty=settings.difficulty,
            enable_mountain=enable_mountain,
            enable_swamp=enable_swamp,
        )

        # Select mode strategy
        if settings.mode == "single":
            self.mode = StandardMode()
        elif settings.mode == "two":
            self.mode = TwoPlayerMode()
        elif settings.mode == "timed":
            self.mode = TimedMode(settings.time_limit_sec)
        elif settings.mode == "two_timed":
            two_player_time = getattr(settings, 'two_player_time_limit_sec', settings.time_limit_sec)
            self.mode = TwoPlayerTimedMode(two_player_time)
        else:
            self.mode = StandardMode()

        # Spawn snakes
        self.snakes = []
        
        # 获取用户选择的皮肤（修复：从偏好设置中获取，而不是硬编码）
        from core.skin_preferences import SkinPreferences
        skin_prefs = SkinPreferences.instance()
        
        # 创建玩家1
        p1_skin_name = skin_prefs.get_skin("P1")
        p1_skin = skin_mgr.get(p1_skin_name)
        # 统一初始长度为4格，不受体型影响
        p1_initial_length = 4
        p1 = Snake(
            name="P1",
            body=self._create_initial_body(Position(4, 4), length=p1_initial_length, direction=Direction.RIGHT),
            direction=Direction.RIGHT,
            skin=p1_skin,
        )
        self.snakes.append(p1)

        if settings.mode in ("two", "two_timed"):
            # 创建玩家2
            p2_skin_name = skin_prefs.get_skin("P2")
            p2_skin = skin_mgr.get(p2_skin_name)
            # 统一初始长度为4格，不受体型影响
            p2_initial_length = 4
            p2 = Snake(
                name="P2",
                body=self._create_initial_body(Position(settings.width - 5, settings.height - 5), length=p2_initial_length, direction=Direction.LEFT),
                direction=Direction.LEFT,
                skin=p2_skin,
            )
            self.snakes.append(p2)

        self.items = []
        self._spawn_initial_items()

        self.events.emit("game_started", {"mode": self.mode.display_name})
        self.events.emit("state_updated", self.snapshot())

    def _create_initial_body(self, start: Position, length: int, direction: Direction):
        from collections import deque
        body = deque()
        dx, dy = direction.delta
        for i in range(length):
            body.append(Position(start.x - dx * i, start.y - dy * i))
        return body

    def _occupied_cells(self) -> Set[Position]:
        occ: Set[Position] = set()
        for s in self.snakes:
            occ |= s.occupied_set()
        if self.map:
            for ob in self.map.obstacles:
                occ.add(ob.position)
        for it in self.items:
            occ.add(it.position)
        return occ

    def __init__(self, events: Optional[EventBus] = None) -> None:
        self.events = events or EventBus()
        self.settings: GameSettings = GameSettings()
        self.state = GameState()
        self.map: GameMap | None = None
        self.snakes: List[Snake] = []
        self.items: List[Item] = []
        self.mode = StandardMode()
        self.item_factory = ItemFactory()

        self.started_at: float = 0.0
        self._last_tick_ms: int = 0

        # Controllers keyed by snake name; UI assigns them.
        self.controllers: Dict[str, "PlayerController"] = {}
        # per-tick rollback snapshots (used when shield absorbs collisions)
        self._prev_bodies: Dict[str, deque] = {}
        
        # 蓝色食物相关计时
        self._last_blue_food_spawn: float = 0.0
        self._blue_food_refresh_interval: float = 5.0  # 5秒刷新一次
        self._blue_food_lifetime: float = 10.0  # 10秒后消失

    def _spawn_initial_items(self) -> None:
        # 初始生成5个黄色食物
        for _ in range(5):
            self.spawn_item(food_type="yellow")
        # 初始生成1个蓝色食物
        self.spawn_item(food_type="blue")
        self._last_blue_food_spawn = time.time()

    def spawn_item(self, force_food: bool = False, food_type: str = "yellow") -> None:
        """
        生成物品
        force_food: 如果为True，强制生成食物（用于初始生成）
        food_type: 食物类型，"yellow"或"blue"
        """
        if not self.map:
            return
        pos = self.map.random_empty_cell(self._occupied_cells())
        if not pos:
            return
        
        if force_food or food_type == "yellow":
            # 生成黄色食物
            from items.food import Food
            self.items.append(Food(position=pos))
        elif food_type == "blue":
            # 生成蓝色食物
            from items.food import BlueFood
            self.items.append(BlueFood(position=pos, spawn_time=time.time()))
        else:
            # 正常随机生成（道具小概率）
            self.items.append(self.item_factory.create_random(pos))

    def toggle_pause(self) -> None:
        if not self.state.running:
            return
        self.state.paused = not self.state.paused
        
        # 如果从暂停状态转为运行状态，且之前未开始计时，则设置开始时间
        if not self.state.paused and self.state.time_started is None:
            self.state.time_started = time.time()
        
        self.events.emit("state_updated", self.snapshot())

    def register_controller(self, snake_name: str, controller: "PlayerController") -> None:
        self.controllers[snake_name] = controller

    def update(self, now_ms: int) -> None:
        """Tick update driven by UI timer."""
        if not self.state.running or self.state.game_over:
            return
        if self.state.paused:
            return
        if not self.map:
            return

        try:
            tick_ms = self._compute_tick_ms()
            if now_ms - self._last_tick_ms < tick_ms:
                return
            self._last_tick_ms = now_ms

            # 处理蓝色食物的生命周期和刷新
            current_time = time.time()
            
            # 移除超过生命周期的蓝色食物
            from items.food import BlueFood
            blue_foods_to_remove = []
            for item in self.items:
                if isinstance(item, BlueFood) and (current_time - item.spawn_time > self._blue_food_lifetime):
                    blue_foods_to_remove.append(item)
            
            for item in blue_foods_to_remove:
                if item in self.items:
                    self.items.remove(item)
            
            # 检查是否需要刷新蓝色食物
            if current_time - self._last_blue_food_spawn >= self._blue_food_refresh_interval:
                # 移除所有蓝色食物，准备刷新
                blue_foods_to_remove = [item for item in self.items if isinstance(item, BlueFood)]
                for item in blue_foods_to_remove:
                    if item in self.items:
                        self.items.remove(item)
                # 生成新的蓝色食物
                self.spawn_item(food_type="blue")
                self._last_blue_food_spawn = current_time
            
            # 确保地图上至少有一个蓝色食物
            has_blue_food = any(isinstance(item, BlueFood) for item in self.items)
            if not has_blue_food:
                self.spawn_item(food_type="blue")
                self._last_blue_food_spawn = current_time

            # Apply controller directions (may raise InvalidInputException)
            self._apply_controller_inputs()

            # Move obstacles first (dynamic obstacles)
            self.map.update_obstacles()

            # Snapshot bodies for safe rollback
            self._prev_bodies = {s.name: deque(s.body) for s in self.snakes if s.alive}

            # Move snakes（每条蛇独立判断是否在湿地上）
            for s in self.snakes:
                if s.alive:
                    # 检查当前蛇是否在湿地上（用于独立减速）
                    in_swamp = False
                    if self.map and self.map.get_terrain(s.head) == TerrainType.SWAMP:
                        in_swamp = True
                    s.move(in_swamp=in_swamp)

            # Check collisions and items
            self._check_collisions_and_items()

            # 管理黄色食物数量：始终保持地图上有5个黄色食物
            from items.food import Food
            yellow_food_count = sum(1 for item in self.items if isinstance(item, Food) and item.food_type == "yellow")
            target_yellow_food_count = 5
            if yellow_food_count < target_yellow_food_count:
                # 补充黄色食物到5个
                for _ in range(target_yellow_food_count - yellow_food_count):
                    self.spawn_item(food_type="yellow")

            # Mode-specific end condition
            if self.mode.check_game_over(self):
                self._end_game()
            
            # 限时模式：检查时间警告（最后10秒）
            if hasattr(self.mode, 'time_limit_sec') and self.mode.time_limit_sec and self.state.time_started:
                elapsed = time.time() - self.state.time_started
                remaining = self.mode.time_limit_sec - elapsed
                if 0 < remaining <= 10 and int(remaining) == int(remaining):
                    # 每秒发出一次警告（整数秒时）
                    self.events.emit("warning", {"message": f"时间剩余: {int(remaining)}秒"})

            self.events.emit("state_updated", self.snapshot())
            self._prev_bodies = {}

        except CollisionException as ce:
            self.state.message = str(ce)
            # Mark the offender dead if provided
            if ce.who:
                for s in self.snakes:
                    if s.name == ce.who:
                        s.alive = False
            self._end_game()
            self._prev_bodies = {}

        except InvalidInputException as ie:
            # Soft-fail: ignore invalid input, keep game running
            self.events.emit("warning", {"message": str(ie)})
            self._prev_bodies = {}

        except Exception as e:
            # Any unexpected error: stop safely
            self.state.message = f"Unexpected error: {e}"
            self._end_game()
            self._prev_bodies = {}

    def _compute_tick_ms(self) -> int:
        """
        计算游戏更新间隔（毫秒）
        注意：湿地减速现在由每条蛇独立处理，这里只返回基础速度
        """
        # Base speed
        base = self.settings.speed.tick_ms
        # 湿地减速已改为每条蛇独立处理，不再在这里统一减速
        return base

    def _apply_controller_inputs(self) -> None:
        for s in self.snakes:
            ctrl = self.controllers.get(s.name)
            if not ctrl or not s.alive:
                continue
            d = ctrl.consume_requested_direction()
            if d is None:
                continue
            s.turn(d)

    def _check_collisions_and_items(self) -> None:
        assert self.map is not None

        # Build occupancy for body collisions
        bodies = {s.name: set(list(s.body)[1:]) for s in self.snakes}  # exclude head
        heads = {s.name: s.head for s in self.snakes if s.alive}

        # Head collisions
        for s in self.snakes:
            if not s.alive:
                continue
            head = s.head

            # Wall / terrain / obstacle collision
            if self.map.is_blocked(head):
                if s.consume_shield_if_any():
                    # Shield saves you: bounce back by undoing move
                    self._restore_body(s)
                    continue
                raise CollisionException(f"{s.name} 撞到了墙壁/障碍物。", who=s.name)

            # Self collision
            if head in bodies[s.name]:
                if s.consume_shield_if_any():
                    self._restore_body(s)
                    continue
                raise CollisionException(f"{s.name} 撞到了自己。", who=s.name)

            # Other snake collision (head into other body or head-head)
            for other in self.snakes:
                if other is s or not other.alive:
                    continue
                other_body = set(list(other.body))
                if head in other_body:
                    if s.consume_shield_if_any():
                        self._restore_body(s)
                        break
                    raise CollisionException(f"{s.name} 撞到了 {other.name}。", who=s.name)

        # Items
        for s in self.snakes:
            if not s.alive:
                continue
            for it in list(self.items):
                if it.position == s.head:
                    it.apply_effect(s, self)
                    self.items.remove(it)

    def _restore_body(self, s: Snake) -> None:
        """Restore snake body to the snapshot captured at the beginning of this tick."""
        prev = self._prev_bodies.get(s.name)
        if prev is not None:
            s.body = deque(prev)

    def _end_game(self) -> None:
        if self.state.game_over:
            return
        self.state.game_over = True
        self.state.running = False
        winner = self.mode.get_winner(self)
        payload = {
            "mode": self.mode.display_name,
            "winner": winner,
            "scores": {s.name: s.score for s in self.snakes},
            "message": self.state.message,
        }
        self.events.emit("game_over", payload)

    def snapshot(self) -> Dict:
        # 限时模式：计算剩余时间
        remaining_time = None
        if hasattr(self.mode, 'time_limit_sec') and self.mode.time_limit_sec and self.state.time_started:
            elapsed = time.time() - self.state.time_started
            remaining_time = max(0, self.mode.time_limit_sec - elapsed)
        
        return {
            "mode": self.mode.display_name,
            "running": self.state.running,
            "paused": self.state.paused,
            "game_over": self.state.game_over,
            "message": self.state.message,
            "remaining_time": remaining_time,  # 添加剩余时间信息
            "map": {
                "width": self.map.width if self.map else 0,
                "height": self.map.height if self.map else 0,
                "terrain": {(p.x, p.y): int(t.value) for p, t in (self.map.terrain.items() if self.map else [])},
                "obstacles": [(ob.position.x, ob.position.y, bool(getattr(ob, "dynamic", False))) for ob in (self.map.obstacles if self.map else [])],
            },
            "snakes": [
                {
                    "name": s.name,
                    "alive": s.alive,
                    "score": s.score,
                    "shield": s.shield_charges,
                    "shrink_skill_uses": s.shrink_skill_uses,  # Shift技能使用次数
                    "direction": s.direction.name,
                    "body": [(p.x, p.y) for p in s.body],
                    "skin": {
                        "head_color": s.skin.head_color, 
                        "body_color": s.skin.body_color,
                        "head_size_multiplier": s.skin.head_size_multiplier,
                        "body_size_multiplier": s.skin.body_size_multiplier,
                    },
                }
                for s in self.snakes
            ],
            "items": [{"type": it.__class__.__name__, "pos": (it.position.x, it.position.y)} for it in self.items],
        }