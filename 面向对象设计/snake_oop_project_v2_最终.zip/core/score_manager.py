from __future__ import annotations
import json
import os
from dataclasses import dataclass, asdict
from typing import Optional, Dict


@dataclass
class GameRecord:
    """游戏成绩记录（支持所有模式和玩家）"""
    mode: str  # 游戏模式：single, two, timed, two_timed
    player_name: str = ""  # 玩家名称（双人模式下区分玩家）
    best_score: int = 0  # 历史最好成绩
    best_time_used: float = 0.0  # 历史最好成绩对应的用时（限时模式）
    play_count: int = 0  # 游戏次数
    last_updated: str = ""  # 最后更新时间
    
    def get_key(self) -> str:
        """生成唯一键，用于区分不同模式和玩家"""
        if self.player_name:
            return f"{self.mode}:{self.player_name}"
        return self.mode


class ScoreManager:
    """成绩管理器（单例模式），负责管理所有游戏模式的成绩记录"""
    _instance: Optional["ScoreManager"] = None
    _score_file = "scores.json"
    
    def __init__(self) -> None:
        # 使用键值对存储：key -> GameRecord
        # key格式：mode 或 mode:player_name（双人模式）
        self._records: Dict[str, GameRecord] = {}
        self._load_scores()
    
    @classmethod
    def instance(cls) -> "ScoreManager":
        """获取成绩管理器单例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _get_score_file_path(self) -> str:
        """获取成绩文件路径"""
        # 将成绩文件保存在项目根目录
        return os.path.join(os.path.dirname(os.path.dirname(__file__)), self._score_file)
    
    def _load_scores(self) -> None:
        """从文件加载成绩记录（支持新旧格式兼容）"""
        file_path = self._get_score_file_path()
        if os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # 兼容旧格式（基于time_limit_sec）
                    for key, record_data in data.items():
                        if isinstance(record_data, dict):
                            # 新格式：直接使用GameRecord
                            if "mode" in record_data:
                                # 修复：确保mode是字符串类型
                                mode = str(record_data["mode"])
                                # 如果key是数字（如"60"），可能是旧格式的限时模式
                                if key.isdigit() or (isinstance(record_data.get("mode"), int)):
                                    # 这是旧格式的限时模式数据，转换为新格式
                                    record = GameRecord(
                                        mode="timed",
                                        player_name=record_data.get("player_name", ""),
                                        best_score=record_data.get("best_score", 0),
                                        best_time_used=record_data.get("best_time_used", 0.0),
                                        play_count=record_data.get("play_count", 0),
                                        last_updated=record_data.get("last_updated", "")
                                    )
                                else:
                                    # 正常的新格式数据
                                    record = GameRecord(
                                        mode=mode,
                                        player_name=str(record_data.get("player_name", "")),
                                        best_score=int(record_data.get("best_score", 0)),
                                        best_time_used=float(record_data.get("best_time_used", 0.0)),
                                        play_count=int(record_data.get("play_count", 0)),
                                        last_updated=str(record_data.get("last_updated", ""))
                                    )
                                self._records[record.get_key()] = record
                            # 旧格式：转换为新格式（限时模式）
                            elif "time_limit_sec" in record_data:
                                # 迁移旧数据到新格式
                                time_limit = record_data["time_limit_sec"]
                                record = GameRecord(
                                    mode="timed",
                                    player_name="",
                                    best_score=record_data.get("best_score", 0),
                                    best_time_used=record_data.get("best_time_used", 0.0),
                                    play_count=record_data.get("play_count", 0),
                                    last_updated=record_data.get("last_updated", "")
                                )
                                self._records[record.get_key()] = record
            except Exception as e:
                # 如果加载失败，使用空记录
                print(f"Failed to load scores: {e}")
                self._records = {}
    
    def _save_scores(self) -> None:
        """保存成绩记录到文件"""
        file_path = self._get_score_file_path()
        try:
            data = {
                record.get_key(): asdict(record)
                for record in self._records.values()
            }
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save scores: {e}")
    
    def get_record(self, mode: str, player_name: str = "") -> GameRecord:
        """
        获取指定模式和玩家的成绩记录
        mode: 游戏模式（single, two, timed, two_timed）
        player_name: 玩家名称（双人模式下使用，如"P1", "P2"）
        """
        record = GameRecord(mode=mode, player_name=player_name)
        key = record.get_key()
        
        if key not in self._records:
            self._records[key] = record
        return self._records[key]
    
    def update_record(
        self, 
        mode: str, 
        score: int, 
        player_name: str = "",
        time_used: float = 0.0
    ) -> bool:
        """
        更新成绩记录
        mode: 游戏模式
        score: 本次成绩
        player_name: 玩家名称（双人模式下使用）
        time_used: 用时（限时模式使用）
        返回True表示创造了新纪录，False表示未打破纪录
        """
        from datetime import datetime
        
        record = self.get_record(mode, player_name)
        record.play_count += 1
        is_new_record = False
        
        # 比较成绩：如果新成绩更高，则更新记录
        if score > record.best_score:
            record.best_score = score
            if time_used > 0:
                record.best_time_used = time_used
            record.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            is_new_record = True
            self._save_scores()
        elif score == record.best_score and time_used > 0 and time_used < record.best_time_used:
            # 如果分数相同但用时更短（限时模式），也更新记录
            record.best_time_used = time_used
            record.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            is_new_record = True
            self._save_scores()
        else:
            # 即使没有打破纪录，也保存（更新游戏次数）
            self._save_scores()
        
        return is_new_record
    
    def get_all_records_for_mode(self, mode: str) -> Dict[str, GameRecord]:
        """获取指定模式下的所有玩家记录（用于双人模式）"""
        return {
            key: record 
            for key, record in self._records.items() 
            if record.mode == mode
        }
