from __future__ import annotations
import json
import os
from typing import Optional, Dict


class SkinPreferences:
    """皮肤偏好管理器（单例），管理用户选择的皮肤"""
    _instance: Optional["SkinPreferences"] = None
    _prefs_file = "skin_preferences.json"
    
    def __init__(self) -> None:
        self._preferences: Dict[str, str] = {
            "P1": "green",  # P1默认皮肤
            "P2": "blue",   # P2默认皮肤
        }
        self._load_preferences()
    
    @classmethod
    def instance(cls) -> "SkinPreferences":
        """获取皮肤偏好管理器单例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _get_prefs_file_path(self) -> str:
        """获取偏好文件路径"""
        return os.path.join(os.path.dirname(os.path.dirname(__file__)), self._prefs_file)
    
    def _load_preferences(self) -> None:
        """从文件加载皮肤偏好"""
        file_path = self._get_prefs_file_path()
        if os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._preferences.update(data)
            except Exception:
                # 如果加载失败，使用默认值
                pass
    
    def _save_preferences(self) -> None:
        """保存皮肤偏好到文件"""
        file_path = self._get_prefs_file_path()
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(self._preferences, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save skin preferences: {e}")
    
    def get_skin(self, player_name: str = "P1") -> str:
        """获取指定玩家的皮肤名称"""
        return self._preferences.get(player_name, "green")
    
    def set_skin(self, player_name: str, skin_name: str) -> None:
        """设置指定玩家的皮肤"""
        self._preferences[player_name] = skin_name
        self._save_preferences()
