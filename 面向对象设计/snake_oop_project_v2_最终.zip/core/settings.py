from __future__ import annotations
from dataclasses import dataclass
from core.types import SpeedSetting


@dataclass(frozen=True)
class GameSettings:
    width: int = 26
    height: int = 18
    mode: str = "single"
    time_limit_sec: int = 60
    two_player_time_limit_sec: int = 60
    speed: SpeedSetting = SpeedSetting.NORMAL
    enable_moving_obstacle: bool = True
    enable_mountain: bool = True
    enable_swamp: bool = True
    difficulty: str = "hard"
