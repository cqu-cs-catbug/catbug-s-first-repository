from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Tuple


@dataclass(frozen=True)
class Position:
    x: int
    y: int

    def __add__(self, other: Tuple[int, int]) -> "Position":
        dx, dy = other
        return Position(self.x + dx, self.y + dy)


class Direction(Enum):
    UP = (0, -1)
    DOWN = (0, 1)
    LEFT = (-1, 0)
    RIGHT = (1, 0)

    @property
    def delta(self) -> Tuple[int, int]:
        return self.value

    def is_opposite(self, other: "Direction") -> bool:
        return (self.delta[0] + other.delta[0] == 0) and (self.delta[1] + other.delta[1] == 0)


class SpeedSetting(Enum):
    SLOW = 140
    NORMAL = 100
    FAST = 70

    @property
    def tick_ms(self) -> int:
        return int(self.value)


class TerrainType(Enum):
    PLAIN = 0
    MOUNTAIN = 1  # blocked
    SWAMP = 2     # passable but slows
