from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class ColorPalette:
    """表示蛇的颜色特征"""
    name: str  # 颜色名称，如"green", "blue", "red"
    display_name: str  # 显示名称，如"绿色经典", "蓝色经典", "红色经典"
    head_color: str  # 头部颜色
    body_color: str  # 身体颜色
