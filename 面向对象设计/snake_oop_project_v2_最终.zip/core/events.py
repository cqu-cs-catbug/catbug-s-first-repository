from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, DefaultDict, Dict, List
from collections import defaultdict


EventHandler = Callable[[Dict[str, Any]], None]


class EventBus:
    """A tiny Observer/Publish-Subscribe hub."""

    def __init__(self) -> None:
        self._subs: DefaultDict[str, List[EventHandler]] = defaultdict(list)

    def subscribe(self, event_name: str, handler: EventHandler) -> None:
        self._subs[event_name].append(handler)

    def emit(self, event_name: str, payload: Dict[str, Any] | None = None) -> None:
        payload = payload or {}
        for h in list(self._subs.get(event_name, [])):
            h(payload)
