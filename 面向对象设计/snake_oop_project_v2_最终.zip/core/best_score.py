from __future__ import annotations
import json
import os
from typing import Dict, Optional


class BestScoreManager:
    """
    成绩记录管理类，用于记录和管理不同游戏模式下的最好成绩
    
    支持的游戏模式：
    - single: 单人模式
    - timed: 限时模式
    - two: 双人模式
    - two_timed: 双人限时模式
    """
    
    # 支持的游戏模式
    SUPPORTED_MODES = ["single", "timed", "two", "two_timed"]
    
    def __init__(self, game_mode: str = "single") -> None:
        """
        初始化方法
        
        Args:
            game_mode: 游戏模式，默认为单人模式
        
        Raises:
            ValueError: 如果游戏模式不支持
        """
        if game_mode not in self.SUPPORTED_MODES:
            raise ValueError(f"不支持的游戏模式: {game_mode}")
        
        self.game_mode: str = game_mode
        self.best_scores: Dict[str, Dict[str, int]] = {
            "single": {"P1": 0},
            "timed": {"P1": 0},
            "two": {"P1": 0, "P2": 0},
            "two_timed": {"P1": 0, "P2": 0}
        }
        
        # 设置本地存储路径
        self.storage_path: str = self._get_storage_path()
        
        # 尝试从本地加载已保存的成绩
        self.load_from_file()
    
    def _get_storage_path(self) -> str:
        """
        获取本地存储文件的路径
        
        Returns:
            本地存储文件的绝对路径
        """
        script_dir = os.path.dirname(os.path.abspath(__file__))
        storage_dir = os.path.join(script_dir, "..", "assets")
        
        # 确保存储目录存在
        if not os.path.exists(storage_dir):
            os.makedirs(storage_dir)
        
        return os.path.join(storage_dir, "best_scores.json")
    
    def record_score(self, player_id: str, score: int) -> bool:
        """
        记录玩家成绩，比较并更新最好成绩
        
        Args:
            player_id: 玩家ID，如 "P1" 或 "P2"
            score: 当前玩家的成绩
        
        Returns:
            是否更新了最好成绩
        
        Raises:
            ValueError: 如果玩家ID无效
        """
        # 验证玩家ID
        if player_id not in ["P1", "P2"]:
            raise ValueError(f"无效的玩家ID: {player_id}")
        
        # 验证玩家ID是否适用于当前游戏模式
        if self.game_mode in ["single", "timed"] and player_id != "P1":
            raise ValueError(f"当前游戏模式 {self.game_mode} 只支持玩家 P1")
        
        # 比较并更新最好成绩
        # 检查玩家是否已经有记录
        has_record = player_id in self.best_scores[self.game_mode]
        current_best = self.best_scores[self.game_mode].get(player_id, 0)
        
        if score > current_best:
            self.best_scores[self.game_mode][player_id] = score
            self.save_to_file()  # 自动保存到本地
            return True
        # 首次记录时，即使分数为0也返回True
        elif not has_record and score == 0:
            self.best_scores[self.game_mode][player_id] = 0
            self.save_to_file()  # 自动保存到本地
            return True
        return False
    
    def get_best_score(self, player_id: Optional[str] = None) -> Dict[str, int] | int:
        """
        获取最好成绩
        
        Args:
            player_id: 可选，玩家ID，如 "P1" 或 "P2"。如果不提供，返回当前模式下所有玩家的最好成绩
        
        Returns:
            如果提供了player_id，返回该玩家的最好成绩；否则返回当前模式下所有玩家的最好成绩
        
        Raises:
            ValueError: 如果玩家ID无效或不适用当前游戏模式
        """
        if player_id:
            # 验证玩家ID
            if player_id not in ["P1", "P2"]:
                raise ValueError(f"无效的玩家ID: {player_id}")
            
            # 验证玩家ID是否适用于当前游戏模式
            if self.game_mode in ["single", "timed"] and player_id != "P1":
                raise ValueError(f"当前游戏模式 {self.game_mode} 只支持玩家 P1")
            
            return self.best_scores[self.game_mode].get(player_id, 0)
        else:
            return self.best_scores[self.game_mode].copy()
    
    def save_to_file(self) -> None:
        """
        将最好成绩保存到本地存储
        
        Raises:
            IOError: 如果保存过程中出现错误
        """
        try:
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(self.best_scores, f, ensure_ascii=False, indent=2)
        except IOError as e:
            raise IOError(f"保存最好成绩失败: {e}")
    
    def load_from_file(self) -> None:
        """
        从本地存储加载已保存的最好成绩
        
        Raises:
            IOError: 如果加载过程中出现错误
        """
        if not os.path.exists(self.storage_path):
            return  # 文件不存在，使用默认值
        
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                loaded_scores = json.load(f)
                # 合并加载的数据，确保所有模式都有默认值
                for mode in self.SUPPORTED_MODES:
                    if mode in loaded_scores:
                        self.best_scores[mode].update(loaded_scores[mode])
        except (IOError, json.JSONDecodeError) as e:
            raise IOError(f"加载最好成绩失败: {e}")
    
    def set_game_mode(self, game_mode: str) -> None:
        """
        设置当前游戏模式
        
        Args:
            game_mode: 游戏模式
        
        Raises:
            ValueError: 如果游戏模式不支持
        """
        if game_mode not in self.SUPPORTED_MODES:
            raise ValueError(f"不支持的游戏模式: {game_mode}")
        
        self.game_mode = game_mode
    
    def get_all_scores(self) -> Dict[str, Dict[str, int]]:
        """
        获取所有模式下的最好成绩
        
        Returns:
            所有模式下的最好成绩副本
        """
        return {mode: scores.copy() for mode, scores in self.best_scores.items()}
