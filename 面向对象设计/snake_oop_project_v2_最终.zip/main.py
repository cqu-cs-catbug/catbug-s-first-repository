from __future__ import annotations
import argparse

from core.settings import GameSettings
from core.settings_manager import SettingsManager
from core.types import SpeedSetting
from ui.app import SnakeApp


def parse_args() -> GameSettings:
    parser = argparse.ArgumentParser(description="Snake OOP (Tkinter) - v2")
    parser.add_argument("--mode", choices=["single", "two", "timed", "two_timed"], default=None)
    parser.add_argument("--difficulty", choices=["easy", "normal", "hard"], default=None)
    parser.add_argument("--time", type=int, default=None, help="time limit (sec) for timed modes, default 60 (1 minute)")
    parser.add_argument("--speed", choices=["slow", "normal", "fast"], default=None)
    parser.add_argument("--width", type=int, default=None)
    parser.add_argument("--height", type=int, default=None)
    parser.add_argument("--no-moving-obstacle", action="store_true")
    args = parser.parse_args()

    # 首先尝试从文件加载保存的设置
    settings_manager = SettingsManager.instance()
    saved_settings = settings_manager.load_settings()
    
    # 使用命令行参数覆盖保存的设置（如果提供了参数）
    speed = saved_settings.speed
    if args.speed:
        speed = {"slow": SpeedSetting.SLOW, "normal": SpeedSetting.NORMAL, "fast": SpeedSetting.FAST}[args.speed]
    
    # 使用命令行参数或保存的设置值
    from dataclasses import replace
    settings = replace(
        saved_settings,
        width=args.width if args.width is not None else saved_settings.width,
        height=args.height if args.height is not None else saved_settings.height,
        mode=args.mode if args.mode is not None else saved_settings.mode,
        time_limit_sec=args.time if args.time is not None else saved_settings.time_limit_sec,
        speed=speed,
        enable_moving_obstacle=(not args.no_moving_obstacle) if args.no_moving_obstacle else saved_settings.enable_moving_obstacle,
        difficulty=args.difficulty if args.difficulty is not None else saved_settings.difficulty,
    )
    
    return settings


def main() -> None:
    settings = parse_args()
    app = SnakeApp(settings)
    app.run()


if __name__ == "__main__":
    main()
