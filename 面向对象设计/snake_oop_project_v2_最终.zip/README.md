# Snake OOP Project (Tkinter) - v2

## Why Tkinter (no pygame dependency)
This project uses only Python standard library (`tkinter`) so it runs on Windows/macOS/Linux without compiling SDL.

## Run
```bash
python -m pip install -U pip
python main.py
```

Optional CLI:
```bash
python main.py --mode two
python main.py --mode timed --time 60
python main.py --mode two_timed --time 90 --speed fast
```

## Controls
- Player 1: Arrow keys
- Player 2: WASD (only in 2P modes)
- Space: Pause/Resume
- R: Restart

## Features
- Modes (Strategy pattern): single / two-player / timed / two-player timed
- Terrain: mountain (blocked), swamp (slows)
- Items (Factory + polymorphism): Food, Shield, HalfLength
- Obstacles: static + moving obstacle example
- Skins (Singleton manager): color-based skins with safe fallback
- Event system (Observer): UI listens to engine events

## "AI辅助痕迹" (required by the assignment)
See `docs/AI_ASSISTED_NOTES.md`.
