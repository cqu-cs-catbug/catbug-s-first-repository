from __future__ import annotations
import time
from modes.base import GameMode


class TimedMode(GameMode):
    def __init__(self, time_limit_sec: int) -> None:
        # 使用传入的时间限制参数
        self.time_limit_sec = time_limit_sec

    @property
    def display_name(self) -> str:
        return f"限时模式 ({self.time_limit_sec}秒)"

    def check_game_over(self, engine: "GameEngine") -> bool:
        if not engine.snakes[0].alive:
            return True
        # 只有在游戏实际开始后才检查时间（time_started存在）
        if engine.state.time_started:
            elapsed = time.time() - engine.state.time_started
            return elapsed >= self.time_limit_sec
        return False

    def get_winner(self, engine: "GameEngine") -> str | None:
        return engine.snakes[0].name if engine.snakes[0].alive else None
