from __future__ import annotations
from modes.base import GameMode


class TwoPlayerMode(GameMode):
    @property
    def display_name(self) -> str:
        return "双人模式"

    def check_game_over(self, engine: "GameEngine") -> bool:
        return any(not s.alive for s in engine.snakes)

    def get_winner(self, engine: "GameEngine") -> str | None:
        alive = [s for s in engine.snakes if s.alive]
        if len(alive) == 1:
            return alive[0].name
        if len(alive) == 2:
            # if both alive but ended (unlikely), compare score
            return alive[0].name if alive[0].score >= alive[1].score else alive[1].name
        return None
