from __future__ import annotations
from modes.base import GameMode


class StandardMode(GameMode):
    @property
    def display_name(self) -> str:
        return "单人模式"

    def check_game_over(self, engine: "GameEngine") -> bool:
        return not engine.snakes[0].alive

    def get_winner(self, engine: "GameEngine") -> str | None:
        return engine.snakes[0].name if engine.snakes[0].alive else None
