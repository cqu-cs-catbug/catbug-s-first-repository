from __future__ import annotations
from abc import ABC, abstractmethod


class GameMode(ABC):
    """Strategy interface for different game rules."""

    @abstractmethod
    def check_game_over(self, engine: "GameEngine") -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_winner(self, engine: "GameEngine") -> str | None:
        raise NotImplementedError

    @property
    @abstractmethod
    def display_name(self) -> str:
        raise NotImplementedError
