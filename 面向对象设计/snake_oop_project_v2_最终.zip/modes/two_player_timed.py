from __future__ import annotations
import time
from modes.base import GameMode


class TwoPlayerTimedMode(GameMode):
    def __init__(self, time_limit_sec: int) -> None:
        self.time_limit_sec = time_limit_sec

    @property
    def display_name(self) -> str:
        return f"双人限时模式 ({self.time_limit_sec}秒)"

    def check_game_over(self, engine: "GameEngine") -> bool:
        if any(not s.alive for s in engine.snakes):
            return True
        # 只有在游戏实际开始后才检查时间（time_started存在）
        if engine.state.time_started:
            elapsed = time.time() - engine.state.time_started
            return elapsed >= self.time_limit_sec
        return False

    def get_winner(self, engine: "GameEngine") -> str | None:
        # If someone died, the other wins
        alive = [s for s in engine.snakes if s.alive]
        if len(alive) == 1:
            return alive[0].name
        # Time out: compare score
        if engine.snakes[0].score == engine.snakes[1].score:
            return None
        return engine.snakes[0].name if engine.snakes[0].score > engine.snakes[1].score else engine.snakes[1].name
