from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from core.types import Direction
from controllers.base import PlayerController


@dataclass
class KeyboardController(PlayerController):
    _requested: Optional[Direction] = None

    def set_requested_direction(self, direction: Direction) -> None:
        self._requested = direction

    def consume_requested_direction(self) -> Optional[Direction]:
        d = self._requested
        self._requested = None
        return d
