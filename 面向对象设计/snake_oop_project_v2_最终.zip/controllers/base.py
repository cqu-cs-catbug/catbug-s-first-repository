from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional

from core.types import Direction


class PlayerController(ABC):
    """Controller interface (optional in the doc; implemented for extensibility)."""

    @abstractmethod
    def set_requested_direction(self, direction: Direction) -> None:
        raise NotImplementedError

    @abstractmethod
    def consume_requested_direction(self) -> Optional[Direction]:
        raise NotImplementedError
