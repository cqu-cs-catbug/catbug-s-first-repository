from __future__ import annotations
import os
import json
import unittest
from core.best_score import BestScoreManager


class TestBestScoreManager(unittest.TestCase):
    """BestScoreManager类的单元测试"""
    
    def setUp(self) -> None:
        """测试前的设置"""
        # 创建一个测试用的BestScoreManager实例
        self.score_manager = BestScoreManager("single")
        # 保存原始存储路径，用于测试后恢复
        self.original_storage_path = self.score_manager._get_storage_path()
        # 创建一个临时存储路径，避免影响实际数据
        self.temp_storage_path = self.original_storage_path + ".test"
        self.score_manager.storage_path = self.temp_storage_path
        
    def tearDown(self) -> None:
        """测试后的清理"""
        # 删除临时存储文件
        if os.path.exists(self.temp_storage_path):
            os.remove(self.temp_storage_path)
    
    def test_initialization(self) -> None:
        """测试初始化方法"""
        # 测试默认初始化
        manager = BestScoreManager()
        self.assertEqual(manager.game_mode, "single")
        
        # 测试不同模式的初始化
        for mode in BestScoreManager.SUPPORTED_MODES:
            manager = BestScoreManager(mode)
            self.assertEqual(manager.game_mode, mode)
        
        # 测试无效模式的初始化
        with self.assertRaises(ValueError):
            BestScoreManager("invalid_mode")
    
    def test_record_score_single_mode(self) -> None:
        """测试单人模式下的成绩记录"""
        self.score_manager.set_game_mode("single")
        
        # 测试首次记录成绩
        result = self.score_manager.record_score("P1", 100)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 100)
        
        # 测试低于当前最好成绩的记录
        result = self.score_manager.record_score("P1", 50)
        self.assertFalse(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 100)
        
        # 测试高于当前最好成绩的记录
        result = self.score_manager.record_score("P1", 150)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 150)
        
        # 测试单人模式下尝试记录P2成绩
        with self.assertRaises(ValueError):
            self.score_manager.record_score("P2", 100)
    
    def test_record_score_timed_mode(self) -> None:
        """测试限时模式下的成绩记录"""
        self.score_manager.set_game_mode("timed")
        
        # 测试首次记录成绩
        result = self.score_manager.record_score("P1", 200)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 200)
        
        # 测试低于当前最好成绩的记录
        result = self.score_manager.record_score("P1", 150)
        self.assertFalse(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 200)
        
        # 测试限时模式下尝试记录P2成绩
        with self.assertRaises(ValueError):
            self.score_manager.record_score("P2", 200)
    
    def test_record_score_two_player_mode(self) -> None:
        """测试双人模式下的成绩记录"""
        self.score_manager.set_game_mode("two")
        
        # 测试记录P1成绩
        result = self.score_manager.record_score("P1", 300)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 300)
        
        # 测试记录P2成绩
        result = self.score_manager.record_score("P2", 250)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P2"), 250)
        
        # 测试更新P1成绩
        result = self.score_manager.record_score("P1", 350)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 350)
        
        # 测试更新P2成绩
        result = self.score_manager.record_score("P2", 300)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P2"), 300)
    
    def test_record_score_two_timed_mode(self) -> None:
        """测试双人限时模式下的成绩记录"""
        self.score_manager.set_game_mode("two_timed")
        
        # 测试记录P1成绩
        result = self.score_manager.record_score("P1", 400)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 400)
        
        # 测试记录P2成绩
        result = self.score_manager.record_score("P2", 350)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P2"), 350)
        
        # 测试更新P1成绩
        result = self.score_manager.record_score("P1", 450)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), 450)
        
        # 测试更新P2成绩
        result = self.score_manager.record_score("P2", 400)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P2"), 400)
    
    def test_get_best_score(self) -> None:
        """测试获取最好成绩的方法"""
        # 单人模式
        self.score_manager.set_game_mode("single")
        self.score_manager.record_score("P1", 100)
        
        # 获取单个玩家成绩
        p1_score = self.score_manager.get_best_score("P1")
        self.assertEqual(p1_score, 100)
        
        # 获取所有玩家成绩
        all_scores = self.score_manager.get_best_score()
        self.assertEqual(all_scores, {"P1": 100})
        
        # 双人模式
        self.score_manager.set_game_mode("two")
        self.score_manager.record_score("P1", 200)
        self.score_manager.record_score("P2", 150)
        
        # 获取单个玩家成绩
        p1_score = self.score_manager.get_best_score("P1")
        p2_score = self.score_manager.get_best_score("P2")
        self.assertEqual(p1_score, 200)
        self.assertEqual(p2_score, 150)
        
        # 获取所有玩家成绩
        all_scores = self.score_manager.get_best_score()
        self.assertEqual(all_scores, {"P1": 200, "P2": 150})
    
    def test_set_game_mode(self) -> None:
        """测试设置游戏模式的方法"""
        # 测试有效的游戏模式
        for mode in BestScoreManager.SUPPORTED_MODES:
            self.score_manager.set_game_mode(mode)
            self.assertEqual(self.score_manager.game_mode, mode)
        
        # 测试无效的游戏模式
        with self.assertRaises(ValueError):
            self.score_manager.set_game_mode("invalid_mode")
    
    def test_save_and_load(self) -> None:
        """测试保存和加载功能"""
        # 记录一些成绩
        self.score_manager.set_game_mode("single")
        self.score_manager.record_score("P1", 100)
        
        self.score_manager.set_game_mode("timed")
        self.score_manager.record_score("P1", 200)
        
        self.score_manager.set_game_mode("two")
        self.score_manager.record_score("P1", 300)
        self.score_manager.record_score("P2", 250)
        
        # 保存成绩到临时文件
        self.score_manager.save_to_file()
        
        # 验证文件已创建
        self.assertTrue(os.path.exists(self.temp_storage_path))
        
        # 创建一个新的实例，测试加载功能
        new_manager = BestScoreManager()
        new_manager.storage_path = self.temp_storage_path
        new_manager.load_from_file()
        
        # 验证加载的成绩
        new_manager.set_game_mode("single")
        self.assertEqual(new_manager.get_best_score("P1"), 100)
        
        new_manager.set_game_mode("timed")
        self.assertEqual(new_manager.get_best_score("P1"), 200)
        
        new_manager.set_game_mode("two")
        self.assertEqual(new_manager.get_best_score("P1"), 300)
        self.assertEqual(new_manager.get_best_score("P2"), 250)
    
    def test_get_all_scores(self) -> None:
        """测试获取所有成绩的方法"""
        # 记录一些成绩
        self.score_manager.set_game_mode("single")
        self.score_manager.record_score("P1", 100)
        
        self.score_manager.set_game_mode("two")
        self.score_manager.record_score("P1", 200)
        self.score_manager.record_score("P2", 150)
        
        # 获取所有成绩
        all_scores = self.score_manager.get_all_scores()
        
        # 验证结果
        self.assertIsInstance(all_scores, dict)
        self.assertIn("single", all_scores)
        self.assertIn("two", all_scores)
        self.assertEqual(all_scores["single"]["P1"], 100)
        self.assertEqual(all_scores["two"]["P1"], 200)
        self.assertEqual(all_scores["two"]["P2"], 150)
        # 验证返回的是副本，修改不会影响原始数据
        all_scores["single"]["P1"] = 500
        self.assertEqual(self.score_manager.get_best_score("P1"), 200)  # 仍为双人模式下的成绩
    
    def test_invalid_player_id(self) -> None:
        """测试无效玩家ID的处理"""
        # 测试无效的玩家ID
        with self.assertRaises(ValueError):
            self.score_manager.record_score("P3", 100)
        
        with self.assertRaises(ValueError):
            self.score_manager.get_best_score("P3")
    
    def test_mode_mismatch(self) -> None:
        """测试游戏模式不匹配的处理"""
        # 单人模式下尝试记录P2成绩
        self.score_manager.set_game_mode("single")
        with self.assertRaises(ValueError):
            self.score_manager.record_score("P2", 100)
        
        with self.assertRaises(ValueError):
            self.score_manager.get_best_score("P2")
    
    def test_edge_cases(self) -> None:
        """测试边缘情况"""
        # 记录0分（初始分数已为0，不应更新）
        self.score_manager.set_game_mode("single")
        result = self.score_manager.record_score("P1", 0)
        self.assertFalse(result)  # 初始分数已为0，不应更新
        
        # 记录负数分数
        result = self.score_manager.record_score("P1", -50)
        self.assertFalse(result)  # 负数分数不应更新
        
        # 记录非常高的分数
        very_high_score = 10**9
        result = self.score_manager.record_score("P1", very_high_score)
        self.assertTrue(result)
        self.assertEqual(self.score_manager.get_best_score("P1"), very_high_score)


if __name__ == "__main__":
    unittest.main()
