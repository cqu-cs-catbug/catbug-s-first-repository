from __future__ import annotations
from dataclasses import dataclass
from abc import ABC, abstractmethod

from core.types import Position


@dataclass
class Item(ABC):
    position: Position
    points: int = 0

    @abstractmethod
    def apply_effect(self, snake: "Snake", engine: "GameEngine") -> None:
        """Apply effect to the snake."""
        raise NotImplementedError
