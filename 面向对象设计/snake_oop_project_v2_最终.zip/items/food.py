from __future__ import annotations
from dataclasses import dataclass

from items.base import Item


@dataclass
class Food(Item):
    points: int = 10
    food_type: str = "yellow"

    def apply_effect(self, snake: "Snake", engine: "GameEngine") -> None:
        snake.grow(1)
        snake.score += self.points
        engine.events.emit("item_consumed", {"who": snake.name, "item": "Food", "score": snake.score})


@dataclass
class BlueFood(Food):
    points: int = 20
    food_type: str = "blue"
    spawn_time: float = 0.0  # 生成时间，用于计时

    def apply_effect(self, snake: "Snake", engine: "GameEngine") -> None:
        snake.grow(1)
        snake.score += self.points
        engine.events.emit("item_consumed", {"who": snake.name, "item": "BlueFood", "score": snake.score})
