from __future__ import annotations
from dataclasses import dataclass

from items.base import Item


@dataclass
class HalfLengthItem(Item):
    points: int = -5

    def apply_effect(self, snake: "Snake", engine: "GameEngine") -> None:
        # 道具物品的减半效果不受使用次数限制（这是道具效果，不是主动技能）
        old_length = len(snake.body)
        # 直接调用内部逻辑，不增加使用次数
        target = max(2, len(snake.body) // 2)
        while len(snake.body) > target:
            snake.body.pop()
        snake.score += self.points
        engine.events.emit("item_consumed", {"who": snake.name, "item": "HalfLength", "score": snake.score})
