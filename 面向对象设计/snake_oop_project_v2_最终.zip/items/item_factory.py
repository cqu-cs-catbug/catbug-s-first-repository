from __future__ import annotations
import random
from typing import Callable, Dict, List, Tuple, Type

from core.types import Position
from items.base import Item
from items.food import Food
from items.shield import ShieldItem
from items.half_length import HalfLengthItem


class ItemFactory:
    """Factory pattern: centralizes item creation."""

    def __init__(self) -> None:
        # 调整权重：食物占绝大多数，道具小概率出现
        self._registry: List[Tuple[Type[Item], int]] = [
            (Food, 85),  # 食物：85%概率
            (ShieldItem, 10),  # 护盾：10%概率
            (HalfLengthItem, 5),  # 减半长度：5%概率
        ]

    def register(self, item_cls: Type[Item], weight: int) -> None:
        self._registry.append((item_cls, max(1, weight)))

    def create_random(self, pos: Position) -> Item:
        classes = [c for c, _ in self._registry]
        weights = [w for _, w in self._registry]
        chosen = random.choices(classes, weights=weights, k=1)[0]
        return chosen(position=pos)
