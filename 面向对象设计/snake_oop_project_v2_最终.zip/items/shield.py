from __future__ import annotations
from dataclasses import dataclass

from items.base import Item


@dataclass
class ShieldItem(Item):
    points: int = 15

    def apply_effect(self, snake: "Snake", engine: "GameEngine") -> None:
        snake.grant_shield(1)
        snake.score += self.points
        engine.events.emit("item_consumed", {"who": snake.name, "item": "Shield", "score": snake.score})
