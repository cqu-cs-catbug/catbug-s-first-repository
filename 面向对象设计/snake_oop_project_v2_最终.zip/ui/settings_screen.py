from __future__ import annotations
from typing import Callable, Optional, Dict
import tkinter as tk

from core.settings import GameSettings
from core.types import SpeedSetting
from ui.base_screen import BaseScreen
from ui.button import Button
from ui.settings_components import ToggleSwitch, Slider
from ui.theme import ThemeManager


class SettingsScreen(BaseScreen):
    """设置界面类"""
    
    def __init__(
        self,
        canvas: tk.Canvas,
        width: int,
        height: int,
        settings: GameSettings,
        on_complete: Callable[[GameSettings], None],
    ) -> None:
        super().__init__(canvas, width, height)
        self.settings = settings
        self.on_complete = on_complete
        
        # 当前设置值（可修改的副本）
        self.current_settings = {
            'enable_mountain': getattr(settings, 'enable_mountain', True),
            'enable_swamp': getattr(settings, 'enable_swamp', True),
            'enable_moving_obstacle': settings.enable_moving_obstacle,
            'width': settings.width,
            'height': settings.height,
            'time_limit_sec': settings.time_limit_sec,
            'two_player_time_limit_sec': getattr(settings, 'two_player_time_limit_sec', 60),
        }
        
        # UI组件
        self.toggles: Dict[str, ToggleSwitch] = {}
        self.sliders: Dict[str, Slider] = {}
        self.save_button: Optional[Button] = None
        self.reset_button: Optional[Button] = None
        self.back_button: Optional[Button] = None
        
        # 拖动相关
        self.dragging_slider: Optional[Slider] = None  # 当前正在拖动的滑动条
        
        # 滚动相关
        self.scroll_offset = 0  # 滚动偏移量（像素）
        self.min_scroll = 0  # 最小滚动值
        self.max_scroll = 0  # 最大滚动值（根据内容高度计算）
        self.scroll_speed = 40  # 增加滚动速度，每次滚动40像素
        self.total_content_height = 0  # 内容总高度
        
        # 主题管理器
        self.theme_manager = ThemeManager.instance()
    
    def render(self) -> None:
        """渲染设置界面"""
        self.clear()
        
        theme = self.theme_manager.get_current_theme()
        self.canvas.configure(bg=theme.bg_primary)
        
        center_x = self.width // 2
        start_y = 60
        spacing = 50
        
        # 计算总内容高度（移除了键位设置，内容高度减少）
        self.total_content_height = 650  # 重新估算内容高度
        self.max_scroll = max(0, self.total_content_height - (self.height - 150))
        
        # 限制滚动范围
        self.scroll_offset = max(self.min_scroll, min(self.max_scroll, self.scroll_offset))
        
        # 标题（固定在顶部，不随滚动移动）
        self.draw_text(
            "⚙️ 游戏设置",
            center_x, start_y,
            font=("Microsoft YaHei", 32, "bold"),
            fill=theme.text_primary,
            shadow=False,
        )
        
        # 应用滚动偏移量到当前y位置
        current_y = start_y + 80 - self.scroll_offset
        
        # 1. 地形设置
        self.draw_text(
            "地形设置",
            center_x, current_y,
            font=("Microsoft YaHei", 20, "bold"),
            fill=theme.text_primary,
            shadow=False,
        )
        current_y += 40
        
        # 山地地形开关（先删除旧的，再创建新的）
        if 'mountain' in self.toggles:
            self.toggles['mountain'].delete()
        mountain_toggle = ToggleSwitch(
            self.canvas,
            center_x, current_y,
            "山地地形",
            self.current_settings['enable_mountain'],
            lambda v: self._on_mountain_changed(v),
        )
        self.toggles['mountain'] = mountain_toggle
        current_y += spacing
        
        # 湿地地形开关（先删除旧的，再创建新的）
        if 'swamp' in self.toggles:
            self.toggles['swamp'].delete()
        swamp_toggle = ToggleSwitch(
            self.canvas,
            center_x, current_y,
            "湿地地形",
            self.current_settings['enable_swamp'],
            lambda v: self._on_swamp_changed(v),
        )
        self.toggles['swamp'] = swamp_toggle
        current_y += spacing + 20
        
        # 2. 游戏机制设置
        self.draw_text(
            "游戏机制",
            center_x, current_y,
            font=("Microsoft YaHei", 20, "bold"),
            fill=theme.text_primary,
            shadow=False,
        )
        current_y += 40
        
        # 移动障碍开关（先删除旧的，再创建新的）
        if 'obstacle' in self.toggles:
            self.toggles['obstacle'].delete()
        obstacle_toggle = ToggleSwitch(
            self.canvas,
            center_x, current_y,
            "移动障碍",
            self.current_settings['enable_moving_obstacle'],
            lambda v: self._on_obstacle_changed(v),
        )
        self.toggles['obstacle'] = obstacle_toggle
        current_y += spacing + 20
        
        # 3. 地图尺寸设置
        self.draw_text(
            "地图尺寸",
            center_x, current_y,
            font=("Microsoft YaHei", 20, "bold"),
            fill=theme.text_primary,
            shadow=False,
        )
        current_y += 40
        
        # 地图宽度滑动条（先删除旧的，再创建新的）
        if 'width' in self.sliders:
            self.sliders['width'].delete()
        width_slider = Slider(
            self.canvas,
            center_x, current_y,
            "宽度",
            10, 30,
            self.current_settings['width'],
            lambda v: self._on_width_changed(v),
        )
        self.sliders['width'] = width_slider
        current_y += spacing
        
        # 地图高度滑动条（先删除旧的，再创建新的）
        if 'height' in self.sliders:
            self.sliders['height'].delete()
        height_slider = Slider(
            self.canvas,
            center_x, current_y,
            "高度",
            10, 25,
            self.current_settings['height'],
            lambda v: self._on_height_changed(v),
        )
        self.sliders['height'] = height_slider
        current_y += spacing  # 从 spacing + 10 改为 spacing，使时间设置部分再上移
        
        # 4. 时间设置
        self.draw_text(
            "时间设置",
            center_x, current_y,
            font=("Microsoft YaHei", 20, "bold"),
            fill=theme.text_primary,
            shadow=False,
        )
        current_y += 40
        
        # 限时模式时间（先删除旧的，再创建新的）
        if 'time_limit' in self.sliders:
            self.sliders['time_limit'].delete()
        time_slider = Slider(
            self.canvas,
            center_x, current_y,
            "限时模式(秒)",
            10, 300,
            self.current_settings['time_limit_sec'],
            lambda v: self._on_time_limit_changed(v),
        )
        self.sliders['time_limit'] = time_slider
        current_y += spacing
        
        # 双人限时模式时间（先删除旧的，再创建新的）
        if 'two_time_limit' in self.sliders:
            self.sliders['two_time_limit'].delete()
        two_time_slider = Slider(
            self.canvas,
            center_x, current_y,
            "双人限时(秒)",
            10, 300,
            self.current_settings['two_player_time_limit_sec'],
            lambda v: self._on_two_time_limit_changed(v),
        )
        self.sliders['two_time_limit'] = two_time_slider
        current_y += spacing + 20
        
        # 按钮区域（固定在底部，不随滚动移动）
        button_y = self.height - 100
        button_width = 120
        button_height = 40
        button_gap = 40  # 按钮之间的边缘到边缘间距
        
        # 计算总宽度：3个按钮宽度 + 2个间距
        total_width = 3 * button_width + 2 * button_gap
        
        # 计算起始位置，确保整体居中
        save_btn_x = center_x - total_width // 2 + button_width // 2
        reset_btn_x = save_btn_x + button_width + button_gap
        back_btn_x = reset_btn_x + button_width + button_gap
        
        # 保存按钮
        self.save_button = Button(
            self.canvas,
            save_btn_x, button_y,
            width=button_width, height=button_height,
            text="✓ 保存设置",
            on_click=self._on_save,
            font= ("Microsoft YaHei", 14, "bold"),
            normal_color=theme.button_normal,
            hover_color=theme.button_hover,
            text_color=theme.button_text,
            border_color=theme.button_border,
        )
        
        # 重置按钮
        self.reset_button = Button(
            self.canvas,
            reset_btn_x, button_y,
            width=button_width, height=button_height,
            text="↻ 重置默认",
            on_click=self._on_reset,
            font= ("Microsoft YaHei", 14),
            normal_color="#dc2626",
            hover_color="#ef4444",
            text_color="#ffffff",
            border_color="#b91c1c",
        )
        
        # 返回按钮
        self.back_button = Button(
            self.canvas,
            back_btn_x, button_y,
            width=button_width, height=button_height,
            text="← 返回",
            on_click=self._on_back,
            font= ("Microsoft YaHei", 14),
            normal_color=theme.text_hint,
            hover_color=theme.text_secondary,
            text_color=theme.bg_primary,
            border_color=theme.text_hint,
        )
        
        # 提示文字
        self.draw_text(
            "💡 提示：点击开关切换选项，拖动滑动条调整数值",
            center_x, self.height - 30,
            font=("Microsoft YaHei", 11),
            fill=theme.text_hint,
            shadow=False,
        )
        
        # 显示滚动条（可选，用于可视化滚动位置）
        if self.max_scroll > 0:
            scrollbar_width = 8
            scrollbar_x = self.width - 20
            scrollbar_height = (self.height - 150) * (self.height - 150) / self.total_content_height
            scrollbar_y = 75 + (self.height - 150 - scrollbar_height) * self.scroll_offset / self.max_scroll
            
            # 背景轨道
            self.canvas.create_rectangle(
                scrollbar_x, 75,
                scrollbar_x + scrollbar_width, self.height - 75,
                fill=theme.bg_secondary,
                outline="",
                width=0
            )
            # 滚动滑块
            self.canvas.create_rectangle(
                scrollbar_x, scrollbar_y,
                scrollbar_x + scrollbar_width, scrollbar_y + scrollbar_height,
                fill=theme.text_secondary,
                outline="",
                width=0
            )
    
    def _on_mountain_changed(self, value: bool) -> None:
        """山地地形开关变化"""
        self.current_settings['enable_mountain'] = value
    
    def _on_swamp_changed(self, value: bool) -> None:
        """湿地地形开关变化"""
        self.current_settings['enable_swamp'] = value
    
    def _on_obstacle_changed(self, value: bool) -> None:
        """移动障碍开关变化"""
        self.current_settings['enable_moving_obstacle'] = value
    
    def _on_width_changed(self, value: int) -> None:
        """地图宽度变化"""
        # 确保值在有效范围内
        value = max(10, min(30, value))
        if self.current_settings['width'] != value:
            self.current_settings['width'] = value
    
    def _on_height_changed(self, value: int) -> None:
        """地图高度变化"""
        # 确保值在有效范围内
        value = max(10, min(25, value))
        if self.current_settings['height'] != value:
            self.current_settings['height'] = value
    
    def _on_time_limit_changed(self, value: int) -> None:
        """限时模式时间变化"""
        # 确保值在有效范围内
        value = max(10, min(300, value))
        if self.current_settings['time_limit_sec'] != value:
            self.current_settings['time_limit_sec'] = value
    
    def _on_two_time_limit_changed(self, value: int) -> None:
        """双人限时模式时间变化"""
        # 确保值在有效范围内
        value = max(10, min(300, value))
        if self.current_settings['two_player_time_limit_sec'] != value:
            self.current_settings['two_player_time_limit_sec'] = value
    
    def _on_save(self) -> None:
        """保存设置"""
        try:
            new_settings = self.get_settings()
            # 显示保存成功提示
            theme = self.theme_manager.get_current_theme()
            center_x = self.width // 2
            success_tag = f"success_msg_{id(self)}"
            
            # 清除旧提示
            self.canvas.delete(success_tag)
            
            # 绘制成功提示背景
            self.canvas.create_rectangle(
                center_x - 150, 100, center_x + 150, 140,
                fill="#10b981",
                outline="#ffffff",
                width=2,
                tags=success_tag
            )
            
            # 绘制成功提示文字
            self.canvas.create_text(
                center_x, 120,
                text="设置保存成功！",
                font=("Microsoft YaHei", 14, "bold"),
                fill="#ffffff",
                anchor="center",
                tags=success_tag
            )
            
            # 2秒后自动清除提示
            self.canvas.after(2000, lambda: self.canvas.delete(success_tag))
            
            # 调用回调函数，保存设置
            self.on_complete(new_settings)
        except Exception as e:
            # 显示保存失败提示
            theme = self.theme_manager.get_current_theme()
            center_x = self.width // 2
            error_tag = f"error_msg_{id(self)}"
            
            # 清除旧提示
            self.canvas.delete(error_tag)
            
            # 绘制失败提示背景
            self.canvas.create_rectangle(
                center_x - 150, 100, center_x + 150, 140,
                fill="#dc2626",
                outline="#ffffff",
                width=2,
                tags=error_tag
            )
            
            # 绘制失败提示文字
            self.canvas.create_text(
                center_x, 120,
                text="设置保存失败！",
                font=("Microsoft YaHei", 14, "bold"),
                fill="#ffffff",
                anchor="center",
                tags=error_tag
            )
            
            # 2秒后自动清除提示
            self.canvas.after(2000, lambda: self.canvas.delete(error_tag))
    
    def _on_reset(self) -> None:
        """重置为默认设置"""
        default = GameSettings()
        self.current_settings = {
            'enable_mountain': default.enable_mountain,
            'enable_swamp': default.enable_swamp,
            'enable_moving_obstacle': default.enable_moving_obstacle,
            'width': default.width,
            'height': default.height,
            'time_limit_sec': default.time_limit_sec,
            'two_player_time_limit_sec': getattr(default, 'two_player_time_limit_sec', 60),
        }
        # 重新渲染界面
        self.render()
    
    def _on_back(self) -> None:
        """返回首页（不保存）"""
        self.on_complete(self.settings)  # 返回原设置
    
    def get_settings(self) -> GameSettings:
        """获取当前设置"""
        # 创建新的GameSettings对象
        # 注意：只包含GameSettings实际定义的字段
        from dataclasses import replace
        
        try:
            # 尝试使用replace，只包含GameSettings实际定义的字段
            new_settings = replace(
                self.settings,
                enable_mountain=self.current_settings['enable_mountain'],
                enable_swamp=self.current_settings['enable_swamp'],
                enable_moving_obstacle=self.current_settings['enable_moving_obstacle'],
                width=self.current_settings['width'],
                height=self.current_settings['height'],
                time_limit_sec=self.current_settings['time_limit_sec'],
                two_player_time_limit_sec=self.current_settings['two_player_time_limit_sec'],
            )
        except Exception as e:
            # 如果replace失败，创建新实例，只包含实际存在的字段
            new_settings = GameSettings(
                width=self.current_settings['width'],
                height=self.current_settings['height'],
                mode=self.settings.mode,
                time_limit_sec=self.current_settings['time_limit_sec'],
                two_player_time_limit_sec=self.current_settings['two_player_time_limit_sec'],
                speed=self.settings.speed,
                enable_moving_obstacle=self.current_settings['enable_moving_obstacle'],
                enable_mountain=self.current_settings['enable_mountain'],
                enable_swamp=self.current_settings['enable_swamp'],
                difficulty=self.settings.difficulty,
            )
        
        return new_settings
    
    def handle_key(self, key: str) -> Optional[str]:
        """处理键盘输入"""
        # 正常键盘处理
        if key == "Escape":
            return "start"
        return None
    
    def handle_click(self, x: int, y: int) -> Optional[str]:
        """处理鼠标点击"""
        # 检查底部固定按钮（不随滚动移动）
        if self.save_button and self.save_button.contains(x, y):
            self._on_save()
            return "start"
        
        if self.reset_button and self.reset_button.contains(x, y):
            self._on_reset()
            return None
        
        if self.back_button and self.back_button.contains(x, y):
            self._on_back()
            return "start"
        
        # 检查开关（应用滚动偏移量到点击位置）
        for toggle in self.toggles.values():
            if toggle.contains(x, y):
                toggle.toggle()
                return None
        
        # 检查滑动条（开始拖动）
        for slider in self.sliders.values():
            if slider.contains(x, y):
                self.dragging_slider = slider
                slider.set_value_from_x(x)
                return None
        
        return None
    
    def handle_motion(self, x: int, y: int) -> None:
        """处理鼠标移动"""
        # 更新按钮悬停状态
        if self.save_button:
            self.save_button.set_hover(self.save_button.contains(x, y))
        if self.reset_button:
            self.reset_button.set_hover(self.reset_button.contains(x, y))
        if self.back_button:
            self.back_button.set_hover(self.back_button.contains(x, y))
    
    def handle_drag(self, x: int, y: int) -> None:
        """处理鼠标拖动事件"""
        if self.dragging_slider:
            # 正在拖动滑动条，实时更新值
            self.dragging_slider.set_value_from_x(x)
        else:
            # 如果没有正在拖动的滑动条，检查是否应该开始拖动
            # 这可以处理鼠标在滑动条上按下后移出再移回的情况
            for slider in self.sliders.values():
                if slider.contains(x, y):
                    self.dragging_slider = slider
                    slider.set_value_from_x(x)
                    break
    
    def handle_release(self, x: int, y: int) -> None:
        """处理鼠标释放事件"""
        if self.dragging_slider:
            # 结束拖动，最后一次更新值
            self.dragging_slider.set_value_from_x(x)
            self.dragging_slider = None
    
    def handle_wheel(self, delta: int) -> None:
        """处理鼠标滚轮事件"""
        # delta > 0 表示向上滚动（减小偏移），delta < 0 表示向下滚动（增加偏移）
        if delta > 0:
            # 向上滚动
            self.scroll_offset -= self.scroll_speed
        else:
            # 向下滚动
            self.scroll_offset += self.scroll_speed
        
        # 重新渲染界面以应用新的滚动偏移
        self.render()
