from __future__ import annotations
from typing import Dict

from core.types import Direction
from controllers.keyboard import KeyboardController


class InputBinder:
    """Binds Tk key events to controllers."""

    def __init__(self, c1: KeyboardController, c2: KeyboardController | None = None) -> None:
        self.c1 = c1
        self.c2 = c2

        self._p1 = {
            "Up": Direction.UP,
            "Down": Direction.DOWN,
            "Left": Direction.LEFT,
            "Right": Direction.RIGHT,
        }
        self._p2 = {
            "w": Direction.UP,
            "s": Direction.DOWN,
            "a": Direction.LEFT,
            "d": Direction.RIGHT,
            "W": Direction.UP,
            "S": Direction.DOWN,
            "A": Direction.LEFT,
            "D": Direction.RIGHT,
        }

    def on_key(self, key: str) -> None:
        if key in self._p1:
            self.c1.set_requested_direction(self._p1[key])
        if self.c2 and key in self._p2:
            self.c2.set_requested_direction(self._p2[key])
