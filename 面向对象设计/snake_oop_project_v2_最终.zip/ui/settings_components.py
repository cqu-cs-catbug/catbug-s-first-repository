from __future__ import annotations
from typing import Callable, Optional
import tkinter as tk


class ToggleSwitch:
    """开关组件"""
    
    def __init__(
        self,
        canvas: tk.Canvas,
        x: int,
        y: int,
        label: str,
        initial_value: bool,
        on_change: Callable[[bool], None],
        width: int = 80,
        height: int = 30,
    ) -> None:
        self.canvas = canvas
        self.x = x
        self.y = y
        self.label = label
        self.value = initial_value
        self.on_change = on_change
        self.width = width
        self.height = height
        self.tag = f"toggle_{id(self)}"
        self.is_hovered = False
        self._render()
    
    def _render(self) -> None:
        """渲染开关"""
        self.canvas.delete(self.tag)
        
        # 背景框
        bg_color = "#4ade80" if self.value else "#9ca3af"
        x1 = self.x - self.width // 2
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2
        y2 = self.y + self.height // 2
        
        # 背景
        self.canvas.create_rectangle(
            x1, y1, x2, y2,
            fill=bg_color,
            outline="#ffffff",
            width=2,
            tags=self.tag
        )
        
        # 滑块
        slider_size = self.height - 6
        if self.value:
            slider_x = x2 - slider_size // 2 - 3
        else:
            slider_x = x1 + slider_size // 2 + 3
        
        self.canvas.create_oval(
            slider_x - slider_size // 2, self.y - slider_size // 2,
            slider_x + slider_size // 2, self.y + slider_size // 2,
            fill="#ffffff",
            outline="#000000",
            width=1,
            tags=self.tag
        )
        
        # 标签文字
        self.canvas.create_text(
            self.x - self.width // 2 - 80, self.y,
            text=self.label,
            font=("Microsoft YaHei", 12),
            fill="#ffffff",
            anchor="e",
            tags=self.tag
        )
        
        # 状态文字
        status_text = "开启" if self.value else "关闭"
        self.canvas.create_text(
            self.x + self.width // 2 + 10, self.y,
            text=status_text,
            font=("Microsoft YaHei", 10),
            fill="#ffffff",
            anchor="w",
            tags=self.tag
        )
    
    def contains(self, x: int, y: int) -> bool:
        """检查点是否在开关区域内"""
        x1 = self.x - self.width // 2 - 80
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2 + 60
        y2 = self.y + self.height // 2
        return x1 <= x <= x2 and y1 <= y <= y2
    
    def toggle(self) -> None:
        """切换开关状态"""
        self.value = not self.value
        self._render()
        self.on_change(self.value)
    
    def set_value(self, value: bool) -> None:
        """设置开关值"""
        if self.value != value:
            self.value = value
            self._render()
    
    def delete(self) -> None:
        """删除开关"""
        self.canvas.delete(self.tag)


class Slider:
    """滑动条组件"""
    
    def __init__(
        self,
        canvas: tk.Canvas,
        x: int,
        y: int,
        label: str,
        min_value: int,
        max_value: int,
        initial_value: int,
        on_change: Callable[[int], None],
        width: int = 200,
        height: int = 20,
    ) -> None:
        self.canvas = canvas
        self.x = x
        self.y = y
        self.label = label
        self.min_value = min_value
        self.max_value = max_value
        self.value = initial_value
        self.on_change = on_change
        self.width = width
        self.height = height
        self.tag = f"slider_{id(self)}"
        self.is_dragging = False
        self._render()
    
    def _render(self) -> None:
        """渲染滑动条"""
        self.canvas.delete(self.tag)
        
        # 计算滑块位置
        ratio = (self.value - self.min_value) / (self.max_value - self.min_value)
        slider_x = self.x - self.width // 2 + int(ratio * self.width)
        
        # 背景轨道
        track_x1 = self.x - self.width // 2
        track_x2 = self.x + self.width // 2
        self.canvas.create_rectangle(
            track_x1, self.y - self.height // 2,
            track_x2, self.y + self.height // 2,
            fill="#4a5568",
            outline="#ffffff",
            width=1,
            tags=self.tag
        )
        
        # 已填充部分
        self.canvas.create_rectangle(
            track_x1, self.y - self.height // 2,
            slider_x, self.y + self.height // 2,
            fill="#4ade80",
            outline="",
            tags=self.tag
        )
        
        # 滑块
        slider_size = self.height + 6
        self.canvas.create_oval(
            slider_x - slider_size // 2, self.y - slider_size // 2,
            slider_x + slider_size // 2, self.y + slider_size // 2,
            fill="#ffffff",
            outline="#000000",
            width=2,
            tags=self.tag
        )
        
        # 标签
        self.canvas.create_text(
            self.x - self.width // 2 - 80, self.y,
            text=self.label,
            font=("Microsoft YaHei", 12),
            fill="#ffffff",
            anchor="e",
            tags=self.tag
        )
        
        # 数值显示
        value_text = f"{self.value}"
        self.canvas.create_text(
            self.x + self.width // 2 + 30, self.y,
            text=value_text,
            font=("Microsoft YaHei", 12, "bold"),
            fill="#ffffff",
            anchor="w",
            tags=self.tag
        )
    
    def contains(self, x: int, y: int) -> bool:
        """检查点是否在滑动条区域内"""
        x1 = self.x - self.width // 2 - 80
        y1 = self.y - self.height // 2 - 10
        x2 = self.x + self.width // 2 + 60
        y2 = self.y + self.height // 2 + 10
        return x1 <= x <= x2 and y1 <= y <= y2
    
    def set_value_from_x(self, x: int) -> None:
        """根据X坐标设置值"""
        track_x1 = self.x - self.width // 2
        track_x2 = self.x + self.width // 2
        
        if x < track_x1:
            new_value = self.min_value
        elif x > track_x2:
            new_value = self.max_value
        else:
            ratio = (x - track_x1) / (track_x2 - track_x1)
            new_value = int(self.min_value + ratio * (self.max_value - self.min_value))
        
        if new_value != self.value:
            self.value = new_value
            self._render()
            self.on_change(self.value)
    
    def set_value(self, value: int) -> None:
        """设置滑动条值"""
        value = max(self.min_value, min(self.max_value, value))
        if self.value != value:
            self.value = value
            self._render()
    
    def delete(self) -> None:
        """删除滑动条"""
        self.canvas.delete(self.tag)


class KeyBindingButton:
    """键位绑定按钮"""
    
    def __init__(
        self,
        canvas: tk.Canvas,
        x: int,
        y: int,
        label: str,
        key_name: str,
        on_click: Callable[[], None],
        width: int = 100,
        height: int = 35,
    ) -> None:
        self.canvas = canvas
        self.x = x
        self.y = y
        self.label = label
        self.key_name = key_name
        self.on_click = on_click
        self.width = width
        self.height = height
        self.tag = f"keybtn_{id(self)}"
        self.is_hovered = False
        self.is_waiting = False
        self._render()
    
    def _render(self) -> None:
        """渲染按钮"""
        self.canvas.delete(self.tag)
        
        bg_color = "#dc2626" if self.is_waiting else ("#4ade80" if self.is_hovered else "#4a5568")
        
        x1 = self.x - self.width // 2
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2
        y2 = self.y + self.height // 2
        
        self.canvas.create_rectangle(
            x1, y1, x2, y2,
            fill=bg_color,
            outline="#ffffff",
            width=2,
            tags=self.tag
        )
        
        # 标签
        self.canvas.create_text(
            self.x - self.width // 2 - 60, self.y,
            text=self.label,
            font=("Microsoft YaHei", 11),
            fill="#ffffff",
            anchor="e",
            tags=self.tag
        )
        
        # 键名
        key_text = "按任意键..." if self.is_waiting else self.key_name
        self.canvas.create_text(
            self.x, self.y,
            text=key_text,
            font=("Microsoft YaHei", 10, "bold"),
            fill="#ffffff",
            anchor="center",
            tags=self.tag
        )
    
    def contains(self, x: int, y: int) -> bool:
        """检查点是否在按钮区域内"""
        x1 = self.x - self.width // 2 - 60
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2
        y2 = self.y + self.height // 2
        return x1 <= x <= x2 and y1 <= y <= y2
    
    def click(self) -> None:
        """点击按钮"""
        self.is_waiting = True
        self._render()
        self.on_click()
    
    def set_key(self, key: str) -> None:
        """设置键位"""
        # 检查是否包含确认提示，如果包含则不修改waiting状态
        if "按Enter确认" in key:
            # 只更新显示，不改变等待状态
            self.key_name = key
        else:
            self.key_name = key
            self.is_waiting = False
        self._render()
    
    def cancel_waiting(self) -> None:
        """取消等待状态"""
        self.is_waiting = False
        self._render()
    
    def set_hover(self, hovered: bool) -> None:
        """设置悬停状态"""
        if self.is_hovered != hovered:
            self.is_hovered = hovered
            self._render()
    
    def delete(self) -> None:
        """删除按钮"""
        self.canvas.delete(self.tag)
