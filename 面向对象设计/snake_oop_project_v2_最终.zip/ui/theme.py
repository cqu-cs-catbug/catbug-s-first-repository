from __future__ import annotations
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class Theme:
    """主题类，定义界面的颜色、字体等视觉属性（体现面向对象的设计）"""
    name: str
    # 背景色
    bg_primary: str  # 主背景色
    bg_secondary: str  # 次要背景色
    bg_gradient_start: str  # 渐变起始色
    bg_gradient_end: str  # 渐变结束色
    
    # 文字颜色
    text_primary: str  # 主文字色
    text_secondary: str  # 次要文字色
    text_hint: str  # 提示文字色
    
    # 按钮颜色
    button_normal: str  # 按钮正常色
    button_hover: str  # 按钮悬停色
    button_text: str  # 按钮文字色
    button_border: str  # 按钮边框色
    
    # 选项颜色
    option_selected: str  # 选中选项色
    option_normal: str  # 未选中选项色
    option_hover: str  # 选项悬停色
    
    # 标题颜色
    title_primary: str  # 主标题色
    title_shadow: str  # 标题阴影色
    
    # 游戏界面颜色
    game_bg: str  # 游戏背景色
    game_plain: str  # 平原地形色
    game_mountain: str  # 山地色
    game_swamp: str  # 湿地色
    game_grid: str  # 网格线色


class ThemeManager:
    """主题管理器（单例模式），管理所有可用主题"""
    _instance: "ThemeManager" = None
    _current_theme: str = "dark"
    
    # 定义三套主题
    THEMES: Dict[str, Theme] = {
        "light": Theme(
            name="浅色模式",
            # 首页背景色与游戏界面一致（使用较深的浅绿色）
            bg_primary="#a8d5ba",  # 较深的浅绿色，与game_bg一致
            bg_secondary="#ffffff",
            bg_gradient_start="#9cc5a8",  # 较深的浅绿色渐变起始色
            bg_gradient_end="#90b896",  # 较深的浅绿色渐变结束色
            text_primary="#1a202c",  # 加深文字颜色，提高对比度
            text_secondary="#2d3748",  # 加深次要文字颜色
            text_hint="#4a5568",  # 加深提示文字颜色
            button_normal="#4a90e2",  # 从#0d6efd改为更柔和的蓝色
            button_hover="#357abd",  # 从#0b5ed7改为更柔和的蓝色
            button_text="#ffffff",
            button_border="#2c5aa0",  # 从#0a58ca改为更柔和的蓝色
            option_selected="#4a90e2",  # 从#0d6efd改为更柔和的蓝色
            option_normal="#2d3748",  # 加深未选中选项颜色
            option_hover="#4a5568",  # 加深悬停选项颜色
            title_primary="#2d3748",  # 加深标题颜色
            title_shadow="#1a202c",  # 加深标题阴影
            # 游戏界面颜色（使用较深的浅绿色）
            game_bg="#a8d5ba",  # 较深的浅绿色，与首页一致
            game_plain="#8fb89d",  # 较深的平原绿色
            game_mountain="#5a4b42",  # 从#6b5b52加深山地色
            game_swamp="#1ea8a8",  # 从#2eb8b8加深湿地色
            game_grid="#9cc5a8",  # 较深的浅绿色网格线
        ),
        "dark": Theme(
            name="深色模式",
            bg_primary="#0f172a",
            bg_secondary="#1e293b",
            bg_gradient_start="#0f172a",
            bg_gradient_end="#1e1b4b",
            text_primary="#ffffff",  # 优化：从#f1f5f9改为纯白色，更明显
            text_secondary="#e2e8f0",  # 优化：从#cbd5e1改为更亮的颜色
            text_hint="#cbd5e1",  # 优化：从#94a3b8改为更亮的颜色
            button_normal="#e94560",
            button_hover="#ff6b8a",
            button_text="#ffffff",
            button_border="#c73650",
            option_selected="#10b981",
            option_normal="#f1f5f9",  # 优化：从#e5e7eb改为更亮的颜色
            option_hover="#cbd5e1",  # 优化：从#94a3b8改为更亮的颜色
            title_primary="#60a5fa",  # 优化：从#0ea5e9改为更亮的蓝色
            title_shadow="#000000",
            game_bg="#1a1a2e",
            game_plain="#4a7c59",
            game_mountain="#6b5b52",
            game_swamp="#2eb8b8",
            game_grid="#2a4a6f",
        ),
    }
    
    @classmethod
    def instance(cls) -> "ThemeManager":
        """获取主题管理器单例"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def get_theme(self, name: str = None) -> Theme:
        """获取指定主题，默认返回当前主题"""
        if name is None:
            name = self._current_theme
        return self.THEMES.get(name, self.THEMES["dark"])
    
    def set_theme(self, name: str) -> None:
        """设置当前主题"""
        if name in self.THEMES:
            self._current_theme = name
    
    def get_current_theme(self) -> Theme:
        """获取当前主题"""
        return self.get_theme(self._current_theme)
    
    def list_themes(self) -> Dict[str, str]:
        """列出所有可用主题"""
        return {k: v.name for k, v in self.THEMES.items()}
