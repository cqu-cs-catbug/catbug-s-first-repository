from __future__ import annotations
from typing import Any, Callable, Dict, List, Optional
import tkinter as tk
import json
import os
from datetime import datetime

from ui.base_screen import BaseScreen
from core.score_manager import ScoreManager
from ui.button import Button, ClickableOption


class EndScreen(BaseScreen):
    """结束界面类，负责显示游戏结果和统计信息"""

    def __init__(
        self,
        canvas: tk.Canvas,
        width: int,
        height: int,
        on_restart: Callable[[], None],
        on_menu: Callable[[], None],
    ) -> None:
        super().__init__(canvas, width, height)
        self.on_restart = on_restart
        self.on_menu = on_menu
        self.game_result: Dict[str, Any] = {}
        self.selected_option = 0  # 0: 重新开始, 1: 返回菜单
        self.menu_options: List[ClickableOption] = []
        self.restart_button: Optional[Button] = None
        self.menu_button: Optional[Button] = None
        # 缓存画布尺寸，避免每帧查询导致闪烁
        self._cached_canvas_width = None
        self._cached_canvas_height = None

    def set_result(self, result: Dict[str, Any]) -> None:
        """设置游戏结果数据"""
        self.game_result = result
        self.selected_option = 0  # 重置选择

    def render(self) -> None:
        """渲染结束界面"""
        self.clear()
        
        # 动态获取画布实际尺寸（确保全屏时正确居中）
        # 使用缓存的画布尺寸，避免每帧查询导致闪烁
        if self._cached_canvas_width is None or self._cached_canvas_height is None:
            # 首次获取或缓存失效时，更新缓存
            self.canvas.update_idletasks()
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            # 如果画布尺寸为1（未初始化），使用窗口尺寸
            if canvas_width <= 1 or canvas_height <= 1:
                root = self.canvas.winfo_toplevel()
                root.update_idletasks()
                canvas_width = root.winfo_width() or self.width
                canvas_height = (root.winfo_height() or self.height) - 20  # 减去状态栏高度
            self._cached_canvas_width = canvas_width
            self._cached_canvas_height = canvas_height
        else:
            # 使用缓存的尺寸
            canvas_width = self._cached_canvas_width
            canvas_height = self._cached_canvas_height
        
        # 更新尺寸
        self.width = canvas_width
        self.height = canvas_height
        
        # 使用主题系统
        from ui.theme import ThemeManager
        theme = ThemeManager.instance().get_current_theme()
        
        # 根据主题选择文字颜色（浅色模式下使用更深的颜色以提高对比度）
        is_light_mode = theme.name == "浅色模式"
        
        # 标题颜色：浅色模式下使用更深的颜色
        if is_light_mode:
            title_winner_color = "#d97706"  # 深橙色，在浅绿色背景上更清晰
            title_game_over_color = "#dc2626"  # 深红色，在浅绿色背景上更清晰
            score_label_color = "#c02626"  # 深红色，在浅绿色背景上更清晰
            text_primary_color = "#1a202c"  # 更深的黑色，提高对比度
            text_secondary_color = "#2d3748"  # 更深的灰色，提高对比度
        else:
            title_winner_color = "#fbbf24"  # 金色，在深色背景上清晰
            title_game_over_color = "#ef4444"  # 红色，在深色背景上清晰
            score_label_color = "#e94560"  # 红色，在深色背景上清晰
            text_primary_color = theme.text_primary
            text_secondary_color = theme.text_secondary

        # 背景色（使用主题）
        self.canvas.configure(bg=theme.bg_primary)

        center_x = self.width // 2
        start_y = 80

        # 游戏结束标题
        winner = self.game_result.get("winner")
        mode = self.game_result.get("mode", "")
        message = self.game_result.get("message", "")

        if winner:
            title_text = f"🏆 {winner} 获胜！"
            title_color = title_winner_color
        else:
            title_text = "游戏结束"
            title_color = title_game_over_color

        self.draw_text(
            title_text,
            center_x,
            start_y,
            font=("Microsoft YaHei", 32, "bold"),
            fill=title_color,
            shadow=False,  # 添加阴影效果，确保在各种背景下清晰可见
        )

        # 模式信息（使用优化的颜色，带阴影）
        self.draw_text(
            f"模式: {mode}",
            center_x,
            start_y + 60,
            font=("Microsoft YaHei", 18),
            fill=text_secondary_color,
            shadow=False,
        )

        # 消息（如果有，使用优化的颜色，带阴影）
        if message:
            self.draw_text(
                message,
                center_x,
            start_y + 100,
                font=("Microsoft YaHei", 16),
                fill=text_primary_color,
                shadow=False,
            )

        # 分数统计
        scores = self.game_result.get("scores", {})
        if scores:
            score_y = start_y + 130  # 从150减少到130，优化间距
            self.draw_text(
                "最终分数:",
                center_x,
                score_y,
                font=("Microsoft YaHei", 20, "bold"),
                fill=score_label_color,
                shadow=False,  # 添加阴影效果
            )

            score_items_y = score_y + 40
            for i, (name, score) in enumerate(scores.items()):
                self.draw_text(
                    f"{name}: {score} 分",
                    center_x,
                    score_items_y + i * 35,
                    font=("Microsoft YaHei", 18),
                    fill=text_primary_color,
                    shadow=False,
                )
        
        # 显示最好成绩（在最终分数下方）
        best_score_y = score_items_y + len(scores) * 35 + 30 if scores else start_y + 200
        # 计算最好成绩区域的高度（根据模式）
        mode = self.game_result.get("mode", "")
        if "双人" in mode:
            # 双人模式：标题(35) + 2行成绩(30*2) = 95像素
            best_scores_height = 95
        else:
            # 单人模式：标题(35) + 1行成绩(30) = 65像素
            best_scores_height = 65
        
        self._render_best_scores(center_x, best_score_y, theme)
        
        # 计算分数区域结束位置（修复：根据实际内容高度计算）
        if scores:
            score_end_y = best_score_y + best_scores_height + 20  # 额外20像素间距
        else:
            score_end_y = start_y + 200

        # 选项菜单（使用按钮，更醒目的布局）
        # 确保按钮位置在内容下方，有足够间距
        options_y = score_end_y + 40  # 增加间距，从30改为40，确保不遮挡
        
        # 重新开始按钮（第一个选项）
        self.restart_button = Button(
            self.canvas,
            center_x,
            options_y,
            width=240,
            height=55,
            text="🔄 重新开始",
            on_click=self._on_restart_clicked,
            font=("Microsoft YaHei", 20, "bold"),
            normal_color="#e94560",
            hover_color="#ff6b8a",
            text_color="white",
            border_color="#c73650",
        )

        # 回到首页按钮（第二个选项）
        self.menu_button = Button(
            self.canvas,
            center_x,
            options_y + 70,
            width=240,
            height=55,
            text="🏠 回到首页",
            on_click=self._on_menu_clicked,
            font=("Microsoft YaHei", 20, "bold"),
            normal_color="#533483",
            hover_color="#7c5fb8",
            text_color="white",
            border_color="#3d2a5f",
        )

        # 操作提示（在按钮下方）
        hint_y = options_y + 150
        if hint_y + 40 < self.height:
            # 根据主题选择提示文字颜色
            if is_light_mode:
                hint_color = "#4c1d95"  # 深紫色，在浅绿色背景上更清晰
                hint_sub_color = "#374151"  # 深灰色，在浅绿色背景上更清晰
            else:
                hint_color = "#533483"  # 紫色，在深色背景上清晰
                hint_sub_color = "#666666"  # 灰色，在深色背景上清晰
            
            self.draw_text(
                "💡 提示：点击上方按钮选择操作",
                center_x,
                hint_y,
                font=("Microsoft YaHei", 12),
                fill=hint_color,
                shadow=False,  # 添加阴影以提高可读性
            )
            
            self.draw_text(
                "↑↓ 选择  |  Enter 确认  |  ESC 退出",
                center_x,
                hint_y + 22,
                font=("Microsoft YaHei", 10),
                fill=hint_sub_color,
                shadow=False,  # 添加阴影以提高可读性
            )

    def _on_restart_clicked(self) -> None:
        """重新开始按钮点击回调（由主应用处理，这里不直接调用）"""
        pass  # 实际处理在handle_click的返回值中

    def _on_menu_clicked(self) -> None:
        """返回主菜单按钮点击回调（由主应用处理，这里不直接调用）"""
        pass  # 实际处理在handle_click的返回值中

    def handle_key(self, key: str) -> Optional[str]:
        """处理键盘输入"""
        if key == "Up":
            self.selected_option = (self.selected_option - 1) % 2
            self.render()
            return None

        elif key == "Down":
            self.selected_option = (self.selected_option + 1) % 2
            self.render()
            return None

        elif key == "Return":  # Enter 键
            if self.selected_option == 0:
                # 重新开始 - 只返回状态，由主应用处理
                return "game"
            else:
                # 返回主菜单 - 只返回状态，由主应用处理
                return "start"

        elif key == "Escape":
            return "exit"

        return None

    def handle_click(self, x: int, y: int) -> Optional[str]:
        """处理鼠标点击"""
        # #region agent log
        def _log(hypothesis_id, location, message, data):
            try:
                with open(r'd:\Desktop\snake_oop_project_v2\.cursor\debug.log', 'a', encoding='utf-8') as f:
                    f.write(json.dumps({
                        'sessionId': 'debug-session',
                        'runId': 'run1',
                        'hypothesisId': hypothesis_id,
                        'location': location,
                        'message': message,
                        'data': data,
                        'timestamp': int(datetime.now().timestamp() * 1000)
                    }, ensure_ascii=False) + '\n')
            except: pass
        # #endregion
        
        # #region agent log
        _log('H', 'ui/end_screen.py:handle_click', 'Function entry', {
            'x': x, 'y': y,
            'restart_button_exists': self.restart_button is not None,
            'menu_button_exists': self.menu_button is not None
        })
        # #endregion
        
        if self.restart_button and self.restart_button.contains(x, y):
            # #region agent log
            _log('I', 'ui/end_screen.py:handle_click', 'Restart button clicked', {})
            # #endregion
            # 只返回状态，不直接调用回调，由主应用处理
            return "game"

        if self.menu_button and self.menu_button.contains(x, y):
            # #region agent log
            _log('J', 'ui/end_screen.py:handle_click', 'Menu button clicked', {})
            # #endregion
            # 只返回状态，不直接调用回调，由主应用处理
            return "start"

        # #region agent log
        _log('K', 'ui/end_screen.py:handle_click', 'No button clicked', {})
        # #endregion
        return None

    def handle_motion(self, x: int, y: int) -> None:
        """处理鼠标移动（悬停效果）"""
        if self.restart_button:
            self.restart_button.set_hover(self.restart_button.contains(x, y))

        if self.menu_button:
            self.menu_button.set_hover(self.menu_button.contains(x, y))
    
    def _render_best_scores(self, center_x: int, start_y: int, theme) -> None:
        """在结束界面显示最好成绩"""
        # 获取游戏模式和分数
        mode = self.game_result.get("mode", "")
        scores = self.game_result.get("scores", {})
        
        # 根据主题选择文字颜色（浅色模式下使用更深的颜色以提高对比度）
        is_light_mode = theme.name == "浅色模式"
        
        # 确定当前游戏模式
        current_mode = ""
        if "双人限时模式" in mode:
            current_mode = "two_timed"
        elif "限时模式" in mode:
            current_mode = "timed"
        elif "双人模式" in mode:
            current_mode = "two"
        else:
            current_mode = "single"
        
        # 获取成绩管理器
        score_manager = ScoreManager.instance()
        
        # 绘制最好成绩标题（根据主题选择颜色）
        if is_light_mode:
            best_score_title_color = "#d97706"  # 深橙色，在浅绿色背景上更清晰
            best_score_highlight_color = "#d97706"  # 深橙色，用于高亮
            best_score_normal_color = "#1a202c"  # 深黑色，提高对比度
        else:
            best_score_title_color = "#fbbf24"  # 金色，在深色背景上清晰
            best_score_highlight_color = "#fbbf24"  # 金色，用于高亮
            best_score_normal_color = theme.text_primary
        
        self.draw_text(
            "历史最好成绩:",
            center_x,
            start_y,
            font=("Microsoft YaHei", 18, "bold"),
            fill=best_score_title_color,
            shadow=False,
        )
        
        # 显示最好成绩值
        best_scores_y = start_y + 35
        if current_mode in ("two", "two_timed"):
            # 双人模式：显示两个玩家的最好成绩
            for i, player_name in enumerate(["P1", "P2"]):
                record = score_manager.get_record(current_mode, player_name)
                best_score = record.best_score if record else 0
                current_score = scores.get(player_name, 0)
                # 如果当前成绩等于最好成绩，高亮显示
                score_color = best_score_highlight_color if current_score == best_score and current_score > 0 else best_score_normal_color
                self.draw_text(
                    f"{player_name} 最好成绩: {best_score} 分",
                    center_x,
                    best_scores_y + i * 30,
                    font=("Microsoft YaHei", 16),
                    fill=score_color,
                    shadow=False,
                )
        else:
            # 单人模式：显示最好成绩
            record = score_manager.get_record(current_mode)
            best_score = record.best_score if record else 0
            current_score = max(scores.values()) if scores else 0
            # 如果当前成绩等于最好成绩，高亮显示
            score_color = best_score_highlight_color if current_score == best_score and current_score > 0 else best_score_normal_color
            self.draw_text(
                f"最好成绩: {best_score} 分",
                center_x,
                best_scores_y,
                font=("Microsoft YaHei", 16),
                fill=score_color,
                shadow=False,
            )
