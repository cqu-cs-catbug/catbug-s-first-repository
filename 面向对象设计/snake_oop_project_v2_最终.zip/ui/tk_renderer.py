from __future__ import annotations
import tkinter as tk
from typing import Any, Dict, Tuple

from core.types import TerrainType
from ui.theme import ThemeManager


class TkRenderer:
    """游戏渲染器 - 使用主题系统，优化性能"""
    
    def __init__(self, root: tk.Tk, cell_size: int = 30) -> None:
        self.root = root
        self.cell = cell_size
        # 主题管理器
        self.theme_manager = ThemeManager.instance()
        # 获取当前主题
        theme = self.theme_manager.get_current_theme()
        # 使用主题背景色初始化画布，设置可扩展
        self.canvas = tk.Canvas(root, width=1024, height=768, bg=theme.game_bg, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # 添加窗口大小变化事件处理
        self.root.bind('<Configure>', self._on_window_resize)
        
        # 性能优化：缓存渐变背景（避免每帧重绘）
        self._bg_cache = None
        self._bg_cache_theme = None
        # 缓存画布尺寸，避免每帧查询（只在窗口大小变化时更新）
        self._cached_canvas_width = None
        self._cached_canvas_height = None

    def _rect(self, x: int, y: int, color: str, outline_color: str = None) -> None:
        c = self.cell
        outline = outline_color if outline_color else ""
        self.canvas.create_rectangle(x*c, y*c, (x+1)*c, (y+1)*c, fill=color, outline=outline, width=1)

    def render(self, snap: Dict[str, Any], hud=None) -> None:
        """渲染游戏画面 - 性能优化版本，使用主题系统"""
        # 性能优化：只在必要时清空画布
        self.canvas.delete("all")
        if not snap.get("map"):
            return
        
        # 获取当前主题
        theme = self.theme_manager.get_current_theme()
        current_theme_name = self.theme_manager._current_theme
        
        w = snap["map"]["width"]
        h = snap["map"]["height"]
        
        # 动态调整cell_size，确保地图完整显示在画布上
        # 使用缓存的画布尺寸（避免每帧查询，消除闪烁）
        if self._cached_canvas_width is None or self._cached_canvas_height is None:
            # 首次获取或缓存失效时，更新缓存
            self.canvas.update_idletasks()
            canvas_width = self.canvas.winfo_width() or 1024
            canvas_height = self.canvas.winfo_height() or 768
            # 如果画布尺寸为1（未初始化），使用窗口尺寸
            if canvas_width <= 1 or canvas_height <= 1:
                self.root.update_idletasks()
                canvas_width = self.root.winfo_width() or 1024
                canvas_height = (self.root.winfo_height() or 768) - 20  # 减去状态栏高度
            self._cached_canvas_width = canvas_width
            self._cached_canvas_height = canvas_height
        else:
            # 使用缓存的尺寸
            canvas_width = self._cached_canvas_width
            canvas_height = self._cached_canvas_height
        
        # 计算最大允许的cell_size，确保地图不会超出画布边界
        max_cell_width = (canvas_width - 40) / w  # 减去40像素的边距
        max_cell_height = (canvas_height - 40) / h  # 减去40像素的边距
        c = min(self.cell, int(min(max_cell_width, max_cell_height)))  # 使用较小的值，确保地图完整显示
        c = max(c, 10)  # 确保cell_size不小于10像素，保证可读性
        
        # 性能优化：缓存渐变背景（主题变化时重新生成）
        if self._bg_cache is None or self._bg_cache_theme != current_theme_name:
            # 生成渐变背景缓存
            bg_tag = "bg_gradient"
            for i in range(canvas_height):
                ratio = i / canvas_height
                # 使用主题渐变色
                start_rgb = self._hex_to_rgb(theme.bg_gradient_start)
                end_rgb = self._hex_to_rgb(theme.bg_gradient_end)
                r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
                g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
                b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
                color = f"#{r:02x}{g:02x}{b:02x}"
                self.canvas.create_line(0, i, canvas_width, i, fill=color, width=1, tags=bg_tag)
            self._bg_cache = bg_tag
            self._bg_cache_theme = current_theme_name
        else:
            # 使用缓存的背景
            self.canvas.create_line(0, 0, 0, 0, tags=self._bg_cache)  # 占位，实际使用缓存
        
        # 绘制游戏区域背景（使用主题颜色）
        game_bg_x = (canvas_width - w*c) // 2
        game_bg_y = (canvas_height - h*c) // 2
        self.canvas.create_rectangle(
            game_bg_x, game_bg_y, game_bg_x + w*c, game_bg_y + h*c, 
            fill=theme.game_bg, outline=theme.text_secondary, width=2
        )

        # 绘制地形（先绘制平原区域，确保所有格子都有背景）
        terrain = snap["map"].get("terrain", {})
        terrain_positions = set(terrain.keys())
        
        # 计算游戏区域的偏移量（居中显示）
        offset_x = (canvas_width - w*c) // 2
        offset_y = (canvas_height - h*c) // 2
        
        # 绘制所有非地形区域（使用主题颜色）
        for y in range(h):
            for x in range(w):
                pos_key = (x, y)
                if pos_key not in terrain_positions:
                    # 平原区域使用主题颜色
                    self.canvas.create_rectangle(
                        offset_x + x*c, offset_y + y*c, 
                        offset_x + (x+1)*c, offset_y + (y+1)*c, 
                        fill=theme.game_plain, outline=theme.game_plain, width=1
                    )
        
        # 绘制地形（使用高区分度的颜色，更醒目）
        for (x, y), t in terrain.items():
            t = int(t)
            if t == TerrainType.MOUNTAIN.value:
                # 山地：使用主题颜色，统一渲染
                self.canvas.create_rectangle(
                    offset_x + x*c, offset_y + y*c, 
                    offset_x + (x+1)*c, offset_y + (y+1)*c, 
                    fill=theme.game_mountain, outline="", width=0
                )
            elif t == TerrainType.SWAMP.value:
                # 湿地：使用主题颜色，统一渲染
                self.canvas.create_rectangle(
                    offset_x + x*c, offset_y + y*c, 
                    offset_x + (x+1)*c, offset_y + (y+1)*c, 
                    fill=theme.game_swamp, outline="", width=0
                )

        # 障碍物（使用深色，与地形区分）
        for (x, y, dyn) in snap["map"].get("obstacles", []):
            if dyn:
                # 动态障碍物：紫色
                self.canvas.create_rectangle(
                    offset_x + x*c, offset_y + y*c, 
                    offset_x + (x+1)*c, offset_y + (y+1)*c, 
                    fill="#7c3aed", outline="#6d28d9"
                )
            else:
                # 静态障碍物：深灰色
                self.canvas.create_rectangle(
                    offset_x + x*c, offset_y + y*c, 
                    offset_x + (x+1)*c, offset_y + (y+1)*c, 
                    fill="#424242", outline="#212121"
                )

        # 物品（食物颜色区分，添加发光效果）
        for it in snap.get("items", []):
            x, y = it["pos"]
            typ = it["type"]
            
            # 确定食物类型和颜色
            if typ == "Food":
                # 黄色食物：明亮的黄色，带发光效果
                color = "#ffd700"  # 金色
                outline = "#ffc107"
                glow_color = "#fff9c4"
                # 添加外发光
                self.canvas.create_oval(
                    offset_x + x*c - 2, offset_y + y*c - 2, 
                    offset_x + (x+1)*c + 2, offset_y + (y+1)*c + 2, 
                    fill=glow_color, outline="", width=0
                )
            elif typ == "BlueFood":
                # 蓝色食物：明亮的蓝色，带发光效果
                color = "#2196f3"  # 蓝色
                outline = "#1976d2"
                glow_color = "#e3f2fd"
                # 添加外发光
                self.canvas.create_oval(
                    offset_x + x*c - 2, offset_y + y*c - 2, 
                    offset_x + (x+1)*c + 2, offset_y + (y+1)*c + 2, 
                    fill=glow_color, outline="", width=0
                )
            elif typ == "ShieldItem":
                # 护盾：明亮的蓝色，带发光效果
                color = "#42a5f5"
                outline = "#1e88e5"
                self.canvas.create_oval(
                    offset_x + x*c - 2, offset_y + y*c - 2, 
                    offset_x + (x+1)*c + 2, offset_y + (y+1)*c + 2, 
                    fill="#e3f2fd", outline="", width=0
                )
            elif typ == "HalfLengthItem":
                # 减半长度：明亮的红色，带发光效果
                color = "#ef5350"
                outline = "#e53935"
                self.canvas.create_oval(
                    offset_x + x*c - 2, offset_y + y*c - 2, 
                    offset_x + (x+1)*c + 2, offset_y + (y+1)*c + 2, 
                    fill="#ffebee", outline="", width=0
                )
            else:
                color = "#f59e0b"
                outline = None
            
            # 绘制物品主体（圆形，更美观）
            self.canvas.create_oval(
                offset_x + x*c + 2, offset_y + y*c + 2, 
                offset_x + (x+1)*c - 2, offset_y + (y+1)*c - 2, 
                fill=color, outline=outline, width=2
            )

        # 蛇（优化颜色和视觉效果，更醒目）
        for s in snap.get("snakes", []):
            body = s["body"]
            skin = s.get("skin", {})
            head_color = skin.get("head_color", "#10b981")  # 更鲜艳的绿色
            body_color = skin.get("body_color", "#059669")  # 更深的绿色
            # 获取体型相关属性
            head_size_multiplier = skin.get("head_size_multiplier", 1.0)
            body_size_multiplier = skin.get("body_size_multiplier", 1.0)
            if not s.get("alive", True):
                head_color = "#6b7280"
                body_color = "#9ca3af"

            for i, (x, y) in enumerate(body):
                if i == 0:
                    # 蛇头：根据体型属性调整大小
                    head_size = c * head_size_multiplier
                    # 计算调整后的位置，使蛇头居中
                    head_offset = (c - head_size) / 2
                    self.canvas.create_rectangle(
                        offset_x + x*c + head_offset, offset_y + y*c + head_offset, 
                        offset_x + (x+1)*c - head_offset, offset_y + (y+1)*c - head_offset, 
                        fill=head_color, outline="#ffffff", width=2
                    )
                    # 添加眼睛效果
                    eye_size = int(c // 5 * head_size_multiplier)
                    eye_offset = head_offset + c//4
                    self.canvas.create_oval(
                        offset_x + x*c + eye_offset, offset_y + y*c + eye_offset, 
                        offset_x + x*c + eye_offset + eye_size, offset_y + y*c + eye_offset + eye_size, 
                        fill="#ffffff", outline=""
                    )
                    self.canvas.create_oval(
                        offset_x + x*c + 3*c//4 - eye_size + head_offset, offset_y + y*c + eye_offset, 
                        offset_x + x*c + 3*c//4 + head_offset, offset_y + y*c + eye_offset + eye_size, 
                        fill="#ffffff", outline=""
                    )
                    # 眼睛瞳孔
                    pupil_size = eye_size // 2
                    self.canvas.create_oval(
                        offset_x + x*c + eye_offset + pupil_size//2, offset_y + y*c + eye_offset + pupil_size//2, 
                        offset_x + x*c + eye_offset + eye_size - pupil_size//2, offset_y + y*c + eye_offset + eye_size - pupil_size//2, 
                        fill="#000000", outline=""
                    )
                    self.canvas.create_oval(
                        offset_x + x*c + 3*c//4 - eye_size + pupil_size//2 + head_offset, offset_y + y*c + eye_offset + pupil_size//2, 
                        offset_x + x*c + 3*c//4 - pupil_size//2 + head_offset, offset_y + y*c + eye_offset + eye_size - pupil_size//2, 
                        fill="#000000", outline=""
                    )
                else:
                    # 蛇身：根据体型属性调整大小
                    body_size = c * body_size_multiplier
                    # 计算调整后的位置，使蛇身居中
                    body_offset = (c - body_size) / 2
                    # 蛇身：带渐变效果，更立体
                    # 使用与皮肤颜色匹配的轮廓色，而不是硬编码的绿色
                    outline_color = self._darken_color(body_color, 0.2)
                    self.canvas.create_rectangle(
                        offset_x + x*c + 1 + body_offset, offset_y + y*c + 1 + body_offset, 
                        offset_x + (x+1)*c - 1 - body_offset, offset_y + (y+1)*c - 1 - body_offset, 
                        fill=body_color, outline=outline_color, width=1
                    )
                    # 添加与皮肤颜色匹配的高光，使蛇身更有立体感
                    highlight_color = self._lighten_color(body_color, 0.3)
                    self.canvas.create_rectangle(
                        offset_x + x*c + 2 + body_offset, offset_y + y*c + 2 + body_offset, 
                        offset_x + x*c + c//3 - body_offset, offset_y + y*c + c//3 - body_offset, 
                        fill=highlight_color, outline="", width=0
                    )

        # 渲染成绩显示（右上角）
        self._render_scores(snap, hud, canvas_width, canvas_height, offset_x, w, c, theme)
        
        # 网格线（使用主题颜色）
        grid_color = theme.game_grid
        for x in range(w+1):
            self.canvas.create_line(
                offset_x + x*c, offset_y, 
                offset_x + x*c, offset_y + h*c, 
                fill=grid_color, width=1
            )
        for y in range(h+1):
            self.canvas.create_line(
                offset_x, offset_y + y*c, 
                offset_x + w*c, offset_y + y*c, 
                fill=grid_color, width=1
            )
        
        # 添加控制提示
        self._render_control_hints(snap, hud, offset_y, h, c, canvas_width, canvas_height, theme)
    
    def _on_window_resize(self, event: tk.Event) -> None:
        """窗口大小变化时的事件处理"""
        # 清空背景缓存，以便重新计算和绘制
        self._bg_cache = None
        self._bg_cache_theme = None
        # 更新缓存的画布尺寸（只在窗口大小变化时更新，避免闪烁）
        self.canvas.update_idletasks()
        canvas_width = self.canvas.winfo_width() or 1024
        canvas_height = self.canvas.winfo_height() or 768
        # 如果画布尺寸为1（未初始化），使用窗口尺寸
        if canvas_width <= 1 or canvas_height <= 1:
            self.root.update_idletasks()
            canvas_width = self.root.winfo_width() or 1024
            canvas_height = (self.root.winfo_height() or 768) - 20  # 减去状态栏高度
        self._cached_canvas_width = canvas_width
        self._cached_canvas_height = canvas_height
        
    def _hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """将十六进制颜色转换为RGB元组"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def _lighten_color(self, hex_color: str, factor: float) -> str:
        """将颜色变亮（用于高光效果）"""
        rgb = self._hex_to_rgb(hex_color)
        r = min(255, int(rgb[0] + (255 - rgb[0]) * factor))
        g = min(255, int(rgb[1] + (255 - rgb[1]) * factor))
        b = min(255, int(rgb[2] + (255 - rgb[2]) * factor))
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def _darken_color(self, hex_color: str, factor: float) -> str:
        """将颜色变暗（用于轮廓效果）"""
        rgb = self._hex_to_rgb(hex_color)
        r = max(0, int(rgb[0] - rgb[0] * factor))
        g = max(0, int(rgb[1] - rgb[1] * factor))
        b = max(0, int(rgb[2] - rgb[2] * factor))
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def _render_scores(self, snap: Dict[str, Any], hud, canvas_width: int, canvas_height: int, offset_x: int, w: int, c: int, theme) -> None:
        """在游戏界面右上角绘制最好成绩和实时成绩，确保与地图完全分离"""
        if not hud:
            return
        
        # 获取实时成绩（从snap中的snakes数据）
        current_scores = {}
        for s in snap.get("snakes", []):
            if s.get("alive", True):
                current_scores[s["name"]] = s.get("score", 0)
        
        # 获取最好成绩（从HUD）
        best_records = hud._best_records if hasattr(hud, '_best_records') else {}
        current_mode = hud._current_mode if hasattr(hud, '_current_mode') else ""
        
        # 检查是否为限时模式，并获取剩余时间
        is_timed_mode = current_mode in ("timed", "two_timed")
        # 从snap中获取剩余时间，这是从引擎计算的准确时间
        remaining_time = snap.get("remaining_time")
        show_warning = False
        
        if is_timed_mode and remaining_time is not None:
            show_warning = remaining_time <= 10
        
        # 计算游戏地图的实际宽度
        map_width = w * c
        map_right_edge = offset_x + map_width
        
        # 计算显示位置（右上角，确保不与地图重叠且不溢出画布）
        padding = 15
        panel_width = 140  # 缩小宽度，避免与游戏界面重叠
        
        # 调整面板高度，根据是否为限时模式和是否显示道具次数
        # 基础高度：90（非限时模式）或110（限时模式）
        # 单人模式和限时模式增加30像素用于显示道具次数，双人模式不增加
        base_height = 110 if (is_timed_mode and remaining_time is not None) else 90
        if current_mode not in ("two", "two_timed"):
            panel_height = base_height + 30  # 增加高度以显示剩余道具次数
        else:
            panel_height = base_height  # 双人模式不显示道具次数
        
        # 计算起始x坐标，确保面板在地图右侧且不溢出画布
        # 优先将成绩栏放在地图右侧，如果空间不够则放在地图上方
        ideal_start_x = map_right_edge + 15  # 地图右侧15像素间距
        if ideal_start_x + panel_width + padding > canvas_width:
            # 如果右侧空间不够，放在地图上方（左上角）
            start_x = padding
            start_y = 15
        else:
            # 右侧有足够空间，放在地图右侧
            start_x = ideal_start_x
            start_y = 15  # 距离顶部15像素
        
        # 确保面板不会超出画布边界
        start_x = max(padding, min(start_x, canvas_width - panel_width - padding))
        
        # 绘制不透明背景框，确保与地图完全分离
        bg_color = theme.bg_secondary if hasattr(theme, 'bg_secondary') else "#2a2a2a"
        self.canvas.create_rectangle(
            start_x - 8, start_y - 8,
            start_x + panel_width, start_y + panel_height,
            fill=bg_color, outline=theme.text_secondary, width=1  # 缩小边框宽度
        )
        
        # 绘制标题
        title_font = ("Microsoft YaHei", 12, "bold")  # 缩小字体
        self.canvas.create_text(
            start_x + panel_width // 2, start_y + 12,
            text="成绩",
            font=title_font,
            fill=theme.text_primary,
            anchor="center"
        )
        
        # 绘制实时成绩
        score_y = start_y + 30
        current_font = ("Microsoft YaHei", 10, "bold")  # 缩小字体
        label_font = ("Microsoft YaHei", 9)  # 缩小字体
        
        # 实时成绩标签
        self.canvas.create_text(
            start_x + 5, score_y,
            text="实时:",
            font=label_font,
            fill=theme.text_secondary,
            anchor="w"
        )
        
        # 实时成绩值（根据模式显示）
        if current_mode in ("two", "two_timed"):
            # 双人模式：显示两个玩家的成绩，简化格式
            score_texts = []
            for player_name in ["P1", "P2"]:
                score = current_scores.get(player_name, 0)
                score_texts.append(f"{player_name}:{score}")
            score_text = " ".join(score_texts)
        else:
            # 单人模式：显示最高分
            score = max(current_scores.values()) if current_scores else 0
            score_text = str(score)
        
        # 绘制实时成绩值（不使用阴影效果）
        is_light_mode = theme.name == "浅色模式"
        if is_light_mode:
            # 浅色模式：直接绘制文字
            self.canvas.create_text(
                start_x + 40, score_y,
                text=score_text,
                font=current_font,
                fill="#16a34a",  # 深绿色，在浅色背景上更清晰
                anchor="w"
            )
        else:
            # 深色模式：直接绘制文字，不使用阴影
            self.canvas.create_text(
                start_x + 40, score_y,
                text=score_text,
                font=current_font,
                fill="#4ade80",  # 绿色，表示实时成绩
                anchor="w"
            )
        
        # 绘制剩余时间（限时模式）
        time_y = start_y + 50
        if is_timed_mode and remaining_time is not None:
            # 剩余时间标签
            self.canvas.create_text(
                start_x + 5, time_y,
                text="剩余:",
                font=label_font,
                fill=theme.text_secondary,
                anchor="w"
            )
            
            # 格式化剩余时间为MM:SS格式
            remaining = max(0, remaining_time)
            minutes = int(remaining // 60)
            seconds = int(remaining % 60)
            time_text = f"{minutes:02d}:{seconds:02d}"
            
            # 确定颜色（最后10秒使用警告颜色）
            if remaining <= 10:
                time_color = "#dc2626"  # 红色警告（深色模式）
                light_time_color = "#b91c1c"  # 红色警告（浅色模式）
            else:
                time_color = "#3b82f6"  # 蓝色（深色模式）
                light_time_color = "#2563eb"  # 蓝色（浅色模式）
            
            # 绘制剩余时间（不使用阴影效果）
            if is_light_mode:
                # 浅色模式：直接绘制文字
                self.canvas.create_text(
                    start_x + 40, time_y,
                    text=time_text,
                    font=current_font,
                    fill=light_time_color,
                    anchor="w"
                )
            else:
                # 深色模式：直接绘制文字，不使用阴影
                self.canvas.create_text(
                    start_x + 40, time_y,
                    text=time_text,
                    font=current_font,
                    fill=time_color,
                    anchor="w"
                )
        
        # 绘制最好成绩
        if is_timed_mode and remaining_time is not None:
            best_y = start_y + 70
        else:
            best_y = score_y + 25
        
        # 最好成绩标签
        self.canvas.create_text(
            start_x + 5, best_y,
            text="最好:",
            font=label_font,
            fill=theme.text_secondary,
            anchor="w"
        )
        
        # 最好成绩值（根据模式显示）
        if current_mode in ("two", "two_timed"):
            # 双人模式：显示两个玩家的最好成绩，简化格式
            best_texts = []
            for player_name in ["P1", "P2"]:
                record = best_records.get(player_name)
                if record:
                    best_texts.append(f"{player_name}:{record.best_score}")
                else:
                    best_texts.append(f"{player_name}:0")
            best_text = " ".join(best_texts)
        else:
            # 单人模式：显示最好成绩
            record = best_records.get("")
            best_score = record.best_score if record else 0
            best_text = str(best_score)
        
        # 绘制最好成绩值（不使用阴影效果）
        if is_light_mode:
            # 浅色模式：直接绘制文字
            self.canvas.create_text(
                start_x + 40, best_y,
                text=best_text,
                font=current_font,
                fill="#d97706",  # 深橙色，在浅色背景上更清晰
                anchor="w"
            )
        else:
            # 深色模式：直接绘制文字，不使用阴影
            self.canvas.create_text(
                start_x + 40, best_y,
                text=best_text,
                font=current_font,
                fill="#fbbf24",  # 金色，表示最好成绩
                anchor="w"
            )
        
        # 绘制剩余道具次数（Shift技能）- 仅在单人模式和限时模式下显示
        # 双人模式不显示道具剩余次数
        if current_mode not in ("two", "two_timed"):
            skill_y = best_y + 25
            # 剩余道具次数标签和数值一起绘制，确保数值在冒号后面
            label_text = "道具剩余:"
            
            # 获取每个玩家的剩余道具次数（单人模式和限时模式只有P1）
            snakes_list = [s for s in snap.get("snakes", []) if s.get("alive", True)]
            
            # 单人模式和限时模式：只显示P1的剩余次数
            if len(snakes_list) >= 1:
                s = snakes_list[0]
                uses = s.get("shrink_skill_uses", 0)
                remaining = max(0, 2 - uses)
                skill_text = str(remaining)
            else:
                skill_text = "0"
            
            # 先创建一个临时文本对象来测量标签宽度
            temp_id = self.canvas.create_text(0, 0, text=label_text, font=label_font, anchor="w")
            bbox = self.canvas.bbox(temp_id)
            self.canvas.delete(temp_id)
            
            if bbox:
                label_width = bbox[2] - bbox[0]  # 右边界 - 左边界
            else:
                # 如果无法测量，使用估算值（"道具剩余:"大约70像素）
                label_width = 70
            
            # 绘制标签
            self.canvas.create_text(
                start_x + 5, skill_y,
                text=label_text,
                font=label_font,
                fill=theme.text_secondary,
                anchor="w"
            )
            
            # 绘制剩余道具次数值（在冒号后面，紧跟着标签）
            value_x = start_x + 5 + label_width + 2  # 标签位置 + 标签宽度 + 2像素间距
            if is_light_mode:
                # 浅色模式：直接绘制文字
                self.canvas.create_text(
                    value_x, skill_y,
                    text=skill_text,
                    font=current_font,
                    fill="#7c3aed",  # 深紫色，在浅色背景上更清晰
                    anchor="w"
                )
            else:
                # 深色模式：直接绘制文字
                self.canvas.create_text(
                    value_x, skill_y,
                    text=skill_text,
                    font=current_font,
                    fill="#a78bfa",  # 紫色，表示道具次数
                    anchor="w"
                )
    
    def _render_control_hints(self, snap: Dict[str, Any], hud, offset_y: int, h: int, c: int, canvas_width: int, canvas_height: int, theme) -> None:
        """在游戏界面底部绘制控制提示，优化文本清晰度和可读性"""
        # 确定游戏模式（从HUD或snap中的snakes数量）
        is_multiplayer = False
        if hasattr(hud, '_current_mode') and hud._current_mode in ("two", "two_timed"):
            is_multiplayer = True
        elif len(snap.get("snakes", [])) >= 2:
            is_multiplayer = True
        
        # 根据游戏模式设置提示文本
        current_mode = hud._current_mode if hasattr(hud, '_current_mode') else ""
        
        if is_multiplayer:
            # 双人模式：不显示道具提示
            hint_text = "玩家1: 上下左右键 | 玩家2: WASD键 | 按空格暂停"
        else:
            # 单人模式和限时模式：显示道具提示和效果说明
            if current_mode == "timed":
                hint_text = "按动上下左右键控制移动 | 按空格暂停 | 按shift使用道具（蛇长度减半，每局2次）"
            else:
                # 单人模式
                hint_text = "按动上下左右键控制移动 | 按空格暂停 | 按shift使用道具（蛇长度减半，每局2次）"
        
        # 计算显示位置（游戏区域底部，确保不重叠且清晰可见）
        game_bottom = offset_y + h*c
        # 与地图底部的间距
        spacing = 25
        hint_y = game_bottom + spacing
        
        # 检查提示词是否会超出画布底部（留出至少20像素的底部边距）
        text_height = 15  # 估算文本高度
        if hint_y + text_height // 2 > canvas_height - 20:
            # 如果会超出，不显示提示词
            return
        
        # 设置字体和颜色（进一步缩小字体，去掉边框）
        hint_font = ("Microsoft YaHei", 10)  # 缩小到10号字体，去掉粗体
        text_color = theme.text_primary
        
        # 不使用阴影效果，直接绘制文字
        is_light_mode = theme.name == "浅色模式"
        
        if is_light_mode:
            # 浅色模式：使用更深的文字颜色以提高对比度
            text_color = "#1a202c"  # 深黑色，在浅色背景上更清晰
        else:
            # 深色模式：使用主题文字颜色
            text_color = theme.text_primary
        
        # 直接绘制文字，不使用阴影
        self.canvas.create_text(
            canvas_width // 2, hint_y,
            text=hint_text,
            font=hint_font,
            fill=text_color
        )