from __future__ import annotations
from typing import Callable, Dict, List, Optional
import tkinter as tk
import json
import os

from ui.base_screen import BaseScreen
from ui.button import Button
from ui.theme import ThemeManager
from skins.skin_manager import SkinManager
from core.skin_preferences import SkinPreferences


class SkinSelectScreen(BaseScreen):
    """皮肤选择界面类，提供多种皮肤选项供用户选择"""
    
    def __init__(
        self,
        canvas: tk.Canvas,
        width: int,
        height: int,
        on_complete: Callable[[], None],
        player_name: str = "P1",
    ) -> None:
        super().__init__(canvas, width, height)
        self.on_complete = on_complete
        self.player_name = player_name
        self.selected_skin = SkinPreferences.instance().get_skin(player_name)
        
        # 皮肤管理器
        self.skin_manager = SkinManager.instance()
        
        # 加载所有可用皮肤（修复：确保正确加载）
        self._load_skins()
        
        # 主题管理器
        self.theme_manager = ThemeManager.instance()
        
        # 加载体型和颜色选项
        self.body_types = self.skin_manager.get_all_body_types()
        self.color_palettes = self.skin_manager.get_all_color_palettes()
        
        # 解析当前选中的皮肤为颜色和体型组合
        self.selected_color, self.selected_body_type = self._parse_skin_combination(self.selected_skin)
        
        self.skin_buttons: List[Button] = []
        self.color_buttons: List[Button] = []
        self.body_type_buttons: List[Button] = []
        self.complete_button: Optional[Button] = None
        self.next_button: Optional[Button] = None
        self.prev_button: Optional[Button] = None
        self.back_button: Optional[Button] = None
    
    def _load_skins(self) -> None:
        """加载皮肤资源（修复：确保所有皮肤都能加载）"""
        # 如果已经加载，先重置状态（修复：允许重新加载）
        if self.skin_manager._loaded:
            # 如果已经加载但只有默认皮肤，尝试重新加载
            if len(self.skin_manager._skins) <= 3:
                self.skin_manager._loaded = False
                self.skin_manager._skins.clear()
        
        # 先注册默认皮肤作为后备
        self.skin_manager.register_default()
        
        # 尝试从文件加载
        skin_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "skins.json")
        try:
            if os.path.exists(skin_file):
                self.skin_manager.load_from_file(skin_file)
        except Exception:
            # 如果加载失败，使用默认皮肤
            pass
    
    def _parse_skin_combination(self, skin_name: str) -> tuple[str, str]:
        """解析皮肤名称为颜色和体型组合"""
        # 尝试解析组合名称：color_body_type
        parts = skin_name.split("_")
        if len(parts) == 2:
            color_name, body_type_name = parts
            return color_name, body_type_name
        
        # 如果无法解析，检查是否为单一颜色或单一体型
        if skin_name in self.skin_manager.get_all_color_palettes():
            return skin_name, "normal"
        
        if skin_name in self.skin_manager.get_all_body_types():
            return "green", skin_name
        
        # 默认返回绿色经典
        return "green", "normal"
    
    def render(self) -> None:
        """渲染皮肤选择界面"""
        self.clear()
        
        # 获取当前主题
        theme = self.theme_manager.get_current_theme()
        
        # 背景
        self.canvas.configure(bg=theme.bg_primary)
        
        # 优化渐变背景绘制：使用更少的线条和更粗的宽度，提升性能
        def hex_to_rgb(hex_color: str) -> tuple:
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        def rgb_to_hex(r: int, g: int, b: int) -> str:
            return f"#{r:02x}{g:02x}{b:02x}"
        
        start_rgb = hex_to_rgb(theme.bg_gradient_start)
        end_rgb = hex_to_rgb(theme.bg_gradient_end)
        
        # 使用更高效的方式绘制渐变：减少线条数量，使用更大的步长
        step = max(2, self.height // 150)
        for i in range(0, self.height, step):
            ratio = i / self.height if self.height > 0 else 0
            r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
            g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
            b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
            color = rgb_to_hex(r, g, b)
            # 绘制更粗的线条以填充间隙，确保没有空白
            line_width = step + 2
            self.canvas.create_line(0, i, self.width, i, fill=color, width=line_width)
        
        center_x = self.width // 2
        start_y = 50
        
        # 计算布局参数 - 响应式设计
        # 根据屏幕尺寸动态调整各区域大小，进一步减小选项尺寸防止溢出
        if self.width >= 1200 and self.height >= 800:
            # 大屏幕
            preview_size = 200
            option_size = 65
            section_spacing = 45
            container_padding = 20
        elif self.width >= 900 and self.height >= 600:
            # 中等屏幕
            preview_size = 170
            option_size = 60
            section_spacing = 40
            container_padding = 15
        else:
            # 小屏幕
            preview_size = 140
            option_size = 55
            section_spacing = 35
            container_padding = 10
        
        option_spacing = 12
        
        # 1. 皮肤预览区域 - 更突出的设计
        preview_y = start_y + 90
        
        # 标题 - 保持居中，与预览图片平行（垂直中心对齐）
        title_font = ("Microsoft YaHei", 40, "bold")
        title_text = f"🎨 选择{self.player_name}皮肤"
        self.draw_text(
            title_text,
            center_x,  # 标题居中
            preview_y,  # 与预览图片的垂直中心对齐
            font=title_font,
            fill=theme.title_primary,
            shadow=False,
        )
        
        # 估算标题宽度（中文字符宽度约为字体大小的0.8-1.0倍）
        # 标题文字："🎨 选择P1皮肤" 约11个字符（包括emoji和空格）
        title_width = len(title_text) * 40 * 0.85  # 中文字符宽度约为字体大小的0.85倍
        # 预览图片左边缘与标题右边缘对齐，留出更大的间距
        preview_left_x = center_x + title_width // 2 + 100  # 标题右边缘 + 100像素间距，保持一定距离
        preview_center_x = preview_left_x + preview_size // 2  # 预览图片中心位置
        
        # 渲染预览图片
        self._render_skin_preview(preview_center_x, preview_y, preview_size, theme)
        
        # 清空旧按钮
        for btn in self.skin_buttons + self.color_buttons + self.body_type_buttons:
            try:
                btn.delete()
            except:
                pass
        self.skin_buttons.clear()
        self.color_buttons.clear()
        self.body_type_buttons.clear()
        
        # 更新体型和颜色选项
        self.body_types = self.skin_manager.get_all_body_types()
        self.color_palettes = self.skin_manager.get_all_color_palettes()
        
        # 2. 当前组合信息 - 移到预览区下方，更醒目，向上移动位置
        combination_y = preview_y + preview_size // 2 + section_spacing // 2  # 确保与预览区域有足够间距，避免重叠
        self._render_current_combination(center_x, combination_y, theme)
        
        # 3. 功能区域容器 - 居中显示，设置统一的背景和边框，向上移动位置
        container_width = min(self.width - 100, 1100)
        container_x1 = center_x - container_width // 2
        # 计算组合信息占用的高度（文字 + 装饰线 + 间距）
        combination_height = 50  # 文字高度约30 + 装饰线约20
        container_y1 = combination_y + combination_height + section_spacing // 2  # 确保与组合信息有足够间距
        
        # 动态计算容器高度，确保内容不溢出
        # 计算颜色选择每行数量
        if self.width >= 1200:
            colors_per_row = 5
        elif self.width >= 900:
            colors_per_row = 4
        elif self.width >= 700:
            colors_per_row = 3
        else:
            colors_per_row = 2
        
        # 计算体型选择行数（每行2个）
        body_type_rows = (len(self.body_types) + 1) // 2
        # 计算颜色选择行数
        color_rows = (len(self.color_palettes) + colors_per_row - 1) // colors_per_row
        
        # 每个选项需要的高度：选项本身 + 间距 + 名称文字（确保文字不重叠）
        option_height_with_name = option_size + option_spacing + 35  # 35是名称文字的高度和间距
        
        # 计算需要的总高度：标题高度 + 选项区域高度
        title_height = 50  # 标题区域高度
        max_rows = max(body_type_rows, color_rows)
        needed_height = title_height + max_rows * option_height_with_name + container_padding * 2
        
        # 确保容器高度不超过可用空间
        # 按钮区域需要：按钮高度 + 返回按钮高度 + 提示文字高度 + 间距
        button_area_height = 220  # 预留足够的按钮区域空间
        max_container_height = self.height - container_y1 - button_area_height
        
        container_height = min(needed_height, max_container_height)
        
        # 如果容器高度太小，调整选项大小
        if container_height < needed_height and container_height < max_container_height * 0.8:
            # 可以适当减小选项大小以适应
            scale_factor = container_height / needed_height
            if scale_factor < 0.9:
                option_size = int(option_size * scale_factor)
                option_spacing = int(option_spacing * scale_factor)
                # 重新计算
                option_height_with_name = option_size + option_spacing + 35
                needed_height = title_height + max_rows * option_height_with_name + container_padding * 2
                container_height = min(needed_height, max_container_height)
        
        # 绘制功能区域背景 - 增强视觉层次感
        # 浅色模式下使用绿色背景，不使用白色
        container_bg = theme.bg_primary if theme.name == "浅色模式" else theme.bg_secondary
        self.canvas.create_rectangle(
            container_x1, container_y1,
            container_x1 + container_width, container_y1 + container_height,
            fill=container_bg,
            outline=theme.text_hint,
            width=3,
            tags="function_container"
        )
        
        # 添加功能区域标题
        container_title = "皮肤定制"
        title_font = ("Microsoft YaHei", 20, "bold")
        self.draw_text(
            container_title,
            center_x,
            container_y1 - 25,
            font=title_font,
            fill=theme.text_primary,
            shadow=False,
        )
        
        # 4. 体型选择区域（左侧）
        body_type_title = "体型选择"
        body_type_x = container_x1 + container_width // 4
        body_type_y = container_y1 + container_padding
        self._render_body_type_selection(body_type_x, body_type_y, body_type_title, option_size, option_spacing, theme)
        
        # 5. 分隔线 - 更明显的分隔
        divider_y = container_y1 + 20
        divider_height = container_height - 40
        self.canvas.create_line(
            container_x1 + container_width // 2, divider_y,
            container_x1 + container_width // 2, divider_y + divider_height,
            fill=theme.text_hint,
            width=3,
            tags="divider"
        )
        
        # 6. 颜色选择区域（右侧）
        color_title = "颜色选择"
        color_x = container_x1 + 3 * container_width // 4
        color_y = container_y1 + container_padding
        # 传递容器边界信息，确保选项不超出
        self._render_color_selection(color_x, color_y, color_title, option_size, option_spacing, theme, 
                                     container_x1 + container_width // 2, container_x1 + container_width)
        
        # 7. 按钮区域 - 固定在底部，确保不被遮挡，更突出的设计
        # 确保按钮区域与容器有足够间距，避免重叠
        min_button_spacing = section_spacing + 20  # 增加最小间距，确保不重叠
        button_y = container_y1 + container_height + min_button_spacing
        # 如果按钮区域太靠下，调整位置
        if button_y > self.height - 180:
            button_y = self.height - 180
        # 确保按钮下方有足够空间
        button_y = min(button_y, self.height - 130)
        
        # 统一按钮尺寸（P1和P2使用相同大小）
        button_width = 160 if self.width < 900 else 180
        button_height = 42 if self.width < 900 else 48
        button_spacing = 15 if self.width < 900 else 20
        
        # 按钮布局：根据玩家显示不同的按钮组合
        if self.player_name == "P1":
            # P1：显示"下一页 (P2)"按钮和"完成"按钮（并排显示）
            total_width = button_width * 2 + button_spacing
            left_x = center_x - total_width // 2 + button_width // 2
            right_x = center_x + total_width // 2 - button_width // 2
            
            # 下一页按钮（左侧）
            self.next_button = Button(
                self.canvas,
                left_x,
                button_y,
                width=button_width,
                height=button_height,
                text="→ 下一页 (P2)",
                on_click=self._on_next,
                font=("Microsoft YaHei", 14 if self.width < 900 else 16, "bold"),
                normal_color=theme.button_normal,
                hover_color=theme.button_hover,
                text_color=theme.button_text,
                border_color=theme.button_border,
            )
            # 完成按钮（右侧）
            self.complete_button = Button(
                self.canvas,
                right_x,
                button_y,
                width=button_width,
                height=button_height,
                text="✓ 完成",
                on_click=self._on_complete,
                font=("Microsoft YaHei", 14 if self.width < 900 else 16, "bold"),
                normal_color=theme.button_normal,
                hover_color=theme.button_hover,
                text_color=theme.button_text,
                border_color=theme.button_border,
            )
            self.prev_button = None
        else:
            # P2：显示"上一页 (P1)"按钮和"完成"按钮（并排显示）
            total_width = button_width * 2 + button_spacing
            left_x = center_x - total_width // 2 + button_width // 2
            right_x = center_x + total_width // 2 - button_width // 2
            
            # 上一页按钮（左侧）
            self.prev_button = Button(
                self.canvas,
                left_x,
                button_y,
                width=button_width,
                height=button_height,
                text="← 上一页 (P1)",
                on_click=self._on_prev,
                font=("Microsoft YaHei", 14 if self.width < 900 else 16, "bold"),
                normal_color=theme.button_normal,
                hover_color=theme.button_hover,
                text_color=theme.button_text,
                border_color=theme.button_border,
            )
            # 完成按钮（右侧）
            self.complete_button = Button(
                self.canvas,
                right_x,
                button_y,
                width=button_width,
                height=button_height,
                text="✓ 完成",
                on_click=self._on_complete,
                font=("Microsoft YaHei", 14 if self.width < 900 else 16, "bold"),
                normal_color=theme.button_normal,
                hover_color=theme.button_hover,
                text_color=theme.button_text,
                border_color=theme.button_border,
            )
            self.next_button = None
        
        # 返回按钮 - 使用统一的按钮尺寸
        back_button_y = button_y + button_height + 16
        back_button_width = button_width  # 使用统一的宽度
        back_button_height = button_height  # 使用统一的高度
        self.back_button = Button(
            self.canvas,
            center_x,
            back_button_y,
            width=back_button_width,
            height=back_button_height,
            text="← 返回首页",
            on_click=self._on_back,
            font=("Microsoft YaHei", 15 if self.width < 900 else 17, "bold"),
            normal_color=theme.button_normal,
            hover_color=theme.button_hover,
            text_color=theme.button_text,
            border_color=theme.button_border,
        )
        
        # 提示文字 - 固定在底部，确保不被遮挡
        hint_y = back_button_y + back_button_height + 15
        if hint_y < self.height - 10:
            if self.player_name == "P1":
                hint_text = "💡 选择皮肤后，可点击下一页为P2选择，或直接完成保存"
            else:
                hint_text = "💡 选择皮肤后，可点击上一页返回P1，或直接完成保存"
            self.draw_text(
                hint_text,
                center_x,
                hint_y,
                font=("Microsoft YaHei", 12 if self.width < 900 else 13),
                fill=theme.text_hint,
                shadow=False,
            )
    
    def _select_skin(self, skin_name: str) -> None:
        """选择皮肤"""
        self.selected_skin = skin_name
        self.render()  # 重新渲染以显示选中状态
    
    def _on_complete(self) -> None:
        """完成选择，保存皮肤偏好"""
        # 保存选择的皮肤
        SkinPreferences.instance().set_skin(self.player_name, self.selected_skin)
        # 调用完成回调
        self.on_complete()
    
    def _on_next(self) -> None:
        """保存P1的皮肤选择，然后切换到P2"""
        # 保存P1选择的皮肤
        SkinPreferences.instance().set_skin(self.player_name, self.selected_skin)
        # 不需要调用完成回调，因为handle_click会返回特殊状态处理切换
    
    def _on_prev(self) -> None:
        """保存P2的皮肤选择，然后切换到P1"""
        # 保存P2选择的皮肤
        SkinPreferences.instance().set_skin(self.player_name, self.selected_skin)
        # 不需要调用完成回调，因为handle_click会返回特殊状态处理切换
    
    def _on_back(self) -> None:
        """返回，不保存"""
        self.on_complete()
    
    def handle_key(self, key: str) -> Optional[str]:
        """处理键盘输入"""
        if key == "Return":  # Enter键
            self._on_complete()
            return "start"
        elif key == "Escape":
            self._on_back()
            return "start"
        return None
    
    def handle_click(self, x: int, y: int) -> Optional[str]:
        """处理鼠标点击"""
        if self.complete_button and self.complete_button.contains(x, y):
            self._on_complete()
            return "start"
        if self.next_button and self.next_button.contains(x, y):
            self._on_next()
            return "next_p2"  # 返回特殊状态，表示要切换到P2
        if self.prev_button and self.prev_button.contains(x, y):
            self._on_prev()
            return "prev_p1"  # 返回特殊状态，表示要切换到P1
        if self.back_button and self.back_button.contains(x, y):
            self._on_back()
            return "start"
        
        # 检查皮肤按钮
        for btn in self.skin_buttons:
            if btn.contains(x, y):
                btn.click()
                return None
        
        # 检查体型选择按钮
        for btn in self.body_type_buttons:
            if btn.contains(x, y):
                btn.click()
                return None
        
        # 检查颜色选择按钮
        for btn in self.color_buttons:
            if btn.contains(x, y):
                btn.click()
                return None
        
        return None
    
    def handle_motion(self, x: int, y: int) -> None:
        """处理鼠标移动"""
        if self.complete_button:
            self.complete_button.set_hover(self.complete_button.contains(x, y))
        if self.next_button:
            self.next_button.set_hover(self.next_button.contains(x, y))
        if self.prev_button:
            self.prev_button.set_hover(self.prev_button.contains(x, y))
        if self.back_button:
            self.back_button.set_hover(self.back_button.contains(x, y))
        
        # 处理颜色和体型按钮的悬停效果
        for btn in self.color_buttons + self.body_type_buttons:
            btn.set_hover(btn.contains(x, y))
    
    def _render_skin_preview(self, center_x, preview_y, preview_size, theme):
        """渲染皮肤预览区域"""
        # 绘制预览背景框 - 增强视觉效果
        preview_bg_x1 = center_x - preview_size // 2
        preview_bg_y1 = preview_y - preview_size // 2
        preview_bg_x2 = center_x + preview_size // 2
        preview_bg_y2 = preview_y + preview_size // 2
        
        # 添加渐变背景效果
        # 浅色模式下使用绿色背景，不使用白色
        preview_bg_color = theme.bg_primary if theme.name == "浅色模式" else theme.bg_secondary
        for i in range(10):
            alpha = i / 10
            self.canvas.create_rectangle(
                preview_bg_x1 + i * 5, preview_bg_y1 + i * 5,
                preview_bg_x2 - i * 5, preview_bg_y2 - i * 5,
                fill=preview_bg_color if i == 0 else "",
                outline=theme.text_hint if i == 0 else "",
                width=3 if i == 0 else 0,
                stipple="gray25" if i > 0 else "",
                tags="preview_bg"
            )
        
        # 获取当前选中的皮肤
        current_skin = self.skin_manager.get_by_combination(self.selected_color, self.selected_body_type)
        
        # 绘制蛇的预览（放大版）
        snake_center_x = center_x
        snake_center_y = preview_y
        
        # 计算蛇的尺寸
        scale = preview_size / 100
        base_head_size = int(20 * scale)
        base_body_size = int(15 * scale)
        
        # 根据体型调整大小
        head_size = int(base_head_size * current_skin.head_size_multiplier)
        body_size = int(base_body_size * current_skin.body_size_multiplier)
        
        # 计算蛇的总高度和宽度，确保不超出边框
        body_count = 5
        spacing = 3 * scale
        
        # 计算蛇头顶部y坐标（相对于预览框中心的偏移）
        head_y_offset = -20 * scale
        head_top_offset = head_y_offset - head_size // 2
        
        # 计算最后一节身体底部y坐标（相对于预览框中心的偏移）
        last_body_y_offset = head_y_offset + head_size // 2 + 5 * scale + (body_count - 1) * (body_size + spacing)
        last_body_bottom_offset = last_body_y_offset + body_size // 2
        
        # 计算总高度（从蛇头顶部到最后一节身体底部）
        total_height = last_body_bottom_offset - head_top_offset
        
        # 计算总宽度（蛇头或身体的最大宽度）
        total_width = max(head_size, body_size)
        
        # 计算可用空间（留出边距）
        margin = 15  # 上下左右各留15像素边距
        available_height = preview_size - margin * 2
        available_width = preview_size - margin * 2
        
        # 检查是否超出边界（相对于中心的偏移不能超过预览框半径）
        max_offset = preview_size // 2 - margin
        height_exceeds = abs(head_top_offset) > max_offset or abs(last_body_bottom_offset) > max_offset
        width_exceeds = total_width > available_width
        
        # 如果超出边界，计算缩放比例
        height_scale = 1.0
        width_scale = 1.0
        if height_exceeds:
            # 计算需要的缩放比例
            max_needed_offset = max(abs(head_top_offset), abs(last_body_bottom_offset))
            height_scale = max_offset / max_needed_offset if max_needed_offset > 0 else 1.0
        if width_exceeds:
            width_scale = available_width / total_width
        
        # 使用较小的缩放比例，确保不超出边框
        final_scale = min(height_scale, width_scale, 1.0)
        if final_scale < 1.0:
            head_size = int(head_size * final_scale)
            body_size = int(body_size * final_scale)
            scale = scale * final_scale
        
        # 绘制蛇身（5节）
        for i in range(5):
            body_y = snake_center_y - 20 * scale + head_size // 2 + 5 * scale + i * (body_size + 3 * scale)
            self.canvas.create_rectangle(
                snake_center_x - body_size // 2, body_y - body_size // 2,
                snake_center_x + body_size // 2, body_y + body_size // 2,
                fill=current_skin.body_color,
                outline="#ffffff",
                width=1,
                tags="preview_snake"
            )
        
        # 绘制蛇头（放在身体前面）
        head_y = snake_center_y - 20 * scale
        self.canvas.create_rectangle(
            snake_center_x - head_size // 2, head_y - head_size // 2,
            snake_center_x + head_size // 2, head_y + head_size // 2,
            fill=current_skin.head_color,
            outline="#ffffff",
            width=3,
            tags="preview_snake"
        )
        
        # 添加眼睛效果
        eye_size = head_size // 4
        eye_offset = head_size // 3
        
        # 左眼
        self.canvas.create_oval(
            snake_center_x - eye_offset, head_y - eye_size,
            snake_center_x - eye_offset + eye_size, head_y,
            fill="#ffffff",
            outline="",
            tags="preview_snake"
        )
        # 右眼
        self.canvas.create_oval(
            snake_center_x + eye_offset - eye_size, head_y - eye_size,
            snake_center_x + eye_offset, head_y,
            fill="#ffffff",
            outline="",
            tags="preview_snake"
        )
        # 瞳孔
        pupil_size = eye_size // 2
        self.canvas.create_oval(
            snake_center_x - eye_offset + eye_size // 4, head_y - eye_size + eye_size // 4,
            snake_center_x - eye_offset + eye_size // 4 + pupil_size, head_y - eye_size // 4,
            fill="#000000",
            outline="",
            tags="preview_snake"
        )
        self.canvas.create_oval(
            snake_center_x + eye_offset - eye_size + eye_size // 4, head_y - eye_size + eye_size // 4,
            snake_center_x + eye_offset - eye_size // 4, head_y - eye_size // 4,
            fill="#000000",
            outline="",
            tags="preview_snake"
        )
        
        # 添加高光效果
        highlight_size = eye_size // 3
        self.canvas.create_oval(
            snake_center_x - eye_offset + eye_size // 6, head_y - eye_size + eye_size // 6,
            snake_center_x - eye_offset + eye_size // 6 + highlight_size, head_y - eye_size // 3,
            fill="#ffffff",
            outline="",
            tags="preview_snake"
        )
        self.canvas.create_oval(
            snake_center_x + eye_offset - eye_size + eye_size // 6, head_y - eye_size + eye_size // 6,
            snake_center_x + eye_offset - eye_size // 6, head_y - eye_size // 3,
            fill="#ffffff",
            outline="",
            tags="preview_snake"
        )
        
        # 提升预览元素层级
        self.canvas.tag_raise("preview_snake")
    
    def _render_body_type_selection(self, x, y, title, option_size, option_spacing, theme):
        """渲染体型选择区域"""
        # 绘制标题 - 更醒目，确保在最上层
        title_font = ("Microsoft YaHei", 18, "bold")
        title_tag = "body_type_title"
        self.canvas.create_text(
            x,
            y,
            text=title,
            font=title_font,
            fill=theme.text_primary,
            anchor="center",
            tags=title_tag
        )
        # 确保标题在最上层
        self.canvas.tag_raise(title_tag)
        
        # 体型选项
        body_types = self.body_types
        
        # 绘制体型选项 - 增加与标题的间距，避免遮挡
        title_height = 25  # 标题高度约25像素
        spacing_after_title = 30  # 标题后间距，略微下移第一排皮肤
        first_option_y = y + title_height + spacing_after_title
        
        for i, (body_type_name, body_type_display) in enumerate(body_types.items()):
            row = i // 2
            col = i % 2
            option_x = x - (option_size + option_spacing) * 0.5 + col * (option_size + option_spacing)
            option_y = first_option_y + row * (option_size + option_spacing + 40)  # 增加间距，确保文字与图片不重叠
            
            # 绘制选项框 - 增强视觉效果
            is_selected = body_type_name == self.selected_body_type
            border_color = theme.option_selected if is_selected else theme.text_hint
            border_width = 4 if is_selected else 2
            
            # 绘制背景圆角矩形
            # 浅色模式下使用绿色背景，不使用白色
            option_bg = theme.bg_primary if (theme.name == "浅色模式" or not is_selected) else theme.bg_secondary
            self.canvas.create_rectangle(
                option_x - option_size // 2, option_y - option_size // 2,
                option_x + option_size // 2, option_y + option_size // 2,
                fill=option_bg,
                outline=border_color,
                width=border_width,
                tags=f"body_type_option_{body_type_name}"
            )
            
            # 绘制体型预览（增强版）- 增大预览图片尺寸
            preview_size = option_size - 10  # 从 option_size - 25 改为 option_size - 10，使预览更大
            scale = preview_size / 100
            
            # 获取体型数据
            current_skin = self.skin_manager.get_by_combination(self.selected_color, body_type_name)
            head_size_multiplier = current_skin.head_size_multiplier
            body_size_multiplier = current_skin.body_size_multiplier
            
            # 计算蛇的尺寸
            base_head_size = int(20 * scale)
            base_body_size = int(15 * scale)
            head_size = int(base_head_size * head_size_multiplier)
            body_size = int(base_body_size * body_size_multiplier)
            
            # 绘制蛇头
            head_x = option_x
            head_y = option_y - 20 * scale
            self.canvas.create_rectangle(
                head_x - head_size // 2, head_y - head_size // 2,
                head_x + head_size // 2, head_y + head_size // 2,
                fill="#5fbf89",
                outline="#ffffff",
                width=2,
                tags=f"body_type_option_{body_type_name}"
            )
            
            # 添加眼睛效果
            eye_size = head_size // 4
            eye_offset = head_size // 3
            
            # 左眼
            self.canvas.create_oval(
                head_x - eye_offset, head_y - eye_size,
                head_x - eye_offset + eye_size, head_y,
                fill="#ffffff",
                outline="",
                tags=f"body_type_option_{body_type_name}"
            )
            # 右眼
            self.canvas.create_oval(
                head_x + eye_offset - eye_size, head_y - eye_size,
                head_x + eye_offset, head_y,
                fill="#ffffff",
                outline="",
                tags=f"body_type_option_{body_type_name}"
            )
            # 瞳孔
            pupil_size = eye_size // 2
            self.canvas.create_oval(
                head_x - eye_offset + eye_size // 4, head_y - eye_size + eye_size // 4,
                head_x - eye_offset + eye_size // 4 + pupil_size, head_y - eye_size // 4,
                fill="#000000",
                outline="",
                tags=f"body_type_option_{body_type_name}"
            )
            self.canvas.create_oval(
                head_x + eye_offset - eye_size + eye_size // 4, head_y - eye_size + eye_size // 4,
                head_x + eye_offset - eye_size // 4, head_y - eye_size // 4,
                fill="#000000",
                outline="",
                tags=f"body_type_option_{body_type_name}"
            )
            
            # 绘制蛇身（3节）
            for j in range(3):
                body_y = head_y + head_size // 2 + 5 * scale + j * (body_size + 3 * scale)
                self.canvas.create_rectangle(
                    head_x - body_size // 2, body_y - body_size // 2,
                    head_x + body_size // 2, body_y + body_size // 2,
                    fill="#1c7c54",
                    outline="",
                    tags=f"body_type_option_{body_type_name}"
                )
            
            # 体型名称 - 更突出
            name_y = option_y + option_size // 2 + 20  # 增加间距，确保不与图片重叠
            name_font = ("Microsoft YaHei", 12, "bold")
            self.draw_text(
                body_type_display,
                option_x,
                name_y,
                font=name_font,
                fill=theme.text_primary if is_selected else theme.text_secondary,
                anchor="center",
                shadow=False,
            )
            
            # 创建可点击区域 - 更大的点击范围，包括图片和文字
            # 计算需要的高度：图片高度 + 文字高度 + 间距
            button_height = option_size + 50  # 确保覆盖图片和文字
            body_type_button = Button(
                self.canvas,
                option_x,
                option_y + 10,  # 稍微下移中心点，使按钮更好地覆盖整个选项
                width=option_size + 20,
                height=button_height,
                text="",
                on_click=lambda bt=body_type_name: self._select_body_type(bt),
                normal_color="",
                hover_color="",
                text_color="",
                border_color="",
            )
            self.body_type_buttons.append(body_type_button)
        
        # 最后再次确保标题在最上层
        self.canvas.tag_raise(title_tag)
    
    def _render_color_selection(self, x, y, title, option_size, option_spacing, theme, container_left=None, container_right=None):
        """渲染颜色选择区域"""
        # 绘制标题 - 更醒目，确保在最上层
        title_font = ("Microsoft YaHei", 18, "bold")
        title_tag = "color_title"
        self.canvas.create_text(
            x,
            y,
            text=title,
            font=title_font,
            fill=theme.text_primary,
            anchor="center",
            tags=title_tag
        )
        # 确保标题在最上层
        self.canvas.tag_raise(title_tag)
        
        # 颜色选项
        color_palettes = self.color_palettes
        color_names = list(color_palettes.keys())
        
        # 计算每行显示的颜色数量 - 根据屏幕尺寸和容器宽度调整
        margin = 15  # 左右各留15像素边距
        if container_right and container_left:
            # 计算可用宽度（留出边距）
            available_width = container_right - container_left - margin * 2
            # 根据可用宽度计算每行能容纳的颜色数量
            # 每个选项需要的宽度：option_size + option_spacing
            max_colors_per_row = int(available_width / (option_size + option_spacing))
            colors_per_row = min(max_colors_per_row, len(color_names))
            # 确保至少显示1个，但不超过5个
            colors_per_row = max(1, min(colors_per_row, 5))
        else:
            # 如果没有容器边界信息，使用原来的逻辑
            if self.width >= 1200:
                colors_per_row = 5
            elif self.width >= 900:
                colors_per_row = 4
            elif self.width >= 700:
                colors_per_row = 3
            else:
                colors_per_row = 2
        
        # 计算颜色选择区域的起始位置，确保不超出容器边界
        if container_left and container_right:
            # 计算选项区域的总宽度
            total_options_width = colors_per_row * option_size + (colors_per_row - 1) * option_spacing
            # 确保选项区域在容器内居中，但不超出边界
            options_start_x = max(container_left + margin, x - total_options_width // 2)
            options_end_x = options_start_x + total_options_width
            if options_end_x > container_right - margin:
                # 如果超出右边界，向左调整
                options_start_x = container_right - margin - total_options_width
                options_start_x = max(container_left + margin, options_start_x)
        else:
            options_start_x = x - (colors_per_row * (option_size + option_spacing) - option_spacing) // 2
        
        # 绘制颜色选项 - 增加与标题的间距，避免遮挡
        title_height = 25  # 标题高度约25像素
        spacing_after_title = 30  # 标题后间距，略微下移第一排皮肤
        first_option_y = y + title_height + spacing_after_title
        
        # 绘制颜色选项
        for i, color_name in enumerate(color_names):
            row = i // colors_per_row
            col = i % colors_per_row
            option_x = options_start_x + col * (option_size + option_spacing) + option_size // 2
            option_y = first_option_y + row * (option_size + option_spacing + 40)  # 增加间距，确保文字与图片不重叠
            
            # 最终边界检查，确保选项在容器内（如果仍然超出，调整位置）
            if container_right and option_x + option_size // 2 > container_right - margin:
                option_x = container_right - margin - option_size // 2
            if container_left and option_x - option_size // 2 < container_left + margin:
                option_x = container_left + margin + option_size // 2
            
            # 获取颜色信息
            color_palette = self.skin_manager.color_palette_manager.get(color_name)
            head_color = color_palette.head_color
            body_color = color_palette.body_color
            
            # 绘制选项框 - 增强视觉效果
            is_selected = color_name == self.selected_color
            border_color = theme.option_selected if is_selected else theme.text_hint
            border_width = 4 if is_selected else 2
            
            # 绘制背景圆角矩形
            # 浅色模式下使用绿色背景，不使用白色
            option_bg = theme.bg_primary if (theme.name == "浅色模式" or not is_selected) else theme.bg_secondary
            self.canvas.create_rectangle(
                option_x - option_size // 2, option_y - option_size // 2,
                option_x + option_size // 2, option_y + option_size // 2,
                fill=option_bg,
                outline=border_color,
                width=border_width,
                tags=f"color_option_{color_name}"
            )
            
            # 绘制颜色预览（增强版）- 增大预览图片尺寸
            preview_size = option_size - 10  # 从 option_size - 25 改为 option_size - 10，使预览更大
            scale = preview_size / 100
            
            # 计算蛇的尺寸
            base_head_size = int(20 * scale)
            base_body_size = int(15 * scale)
            
            # 根据体型调整大小
            current_skin = self.skin_manager.get_by_combination(color_name, self.selected_body_type)
            head_size = int(base_head_size * current_skin.head_size_multiplier)
            body_size = int(base_body_size * current_skin.body_size_multiplier)
            
            # 绘制蛇头
            head_x = option_x
            head_y = option_y - 20 * scale
            self.canvas.create_rectangle(
                head_x - head_size // 2, head_y - head_size // 2,
                head_x + head_size // 2, head_y + head_size // 2,
                fill=head_color,
                outline="#ffffff",
                width=2,
                tags=f"color_option_{color_name}"
            )
            
            # 添加眼睛效果
            eye_size = head_size // 4
            eye_offset = head_size // 3
            
            # 左眼
            self.canvas.create_oval(
                head_x - eye_offset, head_y - eye_size,
                head_x - eye_offset + eye_size, head_y,
                fill="#ffffff",
                outline="",
                tags=f"color_option_{color_name}"
            )
            # 右眼
            self.canvas.create_oval(
                head_x + eye_offset - eye_size, head_y - eye_size,
                head_x + eye_offset, head_y,
                fill="#ffffff",
                outline="",
                tags=f"color_option_{color_name}"
            )
            # 瞳孔
            pupil_size = eye_size // 2
            self.canvas.create_oval(
                head_x - eye_offset + eye_size // 4, head_y - eye_size + eye_size // 4,
                head_x - eye_offset + eye_size // 4 + pupil_size, head_y - eye_size // 4,
                fill="#000000",
                outline="",
                tags=f"color_option_{color_name}"
            )
            self.canvas.create_oval(
                head_x + eye_offset - eye_size + eye_size // 4, head_y - eye_size + eye_size // 4,
                head_x + eye_offset - eye_size // 4, head_y - eye_size // 4,
                fill="#000000",
                outline="",
                tags=f"color_option_{color_name}"
            )
            
            # 绘制蛇身（3节）
            for j in range(3):
                body_y = head_y + head_size // 2 + 5 * scale + j * (body_size + 3 * scale)
                self.canvas.create_rectangle(
                    head_x - body_size // 2, body_y - body_size // 2,
                    head_x + body_size // 2, body_y + body_size // 2,
                    fill=body_color,
                    outline="",
                    tags=f"color_option_{color_name}"
                )
            
            # 颜色名称 - 更突出
            name_y = option_y + option_size // 2 + 20  # 增加间距，确保不与图片重叠
            name_font = ("Microsoft YaHei", 12, "bold")
            display_name = color_palettes.get(color_name, color_name)
            self.draw_text(
                display_name,
                option_x,
                name_y,
                font=name_font,
                fill=theme.text_primary if is_selected else theme.text_secondary,
                anchor="center",
                shadow=False,
            )
            
            # 创建可点击区域 - 更大的点击范围，包括图片和文字
            # 计算需要的高度：图片高度 + 文字高度 + 间距
            button_height = option_size + 50  # 确保覆盖图片和文字
            color_button = Button(
                self.canvas,
                option_x,
                option_y + 10,  # 稍微下移中心点，使按钮更好地覆盖整个选项
                width=option_size + 20,
                height=button_height,
                text="",
                on_click=lambda cn=color_name: self._select_color(cn),
                normal_color="",
                hover_color="",
                text_color="",
                border_color="",
            )
            self.color_buttons.append(color_button)
        
        # 最后再次确保标题在最上层
        self.canvas.tag_raise(title_tag)
    
    def _render_current_combination(self, x, y, theme):
        """渲染当前组合信息"""
        # 获取当前组合的显示名称
        color_display = self.color_palettes.get(self.selected_color, self.selected_color)
        body_type_display = self.body_types.get(self.selected_body_type, self.selected_body_type)
        
        # 绘制当前组合信息 - 更醒目
        info_font = ("Microsoft YaHei", 22, "bold")
        self.draw_text(
            f"✨ 当前选择：{color_display} + {body_type_display}",
            x,
            y,
            font=info_font,
            fill=theme.text_primary,
            anchor="center",
            shadow=False,
        )
        
        # 添加装饰效果
        decor_width = min(600, self.width - 100)  # 装饰效果宽度不超过屏幕宽度减100
        self.canvas.create_rectangle(
            x - decor_width // 2, y + 20,
            x + decor_width // 2, y + 25,
            fill=theme.text_hint,
            outline="",
            tags="combination_decor"
        )
    
    def _select_body_type(self, body_type_name: str) -> None:
        """选择体型"""
        self.selected_body_type = body_type_name
        # 更新选中的皮肤组合
        self.selected_skin = f"{self.selected_color}_{self.selected_body_type}"
        self.render()  # 重新渲染以显示选中状态
    
    def _select_color(self, color_name: str) -> None:
        """选择颜色"""
        self.selected_color = color_name
        # 更新选中的皮肤组合
        self.selected_skin = f"{self.selected_color}_{self.selected_body_type}"
        self.render()  # 重新渲染以显示选中状态