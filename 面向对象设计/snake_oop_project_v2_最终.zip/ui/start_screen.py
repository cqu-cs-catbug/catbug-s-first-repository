from __future__ import annotations
from typing import Callable, List, Optional
import tkinter as tk
import logging
import os

from core.settings import GameSettings
from core.types import SpeedSetting
from ui.base_screen import BaseScreen
from ui.button import Button, ClickableOption
from ui.theme import ThemeManager

# 配置日志系统
log_file = os.path.join(os.path.dirname(__file__), "..", ".cursor", "debug.log")
os.makedirs(os.path.dirname(log_file), exist_ok=True)

# 创建logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# 如果还没有handler，创建一个
if not logger.handlers:
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    # 也输出到控制台
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)


class StartScreen(BaseScreen):
    """开始界面类，负责显示游戏选项和模式选择"""

    def __init__(
        self,
        canvas: tk.Canvas,
        width: int,
        height: int,
        settings: GameSettings,
        on_start: Callable[[GameSettings], None],
        on_skin_select: Optional[Callable[[], None]] = None,
        on_settings: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__(canvas, width, height)
        self.settings = settings
        self.on_start = on_start
        self.on_skin_select = on_skin_select or (lambda: None)
        self.on_settings = on_settings or (lambda: None)
        
        # 简化的状态管理
        self.selected_mode = "single"
        self.selected_speed = "normal"
        self.selected_difficulty = "normal"
        
        # 选项映射
        self.modes = {
            "single": "单人模式",
            "two": "双人对战",
            "timed": "限时挑战",
            "two_timed": "双人限时",
        }
        self.speeds = {
            "slow": "慢速",
            "normal": "正常",
            "fast": "快速",
        }
        self.difficulties = {
            "easy": "简单",
            "normal": "普通",
            "hard": "困难",
        }
        
        # 选项列表（线性布局，简化焦点管理）
        self.options: List[ClickableOption] = []
        self.start_button: Optional[Button] = None
        self.theme_button: Optional[Button] = None
        self.skin_button: Optional[Button] = None  # 皮肤切换按钮
        self.settings_button: Optional[Button] = None  # 设置按钮
        
        # 线性焦点管理（更可靠）
        self.focus_index = 0
        self.total_options = 0
        
        # 主题管理器
        self.theme_manager = ThemeManager.instance()
        self.current_theme_name = self.theme_manager._current_theme

    def render(self) -> None:
        """渲染开始界面 - 使用主题系统，优化布局和视觉效果"""
        self.clear()
        
        # 动态获取画布实际尺寸（确保全屏时正确居中）
        # 使用缓存机制，避免频繁查询
        if not hasattr(self, '_cached_canvas_width') or self._cached_canvas_width is None:
            # 首次获取时，更新缓存
            self.canvas.update_idletasks()
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            # 如果画布尺寸为1（未初始化），使用窗口尺寸
            if canvas_width <= 1 or canvas_height <= 1:
                root = self.canvas.winfo_toplevel()
                root.update_idletasks()
                canvas_width = root.winfo_width() or self.width
                canvas_height = (root.winfo_height() or self.height) - 20  # 减去状态栏高度
            self._cached_canvas_width = canvas_width
            self._cached_canvas_height = canvas_height
        else:
            # 使用缓存的尺寸
            canvas_width = self._cached_canvas_width
            canvas_height = self._cached_canvas_height
        
        # 更新尺寸
        self.width = canvas_width
        self.height = canvas_height
        
        # 获取当前主题
        theme = self.theme_manager.get_current_theme()
        
        # 背景设计 - 使用主题颜色
        self.canvas.configure(bg=theme.bg_primary)
        
        # 绘制优化的渐变背景（使用主题渐变色）
        def hex_to_rgb(hex_color: str) -> tuple:
            """将十六进制颜色转换为RGB元组"""
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        def rgb_to_hex(r: int, g: int, b: int) -> str:
            """将RGB元组转换为十六进制颜色"""
            return f"#{r:02x}{g:02x}{b:02x}"
        
        start_rgb = hex_to_rgb(theme.bg_gradient_start)
        end_rgb = hex_to_rgb(theme.bg_gradient_end)
        
        for i in range(self.height):
            ratio = i / self.height
            r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
            g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
            b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
            color = rgb_to_hex(r, g, b)
            self.canvas.create_line(0, i, self.width, i, fill=color, width=1)

        center_x = self.width // 2
        start_y = 40  # 稍微上移，给下方更多空间

        # 标题设计 - 使用主题颜色，优化字体样式
        # 优化：稍微减小标题字体，减少占用空间
        title_font = ("Microsoft YaHei", 38, "bold")  # 从42减小到38
        
        # 主标题（不使用阴影效果）
        self.draw_text(
            "🐍 贪吃蛇游戏",
            center_x,
            start_y,
            font=title_font,
            fill=theme.title_primary,
        )

        # 欢迎语 - 使用主题次要文字色，优化字体大小和行高
        welcome_font = ("Microsoft YaHei", 16)  # 去掉斜体样式
        welcome_y = start_y + 55  # 从60减小到55，减少间距
        self.draw_text(
            "欢迎来到贪吃蛇世界！",
            center_x,
            welcome_y,
            font=welcome_font,
            fill=theme.text_secondary,
        )

        # 优化选项区域设计 - 采用三列布局，增加间距减少拥挤感
        # 布局规范：左侧游戏模式，中间速度和难度，右侧主题切换
        # 优化：增加标题和选项区域之间的间距
        options_start_y = start_y + 140  # 从120增加到140，增加更多空间
        option_spacing = 35  # 从30增加到35，增加选项之间的间距
        
        # 优化三列布局，增加列间距，减少拥挤感
        # 使用更宽的列间距，让布局更宽松
        col_spacing = self.width // 5  # 使用1/5宽度作为列间距基准
        left_col_x = self.width // 4
        center_col_x = self.width // 2
        right_col_x = self.width * 3 // 4
        
        # 清空现有选项
        self.options.clear()
        
        # 创建选项的辅助函数 - 使用主题颜色，优化字体样式
        # 字体规范：选项文字16号，行高1.5倍
        option_font = ("Microsoft YaHei", 16)
        
        def create_option(x, y, text, is_selected):
            option = ClickableOption(
                self.canvas,
                x,
                y,
                text,
                lambda: None,
                is_selected=is_selected,
                font=option_font,
                selected_color=theme.option_selected,
                normal_color=theme.option_normal,
            )
            self.options.append(option)
            return option
        
        # 计算画布高度，确保所有元素都能放下
        canvas_height = self.canvas.winfo_height() or 600
        
        # 优化：减小分类标题字体，增加标题和选项之间的间距
        category_font = ("Microsoft YaHei", 16, "bold")  # 从18减小到16
        
        # 1. 游戏模式（左侧列）
        mode_y = options_start_y
        self.draw_text("🎮 游戏模式", left_col_x, mode_y - 25, font=category_font, fill=theme.option_selected, shadow=False)
        
        mode_option_y = mode_y + 8  # 从5增加到8，增加标题和选项间距
        for mode_key, mode_name in self.modes.items():
            create_option(left_col_x, mode_option_y, mode_name, self.selected_mode == mode_key)
            mode_option_y += option_spacing
        
        # 2. 游戏速度（中间列上方）
        speed_y = options_start_y
        self.draw_text("⚡ 游戏速度", center_col_x, speed_y - 25, font=category_font, fill=theme.option_selected, shadow=False)
        
        speed_option_y = speed_y + 8  # 从5增加到8
        for speed_key, speed_name in self.speeds.items():
            create_option(center_col_x, speed_option_y, speed_name, self.selected_speed == speed_key)
            speed_option_y += option_spacing
        
        # 3. 地形难度（中间列下方）
        difficulty_y = speed_option_y + 20  # 从15增加到20，增加两个分类之间的间距
        self.draw_text("⛰️ 地形难度", center_col_x, difficulty_y - 25, font=category_font, fill=theme.option_selected, shadow=False)
        
        difficulty_option_y = difficulty_y + 8  # 从5增加到8
        for diff_key, diff_name in self.difficulties.items():
            create_option(center_col_x, difficulty_option_y, diff_name, self.selected_difficulty == diff_key)
            difficulty_option_y += option_spacing
        
        # 4. 主题切换（右侧列）
        theme_y = options_start_y
        self.draw_text("🎨 界面主题", right_col_x, theme_y - 25, font=category_font, fill=theme.option_selected, shadow=False)
        
        theme_option_y = theme_y + 8  # 从5增加到8
        theme_names = {"light": "浅色模式", "dark": "深色模式"}
        for theme_key, theme_display_name in theme_names.items():
            create_option(right_col_x, theme_option_y, theme_display_name, self.current_theme_name == theme_key)
            theme_option_y += option_spacing
        
        # 5. 开始游戏按钮 - 使用主题颜色，优化设计
        # 优化：增加按钮与选项之间的间距，减少拥挤感
        max_option_y = max(difficulty_option_y, theme_option_y, mode_option_y)
        button_y = max_option_y + 60  # 从50增加到60，增加更多间距
        
        # 确保按钮不会超出画布底部，但优先保证可见性
        if button_y + 40 > canvas_height - 30:
            # 如果空间不足，向上调整，但确保至少显示
            button_y = max(max_option_y + 40, canvas_height - 100)
        
        # 创建按钮（使用主题颜色，确保文字始终可见）
        # 优化：稍微减小按钮字体，让整体更协调
        button_font = ("Microsoft YaHei", 22, "bold")  # 从24减小到22
        
        # 先删除旧按钮（如果存在）
        if self.start_button:
            try:
                self.start_button.delete()
            except:
                pass
        
        # 创建新按钮，确保文字在按钮内部
        # 优化：稍微减小按钮尺寸，让界面更协调
        self.start_button = Button(
            self.canvas,
            center_x,
            button_y,
            width=280,  # 从300减小到280
            height=65,  # 从70减小到65
            text="▶ 开始游戏",
            on_click=lambda: None,
            font=button_font,
            normal_color=theme.button_normal,
            hover_color=theme.button_hover,
            text_color=theme.button_text,
            border_color=theme.button_border,
        )
        
        # 6. 切换皮肤按钮 - 在开始游戏按钮下方
        # 修复：确保按钮总是显示（如果有回调函数），移除高度限制
        if self.on_skin_select:
            skin_button_y = button_y + 80  # 在开始游戏按钮下方
            # 修复：移除高度限制，确保按钮总是显示
            # 先删除旧按钮
            if self.skin_button:
                try:
                    self.skin_button.delete()
                except:
                    pass
            
            # 创建皮肤切换按钮
            # 修复：使用 self.on_skin_select 作为回调，而不是 lambda: None
            self.skin_button = Button(
                self.canvas,
                center_x,
                skin_button_y,
                width=240,
                height=50,
                text="🎨 切换皮肤",
                on_click=self.on_skin_select,  # 修复：使用实际的回调函数
                font=("Microsoft YaHei", 18),
                normal_color="#533483",
                hover_color="#7c5fb8",
                text_color="#ffffff",
                border_color="#3d2a5f",
            )
        
        # 7. 设置按钮 - 在切换皮肤按钮下方
        if self.on_settings:
            settings_button_y = button_y + 140  # 在切换皮肤按钮下方
            # 先删除旧按钮
            if self.settings_button:
                try:
                    self.settings_button.delete()
                except:
                    pass
            
            # 创建设置按钮
            self.settings_button = Button(
                self.canvas,
                center_x,
                settings_button_y,
                width=240,
                height=50,
                text="⚙️ 游戏设置",
                on_click=self.on_settings,
                font=("Microsoft YaHei", 18),
                normal_color="#2563eb",
                hover_color="#3b82f6",
                text_color="#ffffff",
                border_color="#1e40af",
            )
        
        # 更新选项总数（包括主题选项和开始按钮）
        self.total_options = len(self.options) + 1  # 选项数 + 开始按钮
        
        # 应用焦点
        self._apply_focus()
        
        # 优化操作提示位置和样式 - 使用主题颜色
        # 将提示词固定到页面最下方
        hint_y = self.height - 40  # 主提示词在页面底部上方40像素
        self.draw_text(
            "💡 提示：点击选项或使用 ↑↓ 键选择，Enter 确认",
            center_x,
            hint_y,
            font=("Microsoft YaHei", 12),
            fill=theme.text_hint,
            shadow=False,
        )
        self.draw_text(
            "按 ESC 键退出游戏",
            center_x,
            hint_y + 22,
            font=("Microsoft YaHei", 10),
            fill=theme.text_hint,
            shadow=False,
        )

    def _apply_focus(self) -> None:
        """应用焦点状态 - 简化设计"""
        # 重置所有选项的悬停状态
        for option in self.options:
            option.set_hover(False)
        if self.start_button:
            self.start_button.set_hover(False)
        
        # 根据焦点索引设置悬停状态
        if self.focus_index < len(self.options):
            # 焦点在选项上
            self.options[self.focus_index].set_hover(True)
        elif self.focus_index == len(self.options) and self.start_button:
            # 焦点在开始按钮上
            self.start_button.set_hover(True)

    def _get_option_category(self, index: int) -> str:
        """根据选项索引获取选项类别（支持主题选项）"""
        mode_count = len(self.modes)
        speed_count = len(self.speeds)
        difficulty_count = len(self.difficulties)
        theme_count = 3  # 三个主题选项
        
        if index < mode_count:
            return "mode"
        elif index < mode_count + speed_count:
            return "speed"
        elif index < mode_count + speed_count + difficulty_count:
            return "difficulty"
        elif index < mode_count + speed_count + difficulty_count + theme_count:
            return "theme"
        else:
            return "start"

    def _get_option_key(self, category: str, index: int) -> str:
        """根据类别和索引获取选项键（支持主题选项）"""
        mode_count = len(self.modes)
        speed_count = len(self.speeds)
        difficulty_count = len(self.difficulties)
        
        if category == "mode":
            return list(self.modes.keys())[index]
        elif category == "speed":
            return list(self.speeds.keys())[index - mode_count]
        elif category == "difficulty":
            return list(self.difficulties.keys())[index - mode_count - speed_count]
        elif category == "theme":
            theme_keys = ["light", "dark"]
            theme_index = index - mode_count - speed_count - difficulty_count
            return theme_keys[theme_index] if 0 <= theme_index < len(theme_keys) else "dark"
        return ""

    def handle_key(self, key: str) -> Optional[str]:
        """处理键盘输入 - 添加调试日志，修复选项选择逻辑"""
        logger.debug(f"handle_key: key={key}, focus_index={self.focus_index}, total_options={self.total_options}")
        
        if key == "Up":
            # 向上移动焦点
            self.focus_index = (self.focus_index - 1) % self.total_options
            logger.debug(f"Focus moved up to index {self.focus_index}")
            self._apply_focus()
            return None
        
        elif key == "Down":
            # 向下移动焦点
            self.focus_index = (self.focus_index + 1) % self.total_options
            logger.debug(f"Focus moved down to index {self.focus_index}")
            self._apply_focus()
            return None
        
        elif key == "Return":  # Enter键
            category = self._get_option_category(self.focus_index)
            logger.debug(f"Enter pressed, focus_index={self.focus_index}, category={category}")
            
            if category == "start":
                # 开始游戏
                logger.debug("Starting game")
                return "game"
            else:
                # 选择当前焦点的选项
                option_key = self._get_option_key(category, self.focus_index)
                logger.debug(f"Selecting option: category={category}, key={option_key}")
                
                if category == "mode":
                    old_mode = self.selected_mode
                    self.selected_mode = option_key
                    logger.debug(f"Mode changed: {old_mode} -> {option_key}")
                elif category == "speed":
                    old_speed = self.selected_speed
                    self.selected_speed = option_key
                    logger.debug(f"Speed changed: {old_speed} -> {option_key}")
                elif category == "difficulty":
                    old_difficulty = self.selected_difficulty
                    self.selected_difficulty = option_key
                    logger.debug(f"Difficulty changed: {old_difficulty} -> {option_key}")
                elif category == "theme":
                    # 切换主题
                    old_theme = self.current_theme_name
                    self.current_theme_name = option_key
                    self.theme_manager.set_theme(option_key)
                    logger.debug(f"Theme changed: {old_theme} -> {option_key}")
                
                # 重新渲染以更新选中状态
                self.render()
                return None
        
        elif key == "Escape":
            # 退出游戏
            logger.debug("Escape pressed, exiting")
            return "exit"
        
        return None

    def handle_click(self, x: int, y: int) -> Optional[str]:
        """处理鼠标点击 - 添加调试日志，修复选项识别逻辑"""
        # 调试日志：记录点击位置
        logger.debug(f"handle_click: x={x}, y={y}, total_options={len(self.options)}")
        
        # 检查开始按钮
        if self.start_button and self.start_button.contains(x, y):
            logger.debug("Clicked start button")
            return "game"
        
        # 检查皮肤切换按钮
        if self.skin_button and self.skin_button.contains(x, y):
            logger.debug("Clicked skin button")
            return "skin_select"  # 返回状态，由ui/app.py处理
        
        # 检查设置按钮
        if self.settings_button and self.settings_button.contains(x, y):
            logger.debug("Clicked settings button")
            return "settings"  # 返回状态，由ui/app.py处理
        
        # 检查选项点击（支持主题选项）
        # 修复：正确计算各选项的索引范围
        mode_count = len(self.modes)  # 4个模式选项
        speed_count = len(self.speeds)  # 3个速度选项
        difficulty_count = len(self.difficulties)  # 3个难度选项
        theme_count = 3  # 3个主题选项
        
        # 计算各选项的起始索引
        mode_start = 0
        speed_start = mode_count
        difficulty_start = mode_count + speed_count
        theme_start = mode_count + speed_count + difficulty_count
        
        logger.debug(f"Option ranges: mode={mode_start}-{speed_start-1}, speed={speed_start}-{difficulty_start-1}, "
                    f"difficulty={difficulty_start}-{theme_start-1}, theme={theme_start}-{theme_start+theme_count-1}")
        
        # 遍历所有选项，找到匹配的选项
        matched_options = []
        for i, option in enumerate(self.options):
            if option.contains(x, y):
                matched_options.append((i, option.text))
                logger.debug(f"Option {i} matched: text='{option.text}', x={option.x}, y={option.y}")
        
        # 如果有多个匹配（理论上不应该），选择最接近的
        if matched_options:
            # 选择第一个匹配的选项（通常只有一个）
            i, option_text = matched_options[0]
            logger.debug(f"Selected option index: {i}, text: '{option_text}'")
            
            # 确定选项类别并更新选择
            if i < speed_start:
                # 模式选项（索引0-3）
                mode_index = i - mode_start
                if 0 <= mode_index < len(self.modes):
                    mode_key = list(self.modes.keys())[mode_index]
                    logger.debug(f"Selecting mode: index={mode_index}, key={mode_key}, name={self.modes[mode_key]}")
                    self.selected_mode = mode_key
                else:
                    logger.warning(f"Invalid mode index: {mode_index}")
            elif i < difficulty_start:
                # 速度选项（索引4-6）
                speed_index = i - speed_start
                if 0 <= speed_index < len(self.speeds):
                    speed_key = list(self.speeds.keys())[speed_index]
                    logger.debug(f"Selecting speed: index={speed_index}, key={speed_key}, name={self.speeds[speed_key]}")
                    self.selected_speed = speed_key
                else:
                    logger.warning(f"Invalid speed index: {speed_index}")
            elif i < theme_start:
                # 难度选项（索引7-9）
                difficulty_index = i - difficulty_start
                if 0 <= difficulty_index < len(self.difficulties):
                    difficulty_key = list(self.difficulties.keys())[difficulty_index]
                    logger.debug(f"Selecting difficulty: index={difficulty_index}, key={difficulty_key}, name={self.difficulties[difficulty_key]}")
                    self.selected_difficulty = difficulty_key
                else:
                    logger.warning(f"Invalid difficulty index: {difficulty_index}")
            elif i < theme_start + theme_count:
                # 主题选项（索引10-11）
                theme_index = i - theme_start
                theme_keys = ["light", "dark"]
                if 0 <= theme_index < len(theme_keys):
                    theme_key = theme_keys[theme_index]
                    logger.debug(f"Selecting theme: index={theme_index}, key={theme_key}")
                    self.current_theme_name = theme_key
                    self.theme_manager.set_theme(theme_key)
                else:
                    logger.warning(f"Invalid theme index: {theme_index}")
            
            # 更新焦点索引
            self.focus_index = i
            logger.debug(f"Updated focus_index to {i}, selected_mode={self.selected_mode}, selected_speed={self.selected_speed}")
            
            # 重新渲染以应用变化
            self.render()
            return None
        else:
            logger.debug("No option matched the click")
        
        return None

    def handle_motion(self, x: int, y: int) -> Optional[str]:
        """处理鼠标移动 - 简化设计"""
        # 检查开始按钮悬停
        if self.start_button:
            self.start_button.set_hover(self.start_button.contains(x, y))
        
        # 检查皮肤切换按钮悬停
        if self.skin_button:
            self.skin_button.set_hover(self.skin_button.contains(x, y))
        
        # 检查设置按钮悬停
        if self.settings_button:
            self.settings_button.set_hover(self.settings_button.contains(x, y))
        
        # 检查选项悬停
        for option in self.options:
            option.set_hover(option.contains(x, y))
        
        return None

    def get_settings(self) -> GameSettings:
        """获取当前选择的设置 - 确保设置正确"""
        # 转换速度字符串为SpeedSetting枚举
        speed_map = {
            "slow": SpeedSetting.SLOW,
            "normal": SpeedSetting.NORMAL,
            "fast": SpeedSetting.FAST,
        }
        
        # 使用dataclasses.replace来更新设置，保留所有其他字段
        from dataclasses import replace
        
        try:
            # 尝试使用replace更新设置，保留所有字段（包括enable_mountain, enable_swamp等）
            return replace(
                self.settings,
                mode=self.selected_mode,
                speed=speed_map[self.selected_speed],
                difficulty=self.selected_difficulty,
            )
        except Exception:
            # 如果replace失败，创建新实例，包含所有字段
            return GameSettings(
                width=self.settings.width,
                height=self.settings.height,
                mode=self.selected_mode,
                time_limit_sec=self.settings.time_limit_sec,
                two_player_time_limit_sec=getattr(self.settings, 'two_player_time_limit_sec', 60),
                speed=speed_map[self.selected_speed],
                enable_moving_obstacle=self.settings.enable_moving_obstacle,
                enable_mountain=getattr(self.settings, 'enable_mountain', True),
                enable_swamp=getattr(self.settings, 'enable_swamp', True),
                difficulty=self.selected_difficulty,
                p1_keys=getattr(self.settings, 'p1_keys', None),
                p2_keys=getattr(self.settings, 'p2_keys', None),
                key_scheme=getattr(self.settings, 'key_scheme', 'default'),
            )
