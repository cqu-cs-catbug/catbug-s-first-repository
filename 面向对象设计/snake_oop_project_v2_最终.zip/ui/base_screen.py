from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import tkinter as tk


class BaseScreen(ABC):
    """界面基类，定义所有界面的通用接口（体现面向对象思维）"""

    def __init__(self, canvas: tk.Canvas, width: int, height: int) -> None:
        self.canvas = canvas
        self.width = width
        self.height = height

    @abstractmethod
    def render(self) -> None:
        """渲染界面内容"""
        raise NotImplementedError

    @abstractmethod
    def handle_key(self, key: str) -> Optional[str]:
        """
        处理键盘输入
        返回: 如果返回字符串，表示要切换到的界面状态（如 'game', 'start'）
             如果返回 None，表示当前界面继续处理
        """
        raise NotImplementedError

    def handle_click(self, x: int, y: int) -> Optional[str]:
        """
        处理鼠标点击
        返回: 如果返回字符串，表示要切换到的界面状态
             如果返回 None，表示当前界面继续处理
        """
        return None

    def handle_motion(self, x: int, y: int) -> None:
        """处理鼠标移动（用于悬停效果）"""
        pass

    def clear(self) -> None:
        """清空画布"""
        self.canvas.delete("all")

    def draw_text(
        self,
        text: str,
        x: int,
        y: int,
        font: tuple = ("Arial", 24),
        fill: str = "black",
        anchor: str = "center",
        shadow: bool = False,
    ) -> None:
        """
        绘制文本的辅助方法
        """
        # 绘制主文字层（不绘制阴影）
        self.canvas.create_text(x, y, text=text, font=font, fill=fill, anchor=anchor)

    def draw_rect(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        fill: str = "",
        outline: str = "black",
        width: int = 2,
    ) -> None:
        """绘制矩形的辅助方法"""
        self.canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=outline, width=width)
