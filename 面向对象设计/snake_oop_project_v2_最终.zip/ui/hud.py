from __future__ import annotations
import time
from typing import Any, Dict, Optional

from core.events import EventBus
from core.score_manager import ScoreManager, GameRecord


class Hud:
    def __init__(self, events: EventBus) -> None:
        self.mode = ""
        self.message = ""
        self.scores: Dict[str, int] = {}
        self._last_warning = ""
        self._last_warning_at = 0.0
        
        # 限时模式相关
        self._time_limit_sec: Optional[int] = None
        self._is_timed_mode = False
        self._score_manager = ScoreManager.instance()
        self._best_records: Dict[str, GameRecord] = {}  # 存储所有玩家的最佳成绩
        self._current_mode = ""  # 当前游戏模式
        # 使用从引擎获取的剩余时间，而不是自己计算
        self._remaining_time: Optional[float] = None

        events.subscribe("game_started", self.on_game_started)
        events.subscribe("state_updated", self.on_state_updated)
        events.subscribe("game_over", self.on_game_over)
        events.subscribe("warning", self.on_warning)

    def on_game_started(self, payload: Dict[str, Any]) -> None:
        self.mode = str(payload.get("mode", ""))
        self.message = ""
        
        # 确定当前游戏模式
        if "双人限时模式" in self.mode:
            self._current_mode = "two_timed"
            self._is_timed_mode = True
            # 从引擎获取时间限制，不硬编码
            self._time_limit_sec = None
        elif "限时模式" in self.mode:
            self._current_mode = "timed"
            self._is_timed_mode = True
            # 从引擎获取时间限制，不硬编码
            self._time_limit_sec = None
        elif "双人模式" in self.mode:
            self._current_mode = "two"
            self._is_timed_mode = False
            self._time_limit_sec = None
        else:
            self._current_mode = "single"
            self._is_timed_mode = False
            self._time_limit_sec = None
        
        # 初始化剩余时间为None，直到从引擎获取
        self._remaining_time = None
        
        # 加载历史最好成绩（为所有可能的玩家加载）
        self._best_records = {}
        if self._current_mode in ("two", "two_timed"):
            # 双人模式：为每个玩家加载记录
            for player_name in ["P1", "P2"]:
                record = self._score_manager.get_record(self._current_mode, player_name)
                self._best_records[player_name] = record
        else:
            # 单人模式：只加载一个记录
            record = self._score_manager.get_record(self._current_mode)
            self._best_records[""] = record

    def on_state_updated(self, payload: Dict[str, Any]) -> None:
        self.scores = {s["name"]: s["score"] for s in payload.get("snakes", [])}
        self.message = str(payload.get("message", ""))
        # 从引擎获取剩余时间
        self._remaining_time = payload.get("remaining_time")

    def on_game_over(self, payload: Dict[str, Any]) -> None:
        winner = payload.get("winner")
        msg = payload.get("message") or ""
        
        # 更新成绩记录（为每个玩家分别更新）
        time_used = 0.0
        if self._is_timed_mode and self._time_limit_sec:
            # 计算实际使用时间 = 总时间 - 剩余时间
            if self._remaining_time is not None:
                time_used = self._time_limit_sec - self._remaining_time
            else:
                # 如果没有剩余时间数据，使用默认值
                time_used = 0.0
        
        new_records = []
        if self._current_mode in ("two", "two_timed"):
            # 双人模式：为每个玩家分别更新成绩
            # 修复：确保从scores或payload中获取分数
            scores_to_use = self.scores if self.scores else payload.get("scores", {})
            for player_name, score in scores_to_use.items():
                is_new_record = self._score_manager.update_record(
                    self._current_mode,
                    score,
                    player_name,
                    time_used
                )
                if is_new_record:
                    new_records.append(player_name)
                # 更新本地记录
                self._best_records[player_name] = self._score_manager.get_record(
                    self._current_mode, player_name
                )
        else:
            # 单人模式：更新单个记录
            # 修复：确保从scores或payload中获取分数
            if self.scores:
                score = max(self.scores.values())
            else:
                # 如果没有scores数据，尝试从payload中获取
                payload_scores = payload.get("scores", {})
                if payload_scores:
                    score = max(payload_scores.values())
                else:
                    score = 0
            
            is_new_record = self._score_manager.update_record(
                self._current_mode,
                score,
                "",
                time_used
            )
            if is_new_record:
                new_records.append("")
            # 更新本地记录
            self._best_records[""] = self._score_manager.get_record(self._current_mode)
        
        # 添加新纪录提示
        if new_records:
            if len(new_records) == 1 and new_records[0]:
                msg = f"{msg} 🎉 {new_records[0]}新纪录！" if msg else f"🎉 {new_records[0]}新纪录！"
            else:
                msg = f"{msg} 🎉 新纪录！" if msg else "🎉 新纪录！"
        
        if winner:
            self.message = f"游戏结束。获胜者: {winner}。 {msg}"
        else:
            self.message = f"游戏结束。平局/无获胜者。 {msg}"

    def on_warning(self, payload: Dict[str, Any]) -> None:
        self._last_warning = str(payload.get("message", ""))
        self._last_warning_at = time.time()

    def render_text(self) -> str:
        # Show recent warnings briefly
        warn = ""
        if self._last_warning and (time.time() - self._last_warning_at) < 1.2:
            warn = f" | Warning: {self._last_warning}"
        
        scores = "  ".join([f"{k}:{v}" for k, v in self.scores.items()])
        
        # 限时模式：显示倒计时，使用从引擎获取的剩余时间
        timer_info = ""
        if self._is_timed_mode and self._remaining_time is not None:
            remaining = max(0, self._remaining_time)
            
            # 格式化倒计时显示为 MM:SS 格式
            minutes = int(remaining // 60)
            seconds = int(remaining % 60)
            time_str = f"{minutes:02d}:{seconds:02d}"
            
            # 最后10秒，使用警告格式
            if remaining <= 10:
                timer_info = f" | ⏰ {time_str} ⚠️"
            else:
                timer_info = f" | ⏰ {time_str}"
        
        return f"Mode: {self.mode} | {scores}{timer_info}{warn} | {self.message}"
