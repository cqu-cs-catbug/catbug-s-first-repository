from __future__ import annotations
import tkinter as tk
import time
import json
from datetime import datetime
from typing import Optional

from controllers.keyboard import KeyboardController
from core.engine import GameEngine
from core.settings import GameSettings
from core.types import SpeedSetting
from ui.hud import Hud
from ui.input import InputBinder
from ui.tk_renderer import TkRenderer
from ui.start_screen import StartScreen
from ui.end_screen import EndScreen
from ui.skin_select_screen import SkinSelectScreen


class SnakeApp:
    """主应用类，管理界面状态和游戏流程（体现面向对象的状态管理）"""

    def __init__(self, settings: GameSettings) -> None:
        self.root = tk.Tk()
        self.root.title("Snake OOP (Tkinter) - v2")
        
        # 允许窗口调整大小，实现自适应
        self.root.resizable(True, True)
        
        # 根据地图大小计算初始窗口尺寸
        cell_size = 30
        min_window_width = 1200  # 增大最小宽度，为成绩栏留出空间
        min_window_height = 800  # 增大最小高度，避免地图被遮挡
        
        # 计算基于地图尺寸的窗口大小
        # 增加额外的宽度空间，为右上角的成绩栏留出位置（至少200像素）
        map_width = settings.width * cell_size + 300  # 增加边距，为成绩栏留出空间
        map_height = settings.height * cell_size + 200  # 增加边距和状态栏高度
        
        # 确保窗口不小于最小值
        window_width = max(min_window_width, map_width)
        window_height = max(min_window_height, map_height)
        
        # 设置初始窗口大小
        self.root.geometry(f"{window_width}x{window_height}")
        
        # 初始化渲染器 - 增大单元格尺寸，提升视觉效果
        self.renderer = TkRenderer(self.root, cell_size=cell_size)
        
        # 获取画布实际大小
        canvas_width = window_width
        canvas_height = window_height - 20  # 减去状态栏高度
        
        # 缓存窗口尺寸，用于窗口大小变化检测
        self._last_window_size = (window_width, window_height)
        
        # 状态管理
        self.current_screen: str = "start"  # start | game | end | skin_select | settings
        self.settings = settings
        self.game_start_button: Optional[tk.Button] = None
        self.skin_select_screen: Optional[SkinSelectScreen] = None
        self.settings_screen = None  # 设置界面（延迟初始化）
        self.current_player_for_skin: str = "P1"  # 当前选择皮肤的玩家

        # 游戏引擎和HUD（延迟初始化）
        self.engine: Optional[GameEngine] = None
        self.hud: Optional[Hud] = None

        # 状态栏
        self.status = tk.StringVar(value="")
        self.status_bar = tk.Label(self.root, textvariable=self.status, anchor="w")
        self.status_bar.pack(fill=tk.X)

        # Controllers
        self.c1 = KeyboardController()
        self.c2 = KeyboardController()
        self.input_binder = InputBinder(self.c1, self.c2)

        # 初始化界面对象（体现面向对象的多态）
        self.start_screen = StartScreen(
            self.renderer.canvas,
            canvas_width,
            canvas_height,
            self.settings,
            on_start=self._on_start_selected,
            on_skin_select=self._on_skin_select_requested,
            on_settings=self._on_settings_requested,
        )
        self.end_screen = EndScreen(
            self.renderer.canvas,
            canvas_width,
            canvas_height,
            on_restart=self._on_restart_requested,
            on_menu=self._on_menu_requested,
        )
        # 皮肤选择界面（延迟初始化）
        self.skin_select_screen = None

        # 监听游戏结束事件
        self._setup_game_over_listener()

        # 窗口大小变化事件处理（确保全屏时界面能正确居中）
        self.root.bind('<Configure>', self._on_window_configure)
        
        # Key bindings
        self.root.bind("<KeyPress>", self._on_keypress)
        
        # Mouse bindings（绑定鼠标事件到画布）
        self.renderer.canvas.bind("<Button-1>", self._on_mouse_click)
        self.renderer.canvas.bind("<B1-Motion>", self._on_mouse_drag)  # 鼠标拖动
        self.renderer.canvas.bind("<ButtonRelease-1>", self._on_mouse_release)  # 鼠标释放
        self.renderer.canvas.bind("<Motion>", self._on_mouse_motion)
        # 添加鼠标滚轮支持
        self.renderer.canvas.bind("<MouseWheel>", self._on_mouse_wheel)  # Windows
        self.renderer.canvas.bind("<Button-4>", self._on_mouse_wheel)  # Linux
        self.renderer.canvas.bind("<Button-5>", self._on_mouse_wheel)  # Linux
        # 确保画布可以接收焦点和鼠标事件
        self.renderer.canvas.focus_set()
        # 设置鼠标指针样式，提示可以点击
        self.renderer.canvas.configure(cursor="hand2")

        # 初始渲染开始界面
        self.start_screen.render()
        self._loop()

    def _show_game_start_button(self) -> None:
        """在游戏界面显示开始按钮（点击后正式开始）"""
        if self.game_start_button:
            self.game_start_button.destroy()
        self.game_start_button = tk.Button(
            self.root,
            text="点击或按空格键开始游戏",
            command=self._on_game_start_click,
            bg="#e94560",
            fg="white",
            activebackground="#ff6b8a",
            activeforeground="white",
            relief=tk.RAISED,
            font=("Arial", 12, "bold"),
        )
        # 放在顶部居中
        self.game_start_button.place(relx=0.5, rely=0.01, anchor="n")

    def _hide_game_start_button(self) -> None:
        if self.game_start_button:
            self.game_start_button.destroy()
            self.game_start_button = None

    def _setup_game_over_listener(self) -> None:
        """设置游戏结束事件监听器"""
        # 这个会在游戏引擎创建后设置
        pass

    def _on_start_selected(self, settings: GameSettings) -> None:
        """开始界面选择开始游戏时的回调"""
        self.settings = settings
        self.current_screen = "game"
        # 重置结束界面渲染标记
        self._end_screen_rendered = False

    def _on_restart_requested(self) -> None:
        """结束界面请求重新开始时的回调"""
        # 实际重新开始游戏
        self._restart_game()

    def _on_menu_requested(self) -> None:
        """结束界面请求返回菜单时的回调"""
        # 返回开始界面
        self.current_screen = "start"
        # 更新开始界面的设置
        self.start_screen.settings = self.settings
        self._hide_game_start_button()
        # 渲染开始界面
        self.start_screen.render()
    
    def _get_canvas_size(self) -> tuple[int, int]:
        """获取画布实际尺寸"""
        # 更新画布尺寸（确保获取最新值）
        self.renderer.canvas.update_idletasks()
        canvas_width = self.renderer.canvas.winfo_width() or 1024
        canvas_height = self.renderer.canvas.winfo_height() or 768
        # 如果画布尺寸为1（未初始化），使用窗口尺寸
        if canvas_width <= 1 or canvas_height <= 1:
            canvas_width = self.root.winfo_width() or 1024
            canvas_height = (self.root.winfo_height() or 800) - 20  # 减去状态栏高度
        return canvas_width, canvas_height
    
    def _on_skin_select_requested(self) -> None:
        """开始界面请求皮肤选择时的回调"""
        # #region agent log
        self._log('S1', 'ui/app.py:_on_skin_select_requested', 'Skin select requested', {
            'current_screen': self.current_screen
        })
        # #endregion
        self.current_screen = "skin_select"
        self.current_player_for_skin = "P1"  # 默认选择P1的皮肤
        
        # 获取实际画布尺寸
        canvas_width, canvas_height = self._get_canvas_size()
        
        # 创建皮肤选择界面（如果不存在或尺寸不匹配）
        if not self.skin_select_screen or self.skin_select_screen.width != canvas_width or self.skin_select_screen.height != canvas_height:
            # #region agent log
            self._log('S2', 'ui/app.py:_on_skin_select_requested', 'Creating skin select screen', {
                'canvas_width': canvas_width, 'canvas_height': canvas_height
            })
            # #endregion
            self.skin_select_screen = SkinSelectScreen(
                self.renderer.canvas,
                canvas_width,
                canvas_height,
                on_complete=self._on_skin_select_completed,
                player_name=self.current_player_for_skin,
            )
        else:
            # 更新玩家名称（如果切换了玩家）
            self.skin_select_screen.player_name = self.current_player_for_skin
        
        # 渲染皮肤选择界面
        # #region agent log
        self._log('S3', 'ui/app.py:_on_skin_select_requested', 'Rendering skin select screen', {})
        # #endregion
        self.skin_select_screen.render()
    
    def _on_skin_select_switch_to_p2(self) -> None:
        """从P1皮肤选择切换到P2皮肤选择"""
        # #region agent log
        self._log('S5', 'ui/app.py:_on_skin_select_switch_to_p2', 'Switching to P2 skin select', {
            'current_screen': self.current_screen
        })
        # #endregion
        # 确保当前界面状态是skin_select
        self.current_screen = "skin_select"
        self.current_player_for_skin = "P2"
        
        # 获取实际画布尺寸
        canvas_width, canvas_height = self._get_canvas_size()
        
        # 重新创建皮肤选择界面，设置为P2
        self.skin_select_screen = SkinSelectScreen(
            self.renderer.canvas,
            canvas_width,
            canvas_height,
            on_complete=self._on_skin_select_completed,
            player_name="P2",
        )
        # 渲染P2皮肤选择界面（确保清除之前的界面）
        self.skin_select_screen.render()
    
    def _on_skin_select_switch_to_p1(self) -> None:
        """从P2皮肤选择切换到P1皮肤选择"""
        # #region agent log
        self._log('S6', 'ui/app.py:_on_skin_select_switch_to_p1', 'Switching to P1 skin select', {
            'current_screen': self.current_screen
        })
        # #endregion
        # 确保当前界面状态是skin_select
        self.current_screen = "skin_select"
        self.current_player_for_skin = "P1"
        
        # 获取实际画布尺寸
        canvas_width, canvas_height = self._get_canvas_size()
        
        # 重新创建皮肤选择界面，设置为P1
        self.skin_select_screen = SkinSelectScreen(
            self.renderer.canvas,
            canvas_width,
            canvas_height,
            on_complete=self._on_skin_select_completed,
            player_name="P1",
        )
        # 渲染P1皮肤选择界面（确保清除之前的界面）
        self.skin_select_screen.render()
    
    def _on_skin_select_completed(self) -> None:
        """皮肤选择完成时的回调"""
        # #region agent log
        self._log('S4', 'ui/app.py:_on_skin_select_completed', 'Skin select completed', {
            'current_screen': self.current_screen,
            'current_player': self.current_player_for_skin
        })
        # #endregion
        # 注意：P1和P2的皮肤都已经在SkinSelectScreen的_on_complete和_on_next中保存了
        # 这里只需要返回首页即可
        self.current_screen = "start"
        self.current_player_for_skin = "P1"  # 重置为P1，下次进入时从P1开始
        # 重新渲染开始界面
        self.start_screen.render()
    
    def _on_settings_requested(self) -> None:
        """设置界面请求回调"""
        self._log('SET1', 'ui/app.py:_on_settings_requested', 'Settings requested', {
            'current_screen': self.current_screen
        })
        # 切换到设置界面
        self.current_screen = "settings"
        
        # 获取实际画布尺寸
        canvas_width, canvas_height = self._get_canvas_size()
        
        # 创建或重新创建设置界面（如果不存在或尺寸不匹配）
        if not hasattr(self, 'settings_screen') or self.settings_screen is None:
            from ui.settings_screen import SettingsScreen
            self.settings_screen = SettingsScreen(
                self.renderer.canvas,
                canvas_width,
                canvas_height,
                self.settings,
                on_complete=self._on_settings_completed,
            )
        else:
            # 更新设置界面的尺寸和当前设置
            self.settings_screen.width = canvas_width
            self.settings_screen.height = canvas_height
            self.settings_screen.settings = self.settings
        
        # 渲染设置界面
        self.settings_screen.render()
        self.status.set("游戏设置 - 按ESC返回")
    
    def _on_settings_completed(self, new_settings: GameSettings) -> None:
        """设置完成回调"""
        self._log('SET4', 'ui/app.py:_on_settings_completed', 'Settings completed', {})
        # 保存设置到内存
        self.settings = new_settings
        # 保存设置到文件（持久化）
        from core.settings_manager import SettingsManager
        settings_manager = SettingsManager.instance()
        settings_manager.save_settings(new_settings)
        # 更新开始界面的设置
        self.start_screen.settings = new_settings
        # 返回首页
        self.current_screen = "start"
        self.start_screen.render()
        self.status.set("点击开始游戏进入地图预览")

    def _start_game(self, paused_at_start: bool = True) -> None:
        """启动游戏，默认先暂停让玩家查看地图"""
        self.current_screen = "game"
        self.engine = GameEngine()
        self.hud = Hud(self.engine.events)

        # 监听游戏结束事件
        self.engine.events.subscribe("game_over", self._on_game_over)

        self.engine.register_controller("P1", self.c1)
        if self.settings.mode in ("two", "two_timed"):
            self.engine.register_controller("P2", self.c2)
            self.input_binder.c2 = self.c2
        else:
            self.input_binder.c2 = None

        self.engine.start_game(self.settings)

        # 进入预览状态：暂停，等待点击“开始”按钮或按空格键
        if paused_at_start and self.engine.state.running:
            self.engine.state.paused = True
            # 通知UI刷新状态
            self.engine.events.emit("state_updated", self.engine.snapshot())
            self.status.set("点击顶部按钮或按空格键开始游戏")
            self._show_game_start_button()

    def _on_game_over(self, payload: dict) -> None:
        """游戏结束事件处理"""
        # #region agent log
        self._log('L', 'ui/app.py:_on_game_over', 'Function entry', {
            'payload': payload,
            'current_screen_before': self.current_screen
        })
        # #endregion
        
        self.current_screen = "end"
        self._hide_game_start_button()
        self.end_screen.set_result(payload)
        # 清除缓存，确保获取最新尺寸
        self.end_screen._cached_canvas_width = None
        self.end_screen._cached_canvas_height = None
        self.end_screen.render()
        
        # #region agent log
        self._log('M', 'ui/app.py:_on_game_over', 'After render', {
            'current_screen_after': self.current_screen
        })
        # #endregion

    def _restart_game(self) -> None:
        """重新开始游戏"""
        # #region agent log
        self._log('E', 'ui/app.py:_restart_game', 'Function entry', {
            'current_screen': self.current_screen
        })
        # #endregion
        
        self.engine = GameEngine()
        self.hud = Hud(self.engine.events)

        # 监听游戏结束事件
        self.engine.events.subscribe("game_over", self._on_game_over)

        self.engine.register_controller("P1", self.c1)
        if self.settings.mode in ("two", "two_timed"):
            self.engine.register_controller("P2", self.c2)
            self.input_binder.c2 = self.c2
        else:
            self.input_binder.c2 = None

        self.engine.start_game(self.settings)
        
        # #region agent log
        self._log('F', 'ui/app.py:_restart_game', 'After start_game', {
            'engine_running': self.engine.state.running,
            'current_screen': self.current_screen
        })
        # #endregion
        
        if self.engine.state.running:
            self.engine.state.paused = True
            self.engine.events.emit("state_updated", self.engine.snapshot())
            self.status.set("点击顶部按钮开始游戏")
            self._show_game_start_button()
            # #region agent log
            self._log('G', 'ui/app.py:_restart_game', 'Setting current_screen to game', {})
            # #endregion
            # 关键修复：切换到游戏界面
            self.current_screen = "game"

    def _on_game_start_click(self) -> None:
        """顶部按钮：正式开始游戏"""
        if self.engine and self.engine.state.running and self.engine.state.paused:
            self.engine.toggle_pause()
            self._hide_game_start_button()
            self.status.set("")

    def _on_window_configure(self, event: tk.Event) -> None:
        """窗口大小变化事件处理（确保全屏时界面能正确居中）"""
        # 获取当前窗口尺寸
        current_width = event.width
        current_height = event.height
        # 只在尺寸真正变化时才清除缓存（避免频繁操作）
        if hasattr(self, '_last_window_size'):
            if (current_width, current_height) == self._last_window_size:
                return
        self._last_window_size = (current_width, current_height)
        
        # 更新画布尺寸
        canvas_width, canvas_height = self._get_canvas_size()
        
        # 根据当前界面清除缓存，强制重新获取尺寸
        if self.current_screen == "start":
            self.start_screen.width = canvas_width
            self.start_screen.height = canvas_height
            # 清除首页的缓存（如果有）
            if hasattr(self.start_screen, '_cached_canvas_width'):
                self.start_screen._cached_canvas_width = None
                self.start_screen._cached_canvas_height = None
            self.start_screen.render()
        elif self.current_screen == "end":
            self.end_screen.width = canvas_width
            self.end_screen.height = canvas_height
            # 清除结束界面的缓存
            self.end_screen._cached_canvas_width = None
            self.end_screen._cached_canvas_height = None
            self.end_screen.render()
    
    def _on_keypress(self, event: tk.Event) -> None:
        """统一的键盘事件处理（体现面向对象的多态）"""
        key = getattr(event, "keysym", "")

        # 根据当前界面状态分发键盘事件
        if self.current_screen == "start":
            result = self.start_screen.handle_key(key)
            if result == "game":
                self._start_game()
            elif result == "exit":
                self.root.quit()

        elif self.current_screen == "end":
            result = self.end_screen.handle_key(key)
            if result == "game":
                self._restart_game()
            elif result == "start":
                self.start_screen.render()
            elif result == "exit":
                self.root.quit()
        
        elif self.current_screen == "skin_select":
            # 皮肤选择界面：处理键盘事件
            if hasattr(self, 'skin_select_screen') and self.skin_select_screen:
                result = self.skin_select_screen.handle_key(key)
                if result == "start":
                    # 返回首页
                    self._on_skin_select_completed()
        
        elif self.current_screen == "settings":
            # 设置界面：处理键盘事件
            if hasattr(self, 'settings_screen') and self.settings_screen:
                result = self.settings_screen.handle_key(key)
                if result == "start":
                    # 设置完成，返回首页
                    if hasattr(self.settings_screen, 'get_settings'):
                        new_settings = self.settings_screen.get_settings()
                        self._on_settings_completed(new_settings)
                    else:
                        self.current_screen = "start"
                        self.start_screen.render()
                        self.status.set("点击开始游戏进入地图预览")
                elif result == "exit":
                    self.root.quit()

        elif self.current_screen == "game":
            # 游戏中的键盘处理
            if key == "space":
                if self.engine:
                    # 与点击开始游戏按钮的效果一致
                    if self.engine.state.running and self.engine.state.paused:
                        # 显示了开始游戏按钮的状态，按下空格相当于点击按钮
                        self.engine.toggle_pause()
                        self._hide_game_start_button()
                        self.status.set("")
                    else:
                        # 正常游戏状态，切换暂停
                        self.engine.toggle_pause()
                return
            if key in ("r", "R"):
                self._restart_game()
                return
            if key == "Escape":
                # 暂停并返回菜单
                if self.engine:
                    self.engine.toggle_pause()
                self._hide_game_start_button()
                self.current_screen = "start"
                self.start_screen.render()
                return
            if key in ("Shift_L", "Shift_R", "Shift"):
                # Shift键：蛇长度减半（仅在单人模式和限时模式下可用，双人模式禁用）
                if self.engine and self.engine.state.running and not self.engine.state.paused:
                    # 双人模式禁用道具功能
                    if self.settings.mode in ("two", "two_timed"):
                        return
                    
                    # 单人模式和限时模式：使用道具
                    target_player = "P1"  # 单人模式和限时模式只有P1
                    
                    # 找到目标玩家的蛇并减半长度
                    for snake in self.engine.snakes:
                        if snake.name == target_player and snake.alive:
                            old_length = len(snake.body)
                            # 检查是否可以使用技能（每局最多2次）
                            if snake.shrink_skill_uses >= 2:
                                remaining = 2 - snake.shrink_skill_uses
                                self.engine.events.emit("warning", {"message": f"{snake.name} Shift技能使用次数已达上限（2次）！"})
                            else:
                                success = snake.shrink_half()
                                new_length = len(snake.body)
                                if success and old_length != new_length:  # 只有当长度真正变化时才提示
                                    remaining = 2 - snake.shrink_skill_uses
                                    self.engine.events.emit("warning", {"message": f"{snake.name} 使用Shift键，长度从{old_length}减半到{new_length}！（剩余次数：{remaining}）"})
                            break
                return

            # 游戏控制输入
            self.input_binder.on_key(key)

    def _log(self, hypothesis_id, location, message, data):
        try:
            with open(r'd:\Desktop\snake_oop_project_v2\.cursor\debug.log', 'a', encoding='utf-8') as f:
                f.write(json.dumps({
                    'sessionId': 'debug-session',
                    'runId': 'run1',
                    'hypothesisId': hypothesis_id,
                    'location': location,
                    'message': message,
                    'data': data,
                    'timestamp': int(datetime.now().timestamp() * 1000)
                }, ensure_ascii=False) + '\n')
        except: pass

    def _on_mouse_click(self, event: tk.Event) -> None:
        """处理鼠标点击事件"""
        x = event.x
        y = event.y

        # #region agent log
        self._log('A', 'ui/app.py:_on_mouse_click', 'Mouse click received', {
            'x': x, 'y': y, 'current_screen': self.current_screen
        })
        # #endregion

        # 根据当前界面状态分发鼠标事件
        if self.current_screen == "start":
            result = self.start_screen.handle_click(x, y)
            if result == "game":
                # 先更新设置，然后启动游戏
                self.settings = self.start_screen.get_settings()
                self._start_game()
            elif result == "skin_select":
                # #region agent log
                self._log('SC1', 'ui/app.py:_on_mouse_click', 'Skin select click from start screen', {})
                # #endregion
                self._on_skin_select_requested()
            elif result == "settings":
                # #region agent log
                self._log('SET2', 'ui/app.py:_on_mouse_click', 'Settings click from start screen', {})
                # #endregion
                self._on_settings_requested()
        elif self.current_screen == "skin_select":
            # #region agent log
            self._log('SC2', 'ui/app.py:_on_mouse_click', 'Skin select screen click', {'x': x, 'y': y})
            # #endregion
            if self.skin_select_screen:
                result = self.skin_select_screen.handle_click(x, y)
                if result == "start":
                    # #region agent log
                    self._log('SC3', 'ui/app.py:_on_mouse_click', 'Returning to start from skin select', {})
                    # #endregion
                    self._on_skin_select_completed()
                elif result == "next_p2":
                    # 切换到P2皮肤选择
                    self._on_skin_select_switch_to_p2()
                elif result == "prev_p1":
                    # 切换到P1皮肤选择
                    self._on_skin_select_switch_to_p1()
        elif self.current_screen == "settings":
            # 设置界面：处理鼠标点击
            if hasattr(self, 'settings_screen') and self.settings_screen:
                result = self.settings_screen.handle_click(x, y)
                if result == "start":
                    # 设置完成，返回首页
                    if hasattr(self.settings_screen, 'get_settings'):
                        new_settings = self.settings_screen.get_settings()
                        self._on_settings_completed(new_settings)
                    else:
                        self.current_screen = "start"
                        self.start_screen.render()
                        self.status.set("点击开始游戏进入地图预览")
        elif self.current_screen == "end":
            # #region agent log
            self._log('B', 'ui/app.py:_on_mouse_click', 'End screen click handling', {
                'x': x, 'y': y
            })
            # #endregion
            result = self.end_screen.handle_click(x, y)
            # #region agent log
            self._log('C', 'ui/app.py:_on_mouse_click', 'End screen handle_click result', {
                'result': result
            })
            # #endregion
            if result == "game":
                # #region agent log
                self._log('D', 'ui/app.py:_on_mouse_click', 'Calling _restart_game', {})
                # #endregion
                self._restart_game()
            elif result == "start":
                self.start_screen.render()
                self.current_screen = "start"

    def _on_mouse_motion(self, event: tk.Event) -> None:
        """处理鼠标移动事件（用于悬停效果）"""
        x = event.x
        y = event.y

        if self.current_screen == "start":
            self.start_screen.handle_motion(x, y)
        elif self.current_screen == "skin_select":
            if self.skin_select_screen:
                self.skin_select_screen.handle_motion(x, y)
        elif self.current_screen == "end":
            self.end_screen.handle_motion(x, y)
        elif self.current_screen == "settings":
            if hasattr(self, 'settings_screen') and self.settings_screen:
                self.settings_screen.handle_motion(x, y)
    
    def _on_mouse_drag(self, event: tk.Event) -> None:
        """处理鼠标拖动事件（用于滑动条拖动）"""
        x = event.x
        y = event.y
        
        if self.current_screen == "settings":
            if hasattr(self, 'settings_screen') and self.settings_screen:
                if hasattr(self.settings_screen, 'handle_drag'):
                    self.settings_screen.handle_drag(x, y)
    
    def _on_mouse_release(self, event: tk.Event) -> None:
        """处理鼠标释放事件（用于滑动条拖动结束）"""
        x = event.x
        y = event.y
        
        if self.current_screen == "settings":
            if hasattr(self, 'settings_screen') and self.settings_screen:
                if hasattr(self.settings_screen, 'handle_release'):
                    self.settings_screen.handle_release(x, y)
    
    def _on_mouse_wheel(self, event: tk.Event) -> None:
        """处理鼠标滚轮事件"""
        # 获取滚轮增量
        delta = 0
        if hasattr(event, 'delta'):  # Windows
            delta = event.delta
        else:  # Linux
            if event.num == 4:  # 向上滚动
                delta = 120
            elif event.num == 5:  # 向下滚动
                delta = -120
        
        # 根据当前界面状态分发鼠标滚轮事件
        if self.current_screen == "settings":
            if hasattr(self, 'settings_screen') and self.settings_screen:
                if hasattr(self.settings_screen, 'handle_wheel'):
                    self.settings_screen.handle_wheel(delta)
        elif self.current_screen == "skin_select":
            if hasattr(self, 'skin_select_screen') and self.skin_select_screen:
                if hasattr(self.skin_select_screen, 'handle_wheel'):
                    self.skin_select_screen.handle_wheel(delta)

    def _loop(self) -> None:
        """主循环（根据当前界面状态进行不同的渲染）"""
        if self.current_screen == "game":
            if self.engine:
                now_ms = int(time.time() * 1000)
                self.engine.update(now_ms)
                snap = self.engine.snapshot()
                self.renderer.render(snap, self.hud)  # 传递HUD给渲染器
                if self.hud:
                    self.status.set(self.hud.render_text())
            else:
                # 如果引擎未初始化，显示空状态
                self.status.set("")
        elif self.current_screen == "start":
            # 开始界面：只设置状态栏，不重复渲染（避免覆盖其他界面）
            # 注意：start_screen.render() 只在切换界面时调用，不在循环中调用
            self.status.set("点击开始游戏进入地图预览")
        elif self.current_screen == "skin_select":
            # 皮肤选择界面：确保渲染皮肤选择界面
            # 每次循环都渲染，确保界面内容正确显示
            if self.skin_select_screen:
                self.skin_select_screen.render()
            self.status.set(f"选择{self.current_player_for_skin}皮肤")
        elif self.current_screen == "settings":
            # 设置界面：提示信息已在_on_settings_requested中渲染
            # 不重复渲染，避免滑块值被重置
            self.status.set("游戏设置 - 按ESC返回")
        elif self.current_screen == "end":
            # 结束界面：确保渲染结束界面（每次循环都渲染，防止被覆盖）
            # #region agent log
            self._log('N', 'ui/app.py:_loop', 'Rendering end screen in loop', {
                'current_screen': self.current_screen
            })
            # #endregion
            self.end_screen.render()
            self.status.set("")

        # Schedule next tick
        self.root.after(16, self._loop)  # ~60 fps UI refresh

    def run(self) -> None:
        self.root.mainloop()
