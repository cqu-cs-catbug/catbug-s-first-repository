from __future__ import annotations
from typing import Callable, Optional
import tkinter as tk


class Button:
    """按钮组件类，封装按钮的绘制和交互逻辑（体现面向对象的封装）"""

    def __init__(
        self,
        canvas: tk.Canvas,
        x: int,
        y: int,
        width: int,
        height: int,
        text: str,
        on_click: Callable[[], None],
        font: tuple = ("Arial", 18),
        normal_color: str = "#e94560",
        hover_color: str = "#ff6b8a",
        text_color: str = "white",
        border_color: str = "#c73650",
    ) -> None:
        self.canvas = canvas
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
        self.on_click = on_click
        self.font = font
        self.normal_color = normal_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.border_color = border_color
        self.is_hovered = False
        self.tag = f"button_{id(self)}"
        self._render()

    def _render(self) -> None:
        """渲染按钮"""
        # 先删除旧内容
        self.canvas.delete(self.tag)
        
        color = self.hover_color if self.is_hovered else self.normal_color
        x1 = self.x - self.width // 2
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2
        y2 = self.y + self.height // 2

        # 只有当颜色不为空时才绘制背景（修复：允许透明按钮）
        if color:
            # 绘制按钮背景（带阴影效果，增强立体感）
            # 阴影层
            self.canvas.create_rectangle(
                x1 + 3, y1 + 3, x2 + 3, y2 + 3,
                fill="#000000",
                outline="",
                tags=self.tag,
            )
            # 主背景
            self.canvas.create_rectangle(
                x1, y1, x2, y2,
                fill=color,
                outline=self.border_color if self.border_color else "",
                width=2 if self.border_color else 0,
                tags=self.tag,
            )
            


        # 绘制文本（确保文字始终显示）
        if self.text:
            self.canvas.create_text(
                self.x, self.y,
                text=self.text,
                font=self.font,
                fill=self.text_color,
                tags=self.tag,
            )

    def contains(self, x: int, y: int) -> bool:
        """检查点是否在按钮区域内"""
        x1 = self.x - self.width // 2
        y1 = self.y - self.height // 2
        x2 = self.x + self.width // 2
        y2 = self.y + self.height // 2
        return x1 <= x <= x2 and y1 <= y <= y2

    def set_hover(self, hovered: bool) -> None:
        """设置悬停状态"""
        if self.is_hovered != hovered:
            self.is_hovered = hovered
            self._render()

    def click(self) -> None:
        """触发按钮点击"""
        self.on_click()

    def delete(self) -> None:
        """删除按钮"""
        self.canvas.delete(self.tag)


class ClickableOption:
    """可点击选项类，用于菜单选项（体现面向对象的组合）"""

    def __init__(
        self,
        canvas: tk.Canvas,
        x: int,
        y: int,
        text: str,
        on_click: Callable[[], None],
        is_selected: bool = False,
        font: tuple = ("Arial", 18),
        selected_color: str = "#e94560",
        normal_color: str = "#16213e",
    ) -> None:
        self.canvas = canvas
        self.x = x
        self.y = y
        self.text = text
        self.on_click = on_click
        self.is_selected = is_selected
        self.font = font
        self.selected_color = selected_color
        self.normal_color = normal_color
        self.is_hovered = False
        self.tag = f"option_{id(self)}"
        self._render()

    def _render(self) -> None:
        """渲染选项"""
        prefix = "▶ " if self.is_selected else "  "
        if self.is_hovered and not self.is_selected:
            color = "#ff6b8a"
        else:
            color = self.selected_color if self.is_selected else self.normal_color

        self.canvas.create_text(
            self.x, self.y,
            text=f"{prefix}{self.text}",
            font=self.font,
            fill=color,
            tags=self.tag,
        )

    def contains(self, x: int, y: int, tolerance: int = 50) -> bool:
        """检查点是否在选项区域内（使用容差，同时检查X和Y坐标）"""
        # 估算文本高度和宽度
        text_height = 25
        # 估算文本宽度（根据字体大小，大约每个字符15像素）
        estimated_text_width = len(self.text) * 15 + 20  # 加上前缀和边距
        
        # 检查Y坐标
        y1 = self.y - text_height // 2
        y2 = self.y + text_height // 2
        y_in_range = y1 <= y <= y2
        
        # 检查X坐标（考虑文本宽度）
        x1 = self.x - estimated_text_width // 2
        x2 = self.x + estimated_text_width // 2
        x_in_range = x1 <= x <= x2
        
        return x_in_range and y_in_range

    def set_selected(self, selected: bool) -> None:
        """设置选中状态"""
        if self.is_selected != selected:
            self.is_selected = selected
            self._render()

    def set_hover(self, hovered: bool) -> None:
        """设置悬停状态"""
        if self.is_hovered != hovered:
            self.is_hovered = hovered
            self._render()

    def click(self) -> None:
        """触发选项点击"""
        self.on_click()

    def delete(self) -> None:
        """删除选项"""
        self.canvas.delete(self.tag)
