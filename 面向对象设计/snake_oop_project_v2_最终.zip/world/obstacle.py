from __future__ import annotations
from dataclasses import dataclass
import random
from typing import Optional

from core.types import Position, Direction


@dataclass
class Obstacle:
    position: Position
    blocks: bool = True
    dynamic: bool = False

    def update(self, game_map: "GameMap") -> None:
        """Override in subclasses for dynamic obstacles."""
        return


class MovingObstacle(Obstacle):
    """A simple dynamic obstacle that randomly walks every few ticks."""

    def __init__(self, position: Position, step_interval: int = 8) -> None:
        super().__init__(position=position, blocks=True, dynamic=True)
        self._step_interval = max(1, step_interval)
        self._counter = 0

    def update(self, game_map: "GameMap") -> None:
        self._counter += 1
        if self._counter % self._step_interval != 0:
            return

        # Try a few random neighbor moves; stay if no valid move.
        candidates = [d.delta for d in Direction]
        random.shuffle(candidates)
        for dx, dy in candidates:
            nxt = Position(self.position.x + dx, self.position.y + dy)
            if game_map.within_bounds(nxt) and not game_map.is_blocked(nxt, include_dynamic=False):
                self.position = nxt
                return
