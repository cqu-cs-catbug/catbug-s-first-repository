from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set
import random

from core.types import Position, TerrainType
from world.obstacle import Obstacle, MovingObstacle


@dataclass
class GameMap:
    width: int
    height: int
    terrain: Dict[Position, TerrainType] = field(default_factory=dict)
    obstacles: List[Obstacle] = field(default_factory=list)

    def within_bounds(self, pos: Position) -> bool:
        return 0 <= pos.x < self.width and 0 <= pos.y < self.height

    def get_terrain(self, pos: Position) -> TerrainType:
        return self.terrain.get(pos, TerrainType.PLAIN)

    def add_obstacle(self, obstacle: Obstacle) -> None:
        self.obstacles.append(obstacle)

    def remove_obstacle(self, obstacle: Obstacle) -> None:
        if obstacle in self.obstacles:
            self.obstacles.remove(obstacle)

    def update_obstacles(self) -> None:
        for ob in self.obstacles:
            if getattr(ob, "dynamic", False):
                ob.update(self)

    def is_blocked(self, pos: Position, *, include_dynamic: bool = True) -> bool:
        """Blocked means snake cannot move into the cell."""
        if not self.within_bounds(pos):
            return True
        t = self.get_terrain(pos)
        if t == TerrainType.MOUNTAIN:
            return True
        for ob in self.obstacles:
            if (not include_dynamic) and getattr(ob, "dynamic", False):
                continue
            if ob.blocks and ob.position == pos:
                return True
        return False

    def random_empty_cell(self, occupied: Set[Position]) -> Optional[Position]:
        """Find a random free cell (not blocked and not occupied)."""
        tries = self.width * self.height
        for _ in range(tries):
            p = Position(random.randrange(self.width), random.randrange(self.height))
            if p in occupied:
                continue
            if self.is_blocked(p):
                continue
            return p
        return None

    @classmethod
    def build_default(cls, width: int, height: int, enable_moving_obstacle: bool = True, difficulty: str = "normal", enable_mountain: bool = True, enable_swamp: bool = True) -> "GameMap":
        game_map = cls(width=width, height=height)
        
        # 根据难度调整山地块生成比例
        total_area = (width - 2) * (height - 2)  # 减去边界
        # 难度越大，山地越多
        if difficulty == "easy":
            mountain_ratio = 0.03  # 3%的山地比例
        elif difficulty == "hard":
            mountain_ratio = 0.10  # 10%的山地比例
        else:  # normal
            mountain_ratio = 0.06  # 6%的山地比例
        target_mountain_area = int(total_area * mountain_ratio)
        placed_mountain_area = 0
        
        # Border mountains as walls (保留边界墙)
        for x in range(width):
            game_map.terrain[Position(x, 0)] = TerrainType.MOUNTAIN
            game_map.terrain[Position(x, height - 1)] = TerrainType.MOUNTAIN
        for y in range(height):
            game_map.terrain[Position(0, y)] = TerrainType.MOUNTAIN
            game_map.terrain[Position(width - 1, y)] = TerrainType.MOUNTAIN

        # 生成山地方块（2x2或3x3）- 仅在启用时生成
        max_tries = 1000  # 防止无限循环
        if enable_mountain:
            while placed_mountain_area < target_mountain_area and max_tries > 0:
                max_tries -= 1
                # 随机选择块大小（2x2或3x3）
                block_size = random.choice([2, 3])
                # 随机选择位置
                block_x = random.randrange(1, width - block_size)
                block_y = random.randrange(1, height - block_size)
                
                # 检查该位置是否可以放置山地方块
                can_place = True
                
                # 检查山地块是否会覆盖蛇出生点前方5格区域
                # 玩家1出生点：(4,4) 向右，前方5格：x从4到9，y=4
                # 玩家2出生点：(width-5, height-5) 向左，前方5格：x从width-10到width-5，y=height-5
                for dx in range(block_size):
                    for dy in range(block_size):
                        pos = Position(block_x + dx, block_y + dy)
                        
                        # 检查是否已被占用
                        if pos in game_map.terrain:
                            can_place = False
                            break
                        
                        # 检查是否在玩家1出生点前方5格内
                        if pos.y == 4 and 4 <= pos.x <= 9:
                            can_place = False
                            break
                        
                        # 检查是否在玩家2出生点前方5格内
                        if pos.y == height - 5 and (width - 10) <= pos.x <= (width - 5):
                            can_place = False
                            break
                    
                    if not can_place:
                        break
                
                if can_place:
                    # 放置山地方块
                    for dx in range(block_size):
                        for dy in range(block_size):
                            pos = Position(block_x + dx, block_y + dy)
                            game_map.terrain[pos] = TerrainType.MOUNTAIN
                    placed_mountain_area += block_size * block_size

        # 根据难度调整湿地生成比例 - 仅在启用时生成
        # 难度越大，湿地越多
        if enable_swamp:
            if difficulty == "easy":
                swamp_ratio = 0.02  # 2%的湿地比例
            elif difficulty == "hard":
                swamp_ratio = 0.06  # 6%的湿地比例
            else:  # normal
                swamp_ratio = 0.04  # 4%的湿地比例

            # 随机生成湿地（内部区域）
            # 优化：减少湿地数量，但确保分布合理，避免过度集中
            swamp_count = int((width - 2) * (height - 2) * swamp_ratio)
            max_attempts = swamp_count * 3  # 增加尝试次数，确保能放置足够的湿地
            attempts = 0
            placed_count = 0
            
            while placed_count < swamp_count and attempts < max_attempts:
                attempts += 1
                x = random.randrange(1, width - 1)
                y = random.randrange(1, height - 1)
                pos = Position(x, y)
                # 确保不是边界，不是山地，且不与已有地形冲突
                if pos not in game_map.terrain:
                    game_map.terrain[pos] = TerrainType.SWAMP
                    placed_count += 1

        # 少量单格山地地形（随机位置）- 仅在启用山地时生成
        # 难度越大，单格山地越多
        if enable_mountain:
            if difficulty == "easy":
                mountain_single_count = random.randint(0, 1)  # 0-1个单格山地
            elif difficulty == "hard":
                mountain_single_count = random.randint(2, 3)  # 2-3个单格山地
            else:  # normal
                mountain_single_count = random.randint(1, 2)  # 1-2个单格山地
            for _ in range(mountain_single_count):
                x = random.randrange(2, width - 2)
                y = random.randrange(2, height - 2)
                pos = Position(x, y)
                # 确保不在已有地形上，且不在蛇出生点前方5格内
                if pos not in game_map.terrain:
                    # 检查是否在玩家1出生点前方5格内
                    if pos.y == 4 and 4 <= pos.x <= 9:
                        continue
                    # 检查是否在玩家2出生点前方5格内
                    if pos.y == height - 5 and (width - 10) <= pos.x <= (width - 5):
                        continue
                    # 放置单格山地
                    game_map.terrain[pos] = TerrainType.MOUNTAIN

        # 一个移动障碍物（可选，随机位置）
        if enable_moving_obstacle:
            x = random.randrange(3, width - 3)
            y = random.randrange(3, height - 3)
            pos = Position(x, y)
            if not game_map.is_blocked(pos, include_dynamic=False):
                game_map.add_obstacle(MovingObstacle(pos, step_interval=10))

        return game_map
